import { 
  db, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  query, 
  where, 
  onSnapshot, 
  deleteDoc, 
  updateDoc 
} from '../lib/firebase';
import { UserProfile, ActiveGameType } from '../types';
import { Friend, FriendRequest, addFriendToUser, getFriends } from './friends';

// 1. Sync User Profile to Firestore (WITHOUT PASSWORD)
export const syncUserProfileToFirestore = async (user: UserProfile) => {
  if (!user || !user.username) return;
  const cleanUsername = user.username.trim().toLowerCase().replace(/^@/, '');
  try {
    const userDocRef = doc(db, 'users', cleanUsername);
    await setDoc(userDocRef, {
      userId: user.id || cleanUsername,
      username: cleanUsername,
      name: user.name,
      avatar: user.avatar,
      coins: user.coins ?? 250,
      score: user.score ?? 0,
      isOnline: true,
      lastSeen: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Failed to sync user to Firestore:', err);
  }
};

// 2. Search User in Firestore by Username (Only returns public profile: name, username, avatar - NO PASSWORDS)
export const searchFirestoreUser = async (
  usernameQuery: string
): Promise<{ exists: boolean; account?: { name: string; username: string; avatar: string; id: string } }> => {
  const clean = usernameQuery.trim().toLowerCase().replace(/^@/, '');
  if (!clean) return { exists: false };

  try {
    const userDocRef = doc(db, 'users', clean);
    const snap = await getDoc(userDocRef);

    if (snap.exists()) {
      const data = snap.data();
      return {
        exists: true,
        account: {
          id: data.userId || clean,
          name: data.name || clean,
          username: data.username || clean,
          avatar: data.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${clean}`,
        },
      };
    }
  } catch (err) {
    console.warn('Firestore user search error:', err);
  }

  return { exists: false };
};

// 3. Send Real-time Friend Request / Invite to Firestore
export const sendFirestoreFriendRequest = async (
  fromUser: UserProfile,
  targetUsername: string,
  roomCode?: string,
  gameType?: ActiveGameType,
  isGameInvite?: boolean
): Promise<{ success: boolean; message: string }> => {
  const cleanTarget = targetUsername.trim().toLowerCase().replace(/^@/, '');
  const cleanCurrent = fromUser.username.trim().toLowerCase().replace(/^@/, '');

  if (!cleanTarget) return { success: false, message: 'Please enter a valid User ID.' };
  if (cleanTarget === cleanCurrent) return { success: false, message: 'You cannot send a friend request to yourself.' };

  const isGame = Boolean(isGameInvite || roomCode);
  const requestId = `${cleanCurrent}_to_${cleanTarget}_${Date.now()}`;

  try {
    const reqDocRef = doc(db, 'friend_requests', requestId);
    await setDoc(reqDocRef, {
      id: requestId,
      fromUserId: fromUser.id,
      fromUsername: cleanCurrent,
      fromName: fromUser.name,
      fromAvatar: fromUser.avatar,
      toUsername: cleanTarget,
      status: 'pending',
      type: roomCode ? 'room_invite' : isGame ? 'game_challenge' : 'friend_request',
      roomCode: roomCode || null,
      gameType: gameType || null,
      timestamp: Date.now(),
      expiresInSeconds: isGame ? 15 : 0,
      createdAt: new Date().toISOString(),
    });

    return {
      success: true,
      message: isGame 
        ? (roomCode ? `Room invite sent to @${cleanTarget}! (15s timer)` : `Game invite sent to @${cleanTarget}! (15s timer)`)
        : `Friend Request sent to @${cleanTarget} via Firebase!`,
    };
  } catch (err) {
    console.warn('Firestore sendFriendRequest error:', err);
    return { success: false, message: 'Failed to send request to Firebase.' };
  }
};

// 4. Listen for Real-time Incoming Friend Requests & Game Invites
export const subscribeToIncomingRequests = (
  currentUsername: string,
  onUpdate: (requests: FriendRequest[]) => void
) => {
  const clean = currentUsername.trim().toLowerCase().replace(/^@/, '');
  if (!clean) return () => {};

  try {
    const q = query(
      collection(db, 'friend_requests'),
      where('toUsername', '==', clean),
      where('status', '==', 'pending')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const requests: FriendRequest[] = [];
      const now = Date.now();
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        // Check 15s expiry for game invites
        if (data.expiresInSeconds && data.expiresInSeconds > 0) {
          const elapsed = (now - data.timestamp) / 1000;
          if (elapsed > data.expiresInSeconds) return;
        }
        requests.push({
          id: docSnap.id,
          fromUserId: data.fromUserId || `usr_${data.fromUsername}`,
          fromName: data.fromName || data.fromUsername,
          fromUsername: data.fromUsername,
          fromAvatar: data.fromAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${data.fromUsername}`,
          toUsername: data.toUsername,
          timestamp: data.timestamp || Date.now(),
          expiresInSeconds: data.expiresInSeconds || 0,
          roomCode: data.roomCode || undefined,
          gameType: data.gameType || undefined,
          type: data.type || 'friend_request',
        });
      });
      onUpdate(requests);
    }, (error) => {
      console.warn('Firestore friend_requests subscription error:', error);
    });

    return unsubscribe;
  } catch (err) {
    console.warn('Subscribe error:', err);
    return () => {};
  }
};

// 5. Accept Friend Request on Firestore & Create Mutual Friendship
export const acceptFirestoreRequest = async (
  requestId: string,
  request: FriendRequest,
  currentUser: UserProfile
): Promise<{ success: boolean; friend?: Friend }> => {
  try {
    const reqDocRef = doc(db, 'friend_requests', requestId);
    // Delete or mark accepted so it is immediately removed from pending queries
    await deleteDoc(reqDocRef).catch(async () => {
      await updateDoc(reqDocRef, { status: 'accepted' });
    });

    // Store mutual friendship in Firestore
    const cleanCurrent = currentUser.username.toLowerCase();
    const cleanOther = request.fromUsername.toLowerCase();
    const friendshipId = [cleanCurrent, cleanOther].sort().join('_');

    const friendshipRef = doc(db, 'friendships', friendshipId);
    await setDoc(friendshipRef, {
      user1: cleanCurrent,
      user2: cleanOther,
      user1Name: currentUser.name,
      user2Name: request.fromName,
      user1Avatar: currentUser.avatar,
      user2Avatar: request.fromAvatar,
      createdAt: Date.now(),
    }, { merge: true });

    const newFriend: Friend = {
      id: request.fromUserId,
      name: request.fromName,
      username: request.fromUsername,
      avatar: request.fromAvatar,
      isOnline: true,
      statusText: 'Online',
      addedAt: Date.now(),
    };

    addFriendToUser(currentUser.id, newFriend);

    return { success: true, friend: newFriend };
  } catch (err) {
    console.warn('Firestore accept error:', err);
    return { success: false };
  }
};

// 6. Reject / Delete Friend Request on Firestore
export const rejectFirestoreRequest = async (requestId: string) => {
  try {
    const reqDocRef = doc(db, 'friend_requests', requestId);
    await deleteDoc(reqDocRef).catch(async () => {
      await updateDoc(reqDocRef, { status: 'rejected' });
    });
  } catch (err) {
    console.warn('Firestore reject error:', err);
  }
};

// 7. Remove Friend / Delete Mutual Friendship on Firestore
export const removeFriendFromFirestore = async (user1Username: string, user2Username: string) => {
  try {
    const clean1 = (user1Username || '').trim().toLowerCase();
    const clean2 = (user2Username || '').trim().toLowerCase();
    if (!clean1 || !clean2) return;
    const friendshipId = [clean1, clean2].sort().join('_');
    const friendshipRef = doc(db, 'friendships', friendshipId);
    await deleteDoc(friendshipRef);
  } catch (err) {
    console.warn('Firestore remove friendship error:', err);
  }
};

