/**
 * Voice Recording and Speech Synthesis Utility for "Guess the Imposter"
 */

export interface VoiceRecordingResult {
  audioBlob: Blob;
  audioUrl: string;
  durationSeconds: number;
}

class VoiceRecorderManager {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private stream: MediaStream | null = null;
  private startTime: number = 0;

  public async startRecording(): Promise<boolean> {
    try {
      this.audioChunks = [];
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.mediaRecorder = new MediaRecorder(this.stream);
      this.startTime = Date.now();

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };

      this.mediaRecorder.start();
      return true;
    } catch (err) {
      console.warn('Microphone access unavailable or denied, falling back to simulated voice recording', err);
      this.startTime = Date.now();
      return false;
    }
  }

  public async stopRecording(): Promise<VoiceRecordingResult> {
    const elapsed = Math.max(1, Math.round((Date.now() - this.startTime) / 1000));

    return new Promise((resolve) => {
      if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        this.mediaRecorder.onstop = () => {
          const blob = new Blob(this.audioChunks, { type: 'audio/webm' });
          const url = URL.createObjectURL(blob);
          if (this.stream) {
            this.stream.getTracks().forEach((track) => track.stop());
            this.stream = null;
          }
          resolve({
            audioBlob: blob,
            audioUrl: url,
            durationSeconds: elapsed,
          });
        };
        this.mediaRecorder.stop();
      } else {
        // Fallback simulation blob
        const emptyBlob = new Blob([], { type: 'audio/webm' });
        resolve({
          audioBlob: emptyBlob,
          audioUrl: '',
          durationSeconds: elapsed,
        });
      }
    });
  }

  public speakText(text: string, voicePitch: number = 1, onEnd?: () => void) {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.pitch = voicePitch;
        utterance.rate = 1.0;
        utterance.onend = () => {
          if (onEnd) onEnd();
        };
        utterance.onerror = () => {
          if (onEnd) onEnd();
        };
        window.speechSynthesis.speak(utterance);
      } catch (err) {
        if (onEnd) onEnd();
      }
    } else {
      if (onEnd) setTimeout(onEnd, 2000);
    }
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}

export const voiceRecorder = new VoiceRecorderManager();
