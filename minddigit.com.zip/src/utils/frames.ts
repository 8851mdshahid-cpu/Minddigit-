export interface AvatarFrame {
  id: string;
  name: string;
  hindiName: string;
  icon: string;
  borderClass: string;
  badgeEmoji?: string;
  glowColor: string;
  description: string;
}

export const AVATAR_FRAMES: AvatarFrame[] = [
  {
    id: 'default',
    name: 'Classic Slate',
    hindiName: 'क्लासिक फ्रेम',
    icon: '⚪',
    borderClass: 'border-2 border-white shadow-sm',
    glowColor: 'rgba(255, 255, 255, 0.2)',
    description: 'Clean minimalist classic profile border',
  },
  {
    id: 'gold-royale',
    name: 'Gold Royale',
    hindiName: 'रॉयल गोल्ड फ्रेम',
    icon: '👑',
    borderClass: 'border-3 border-amber-400 ring-2 ring-amber-300 shadow-md shadow-amber-500/30',
    badgeEmoji: '👑',
    glowColor: 'rgba(245, 158, 11, 0.4)',
    description: 'Prestigious golden aura with champion crown',
  },
  {
    id: 'cyber-neon',
    name: 'Cyber Neon',
    hindiName: 'साइबर नियॉन',
    icon: '⚡',
    borderClass: 'border-3 border-cyan-400 ring-2 ring-cyan-300 shadow-md shadow-cyan-500/40 animate-pulse',
    badgeEmoji: '⚡',
    glowColor: 'rgba(6, 182, 212, 0.4)',
    description: 'Electric futuristic pulsing cyan neon light',
  },
  {
    id: 'fire-blaze',
    name: 'Fire Blaze',
    hindiName: 'फायर ब्लेज़',
    icon: '🔥',
    borderClass: 'border-3 border-orange-500 ring-2 ring-amber-400 shadow-md shadow-orange-500/40',
    badgeEmoji: '🔥',
    glowColor: 'rgba(249, 115, 22, 0.4)',
    description: 'High streak flaming red-orange heat',
  },
  {
    id: 'diamond-elite',
    name: 'Diamond Elite',
    hindiName: 'डायमंड एलीट',
    icon: '💎',
    borderClass: 'border-3 border-blue-400 ring-2 ring-sky-300 shadow-md shadow-sky-400/40',
    badgeEmoji: '💎',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    description: 'Sparkling crystal diamond border',
  },
  {
    id: 'cosmic-purple',
    name: 'Cosmic Nebula',
    hindiName: 'कॉस्मिक नेबुला',
    icon: '🌌',
    borderClass: 'border-3 border-purple-500 ring-2 ring-fuchsia-400 shadow-md shadow-purple-500/40',
    badgeEmoji: '✨',
    glowColor: 'rgba(168, 85, 247, 0.4)',
    description: 'Mystic deep-space galactic aura',
  },
  {
    id: 'emerald-knight',
    name: 'Emerald Knight',
    hindiName: 'एमराल्ड शील्ड',
    icon: '🛡️',
    borderClass: 'border-3 border-emerald-500 ring-2 ring-teal-400 shadow-md shadow-emerald-500/40',
    badgeEmoji: '🛡️',
    glowColor: 'rgba(16, 185, 129, 0.4)',
    description: 'Unbreakable emerald victory shield',
  },
];

export const getFrameById = (frameId?: string): AvatarFrame => {
  return AVATAR_FRAMES.find((f) => f.id === frameId) || AVATAR_FRAMES[0];
};
