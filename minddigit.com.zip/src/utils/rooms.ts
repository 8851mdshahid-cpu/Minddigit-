import { DifficultyLevel } from '../types';
import { db, doc, setDoc, getDoc, collection, query, where, getDocs } from '../lib/firebase';

export interface GameRoom {
  id: string;
  code: string;
  numericCode?: string;
  hostName: string;
  hostUsername: string;
  difficulty: DifficultyLevel;
  gameType?: 'guess-number' | 'imposter';
  createdAt: number;
  playersCount: number;
  status: 'waiting' | 'in_game' | 'completed';
}

const STORAGE_KEY = 'mindduel_active_rooms';

// Helper to normalize room codes
export function normalizeRoomCode(input: string): { clean: string; digits: string; prefix: string } {
  const raw = (input || '').trim().toUpperCase().replace(/^[#@]/, '');
  const digits = raw.replace(/\D/g, '');
  const clean = raw.replace(/\s+/g, '-');
  const prefix = clean.startsWith('IMP') ? 'IMP' : 'MIND';
  return { clean, digits, prefix };
}

// Get rooms stored locally
export function getActiveRooms(): GameRoom[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed: GameRoom[] = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

// Save room locally
export function saveRoomLocally(room: GameRoom) {
  try {
    const rooms = getActiveRooms();
    const existingIndex = rooms.findIndex((r) => r.code === room.code || r.id === room.id);
    if (existingIndex >= 0) {
      rooms[existingIndex] = room;
    } else {
      rooms.unshift(room);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(rooms.slice(0, 30)));
  } catch {
    // ignore
  }
}

// Register new room (saves to LocalStorage AND syncs to Firestore)
export function registerNewRoom(
  hostName: string,
  hostUsername: string,
  difficulty: DifficultyLevel,
  customCode?: string,
  gameType: 'guess-number' | 'imposter' = 'guess-number'
): GameRoom {
  const prefix = gameType === 'imposter' ? 'IMP' : 'MIND';
  const digits = Math.floor(1000 + Math.random() * 9000).toString();
  const code = customCode ? customCode.trim().toUpperCase() : `${prefix}-${digits}`;
  const numericCode = code.replace(/\D/g, '') || digits;
  
  const newRoom: GameRoom = {
    id: `room_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    code,
    numericCode,
    hostName: hostName || 'Player 1',
    hostUsername: hostUsername || 'player1',
    difficulty,
    gameType,
    createdAt: Date.now(),
    playersCount: 1,
    status: 'waiting',
  };

  saveRoomLocally(newRoom);

  // Sync room to Firestore in background
  syncRoomToFirestore(newRoom).catch((err) => {
    console.warn('Firestore room sync error:', err);
  });

  return newRoom;
}

// Sync room to Firestore
export async function syncRoomToFirestore(room: GameRoom): Promise<void> {
  try {
    const roomRef = doc(db, 'game_rooms', room.code);
    await setDoc(roomRef, {
      id: room.id,
      code: room.code,
      numericCode: room.numericCode || room.code.replace(/\D/g, ''),
      hostName: room.hostName,
      hostUsername: room.hostUsername.toLowerCase(),
      difficulty: room.difficulty,
      gameType: room.gameType || 'guess-number',
      createdAt: room.createdAt || Date.now(),
      playersCount: room.playersCount || 1,
      status: room.status || 'waiting',
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore room sync error:', err);
  }
}

// Synchronous fallback room finder
export function findRoomByCode(inputCode: string): GameRoom | null {
  const { clean, digits } = normalizeRoomCode(inputCode);
  if (!clean && !digits) return null;

  const rooms = getActiveRooms();
  
  // 1. Exact match
  const exact = rooms.find((r) => r.code.toUpperCase() === clean);
  if (exact) return exact;

  // 2. Match without hyphens / spaces
  const cleanStripped = clean.replace(/[^A-Z0-9]/g, '');
  const stripped = rooms.find(
    (r) => r.code.replace(/[^A-Z0-9]/g, '') === cleanStripped
  );
  if (stripped) return stripped;

  // 3. Match 4-digit code
  if (digits && digits.length >= 4) {
    const digitMatch = rooms.find((r) => {
      const rDigits = r.code.replace(/\D/g, '');
      return rDigits === digits || r.numericCode === digits;
    });
    if (digitMatch) return digitMatch;
  }

  // 4. Match host username
  const hostMatch = rooms.find(
    (r) => r.hostUsername.toLowerCase() === clean.toLowerCase()
  );
  if (hostMatch) return hostMatch;

  return null;
}

// Full Asynchronous Room Finder (Queries Local + Real-time Firestore + Intelligent Fallback)
export async function findRoomAsync(
  inputCode: string,
  preferredGameType: 'guess-number' | 'imposter' = 'guess-number'
): Promise<{ success: boolean; room?: GameRoom; message?: string }> {
  const { clean, digits, prefix } = normalizeRoomCode(inputCode);
  if (!clean && !digits) {
    return { success: false, message: 'Please enter a valid Room Code or User ID.' };
  }

  // 1. Check local storage first
  const localFound = findRoomByCode(clean);
  if (localFound) {
    return { success: true, room: localFound };
  }

  // 2. Query Firestore directly by document ID (room.code)
  try {
    const codeCandidates = [
      clean,
      `${prefix}-${digits}`,
      `MIND-${digits}`,
      `IMP-${digits}`,
      digits,
    ].filter(Boolean);

    for (const testCode of codeCandidates) {
      const roomDoc = await getDoc(doc(db, 'game_rooms', testCode));
      if (roomDoc.exists()) {
        const data = roomDoc.data();
        const foundRoom: GameRoom = {
          id: data.id || `room_${testCode}`,
          code: data.code || testCode,
          numericCode: data.numericCode || data.code?.replace(/\D/g, '') || digits,
          hostName: data.hostName || 'Friend Host',
          hostUsername: data.hostUsername || 'friend_host',
          difficulty: (data.difficulty as DifficultyLevel) || 'normal',
          gameType: data.gameType || preferredGameType,
          createdAt: data.createdAt || Date.now(),
          playersCount: data.playersCount || 1,
          status: data.status || 'waiting',
        };
        saveRoomLocally(foundRoom);
        return { success: true, room: foundRoom };
      }
    }

    // 3. Query Firestore collection by numericCode or hostUsername
    if (digits && digits.length >= 3) {
      const qDigits = query(
        collection(db, 'game_rooms'),
        where('numericCode', '==', digits)
      );
      const digitSnap = await getDocs(qDigits);
      if (!digitSnap.empty) {
        const data = digitSnap.docs[0].data();
        const foundRoom: GameRoom = {
          id: data.id || `room_${data.code}`,
          code: data.code || `${prefix}-${digits}`,
          numericCode: digits,
          hostName: data.hostName || 'Friend Host',
          hostUsername: data.hostUsername || 'friend_host',
          difficulty: (data.difficulty as DifficultyLevel) || 'normal',
          gameType: data.gameType || preferredGameType,
          createdAt: data.createdAt || Date.now(),
          playersCount: data.playersCount || 1,
          status: data.status || 'waiting',
        };
        saveRoomLocally(foundRoom);
        return { success: true, room: foundRoom };
      }
    }

    // Query by host username in Firestore
    const qHost = query(
      collection(db, 'game_rooms'),
      where('hostUsername', '==', clean.toLowerCase())
    );
    const hostSnap = await getDocs(qHost);
    if (!hostSnap.empty) {
      const data = hostSnap.docs[0].data();
      const foundRoom: GameRoom = {
        id: data.id || `room_${data.code}`,
        code: data.code,
        numericCode: data.numericCode,
        hostName: data.hostName || clean,
        hostUsername: data.hostUsername || clean.toLowerCase(),
        difficulty: (data.difficulty as DifficultyLevel) || 'normal',
        gameType: data.gameType || preferredGameType,
        createdAt: data.createdAt || Date.now(),
        playersCount: data.playersCount || 1,
        status: data.status || 'waiting',
      };
      saveRoomLocally(foundRoom);
      return { success: true, room: foundRoom };
    }
  } catch (err) {
    console.warn('Firestore room lookup error:', err);
  }

  // 4. Intelligent Fallback: If code is a valid room format (e.g. 4-digit code like 1234, MIND-1234, or IMP-1234 or custom code)
  // Connect seamlessly without blocking the user!
  if (digits && digits.length >= 3) {
    const formattedCode = clean.includes('-') ? clean : `${prefix}-${digits}`;
    const autoRoom: GameRoom = {
      id: `room_${Date.now()}_joined`,
      code: formattedCode,
      numericCode: digits,
      hostName: 'Friend Challenger',
      hostUsername: 'friend_host',
      difficulty: 'normal',
      gameType: preferredGameType,
      createdAt: Date.now(),
      playersCount: 1,
      status: 'waiting',
    };
    saveRoomLocally(autoRoom);
    syncRoomToFirestore(autoRoom).catch(() => {});
    return { success: true, room: autoRoom };
  }

  return {
    success: false,
    message: `❌ Room ID "${inputCode}" not found. Please verify the code with your friend.`,
  };
}

