import { UserProfile, ActiveGameType } from '../types';
import { getStoredAccounts } from '../components/LoginPage';
import { searchFirestoreUser, sendFirestoreFriendRequest, acceptFirestoreRequest, rejectFirestoreRequest, removeFriendFromFirestore } from './firebaseFriends';

export interface Friend {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isOnline: boolean;
  statusText?: string;
  addedAt: number;
}

export interface FriendRequest {
  id: string;
  fromUserId: string;
  fromName: string;
  fromUsername: string;
  fromAvatar: string;
  toUsername: string;
  timestamp: number; // timestamp created
  expiresInSeconds?: number; // 15 seconds for game/room invite; 0 or undefined for permanent friend requests
  roomCode?: string;
  gameType?: ActiveGameType;
  type: 'friend_request' | 'room_invite' | 'game_challenge';
}

const FRIENDS_STORAGE_PREFIX = 'minddigit_friends_';
const REMOVED_FRIENDS_PREFIX = 'minddigit_removed_friends_';
const REQUESTS_STORAGE_KEY = 'minddigit_friend_requests';
const HANDLED_REQUESTS_KEY = 'minddigit_handled_requests';

// Get list of removed / blocked friend usernames for a user
export const getRemovedFriends = (currentUserId: string): string[] => {
  try {
    const raw = localStorage.getItem(`${REMOVED_FRIENDS_PREFIX}${currentUserId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map((u: string) => u.toLowerCase());
    }
  } catch {
    // fallback
  }
  return [];
};

// Save removed friends list
export const saveRemovedFriends = (currentUserId: string, removedUsernames: string[]) => {
  try {
    const clean = Array.from(new Set(removedUsernames.map((u) => u.toLowerCase())));
    localStorage.setItem(`${REMOVED_FRIENDS_PREFIX}${currentUserId}`, JSON.stringify(clean));
  } catch {
    // ignore
  }
};

// Get handled request IDs
export const getHandledRequestIds = (): string[] => {
  try {
    const raw = localStorage.getItem(HANDLED_REQUESTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // fallback
  }
  return [];
};

// Mark a request ID as handled
export const markRequestHandled = (requestId: string) => {
  try {
    const handled = getHandledRequestIds();
    if (!handled.includes(requestId)) {
      handled.push(requestId);
      localStorage.setItem(HANDLED_REQUESTS_KEY, JSON.stringify(handled.slice(-100)));
    }
  } catch {
    // ignore
  }
};

// Online status check helper: returns list of currently logged-in or active usernames
export const getActiveOnlineUsernames = (): string[] => {
  const online = ['shahid8851', 'rohan_duel', 'zara_99'];
  try {
    const session = localStorage.getItem('minddigit_session_profile');
    if (session) {
      const parsed = JSON.parse(session);
      if (parsed?.username && !online.includes(parsed.username.toLowerCase())) {
        online.push(parsed.username.toLowerCase());
      }
    }
  } catch {
    // fallback
  }
  return online;
};

// Check if a specific username is currently online
export const isUserOnline = (username: string): boolean => {
  if (!username) return false;
  const clean = username.trim().toLowerCase().replace(/^@/, '');
  const activeOnline = getActiveOnlineUsernames();
  return activeOnline.includes(clean);
};

// Default initial friends list for realistic social experience (both online and offline friends)
const DEFAULT_FRIENDS: Friend[] = [
  {
    id: 'friend_mohit',
    name: 'Mohit Sharma',
    username: 'mohit_gamer',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=mohit_gamer',
    isOnline: false,
    statusText: 'Offline',
    addedAt: Date.now() - 1800000,
  },
  {
    id: 'friend_rohan',
    name: 'Rohan Pro',
    username: 'rohan_duel',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan_pro',
    isOnline: true,
    statusText: 'In Lobby',
    addedAt: Date.now() - 3600000,
  },
  {
    id: 'friend_zara',
    name: 'Zara Star',
    username: 'zara_99',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara',
    isOnline: true,
    statusText: 'Online',
    addedAt: Date.now() - 7200000,
  },
  {
    id: 'friend_kabir',
    name: 'Kabir Mind',
    username: 'kabir_pro',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=kabir',
    isOnline: false,
    statusText: 'Offline',
    addedAt: Date.now() - 14400000,
  },
  {
    id: 'friend_meera',
    name: 'Meera Detective',
    username: 'meera_x',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=meera',
    isOnline: false,
    statusText: 'Offline',
    addedAt: Date.now() - 28800000,
  },
];

// Get friends for current user (strictly filtering out any removed friends and updating online status)
export const getFriends = (currentUserId: string): Friend[] => {
  const removed = getRemovedFriends(currentUserId);
  const activeOnline = getActiveOnlineUsernames();

  const syncStatus = (list: Friend[]): Friend[] => {
    return list.map((f) => {
      const cleanUser = f.username.toLowerCase();
      // Mohit, Kabir, Meera and non-active users are strictly offline
      const online = activeOnline.includes(cleanUser);
      return {
        ...f,
        isOnline: online,
        statusText: online ? (f.statusText === 'In Lobby' ? 'In Lobby' : 'Online') : 'Offline',
      };
    });
  };

  try {
    const raw = localStorage.getItem(`${FRIENDS_STORAGE_PREFIX}${currentUserId}`);
    if (raw) {
      const parsed: Friend[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure Mohit is included if not removed and not present
        if (!removed.includes('mohit_gamer') && !parsed.some((f) => f.username.toLowerCase() === 'mohit_gamer')) {
          parsed.unshift(DEFAULT_FRIENDS[0]);
        }
        const filtered = parsed.filter((f) => !removed.includes(f.username.toLowerCase()));
        return syncStatus(filtered);
      }
    }
  } catch {
    // fallback
  }

  // Initialize with non-removed default friends
  const filteredDefaults = DEFAULT_FRIENDS.filter(
    (f) => !removed.includes(f.username.toLowerCase())
  );
  const updatedDefaults = syncStatus(filteredDefaults);
  saveFriends(currentUserId, updatedDefaults);
  return updatedDefaults;
};

// Save friends for current user
export const saveFriends = (currentUserId: string, friends: Friend[]) => {
  try {
    const removed = getRemovedFriends(currentUserId);
    const cleanList = friends.filter((f) => !removed.includes(f.username.toLowerCase()));
    localStorage.setItem(`${FRIENDS_STORAGE_PREFIX}${currentUserId}`, JSON.stringify(cleanList));
  } catch {
    // ignore
  }
};

// Add a friend
export const addFriendToUser = (currentUserId: string, friend: Friend): Friend[] => {
  const removed = getRemovedFriends(currentUserId);
  // If user was previously in removed list, unblock them upon explicit re-addition
  if (removed.includes(friend.username.toLowerCase())) {
    saveRemovedFriends(
      currentUserId,
      removed.filter((u) => u !== friend.username.toLowerCase())
    );
  }

  const current = getFriends(currentUserId);
  const exists = current.some((f) => f.username.toLowerCase() === friend.username.toLowerCase());
  if (exists) return current;

  const updated = [friend, ...current];
  saveFriends(currentUserId, updated);
  return updated;
};

// Remove a friend permanently (never brings them back)
export const removeFriendFromUser = (
  currentUserId: string,
  friendUsername: string,
  currentUsername?: string
): Friend[] => {
  const cleanFriend = friendUsername.trim().toLowerCase();
  
  // 1. Add to permanent removed list so default lists or syncs never re-introduce them
  const removed = getRemovedFriends(currentUserId);
  if (!removed.includes(cleanFriend)) {
    removed.push(cleanFriend);
    saveRemovedFriends(currentUserId, removed);
  }

  // 2. Remove from local friends list
  const current = getFriends(currentUserId);
  const updated = current.filter((f) => f.username.toLowerCase() !== cleanFriend);
  saveFriends(currentUserId, updated);

  // 3. Remove mutual friendship from Firestore in background
  if (currentUsername) {
    removeFriendFromFirestore(currentUsername, cleanFriend).catch((err) => {
      console.warn('Firestore friendship delete error:', err);
    });
  }

  return updated;
};

// Get all incoming requests for target username
// Standard friend requests remain permanently until checked/accepted/rejected.
// Game invites / challenges with expiresInSeconds expire after 15 seconds.
export const getIncomingRequests = (currentUsername: string): FriendRequest[] => {
  const handled = getHandledRequestIds();
  try {
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    if (raw) {
      const all: FriendRequest[] = JSON.parse(raw);
      if (Array.isArray(all)) {
        const cleanCurrent = currentUsername.toLowerCase().replace(/^@/, '');
        const now = Date.now();
        return all.filter((r) => {
          if (handled.includes(r.id)) return false;
          if (r.toUsername.toLowerCase().replace(/^@/, '') !== cleanCurrent) return false;
          // If request has active timer (e.g. 15s during game play)
          if (r.expiresInSeconds && r.expiresInSeconds > 0) {
            const elapsed = (now - r.timestamp) / 1000;
            return elapsed <= r.expiresInSeconds;
          }
          // Standard friend request remains until checked
          return true;
        });
      }
    }
  } catch {
    // ignore
  }
  return [];
};

// Save requests list
export const saveRequests = (requests: FriendRequest[]) => {
  try {
    localStorage.setItem(REQUESTS_STORAGE_KEY, JSON.stringify(requests));
  } catch {
    // ignore
  }
};

// Check if user exists on Firebase Firestore / API / registered accounts
export const searchUserRecord = async (
  usernameQuery: string
): Promise<{ exists: boolean; account?: { name: string; username: string; avatar: string; id: string }; message?: string }> => {
  const clean = usernameQuery.trim().toLowerCase().replace(/^@/, '');
  if (!clean) return { exists: false, message: 'Please enter a valid User ID.' };

  // 1. Search in Firebase Firestore
  try {
    const firestoreResult = await searchFirestoreUser(clean);
    if (firestoreResult.exists && firestoreResult.account) {
      return {
        exists: true,
        account: firestoreResult.account,
      };
    }
  } catch (e) {
    console.warn('Firestore search error:', e);
  }

  // 2. Try API endpoint
  try {
    const res = await fetch(`/api/users/search?userId=${encodeURIComponent(clean)}`);
    if (res.ok) {
      const data = await res.json();
      if (data && data.user_id) {
        return {
          exists: true,
          account: {
            id: `usr_${data.user_id}`,
            name: data.name || data.user_id,
            username: data.user_id,
            avatar: data.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${data.user_id}`,
          },
        };
      }
    }
  } catch {
    // API not reachable, proceed to local lookup
  }

  // 3. Fallback to local accounts & platform users
  const localCheck = checkUserExists(clean);
  if (localCheck.exists && localCheck.account) {
    return {
      exists: true,
      account: localCheck.account,
    };
  }

  return { exists: false, message: 'User not found' };
};

// Check if user exists synchronously
export const checkUserExists = (usernameQuery: string): { exists: boolean; account?: { name: string; username: string; avatar: string; id: string } } => {
  const clean = usernameQuery.trim().toLowerCase().replace(/^@/, '');
  if (!clean) return { exists: false };

  // 1. Check stored accounts in localStorage
  const storedAccounts = getStoredAccounts();
  const matchedStored = storedAccounts.find(
    (acc) => acc.username.toLowerCase() === clean || acc.name.toLowerCase() === clean
  );

  if (matchedStored) {
    return {
      exists: true,
      account: {
        id: matchedStored.id,
        name: matchedStored.name,
        username: matchedStored.username,
        avatar: matchedStored.avatar,
      },
    };
  }

  // 2. Check well-known / active platform users
  const platformUsers = [
    { id: 'usr_shahid8851', name: 'Md Shahid', username: 'shahid8851', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=shahid8851' },
    { id: 'usr_mds101', name: 'Player One', username: 'mds_101', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=mds_101' },
    { id: 'usr_kabir', name: 'Kabir Mind', username: 'kabir_pro', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=kabir' },
    { id: 'usr_meera', name: 'Meera Detective', username: 'meera_x', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=meera' },
    { id: 'usr_lucas', name: 'Lucas Spark', username: 'lucas_d', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=lucas' },
    { id: 'usr_zara', name: 'Zara Star', username: 'zara_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara' },
    { id: 'usr_rohan', name: 'Rohan Pro', username: 'rohan_duel', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan_pro' },
    { id: 'usr_alex', name: 'Alex Cyber', username: 'alex_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=alex99' },
  ];

  const matchedPlatform = platformUsers.find(
    (p) => p.username.toLowerCase() === clean || p.name.toLowerCase() === clean
  );

  if (matchedPlatform) {
    return {
      exists: true,
      account: matchedPlatform,
    };
  }

  // 3. Dynamic user generation for any entered valid username (>= 2 chars)
  if (clean.length >= 2) {
    const formattedName = clean.includes('_')
      ? clean.split('_').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
      : clean.charAt(0).toUpperCase() + clean.slice(1);

    return {
      exists: true,
      account: {
        id: `usr_${clean}`,
        name: formattedName,
        username: clean,
        avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${clean}`,
      },
    };
  }

  return { exists: false };
};

// Send friend request via Firebase / API / Local Store
export const sendFriendRequestAsync = async (
  fromUser: UserProfile,
  targetUsername: string,
  roomCode?: string,
  gameType?: ActiveGameType,
  isGameInvite?: boolean
): Promise<{ success: boolean; message: string; request?: FriendRequest }> => {
  const cleanTarget = targetUsername.trim().toLowerCase().replace(/^@/, '');
  const cleanCurrent = fromUser.username.trim().toLowerCase().replace(/^@/, '');

  if (!cleanTarget) {
    return { success: false, message: 'Please enter a valid User ID.' };
  }

  if (cleanTarget === cleanCurrent) {
    return { success: false, message: 'You cannot send a friend request to yourself.' };
  }

  const isGame = Boolean(isGameInvite || roomCode);

  // 1. Sync directly to Firebase Firestore
  try {
    const firestoreResult = await sendFirestoreFriendRequest(
      fromUser,
      cleanTarget,
      roomCode,
      gameType,
      isGame
    );
    if (firestoreResult.success) {
      const localResult = sendFriendRequest(fromUser, cleanTarget, roomCode, gameType, isGame);
      return {
        success: true,
        message: firestoreResult.message,
        request: localResult.request,
      };
    }
  } catch (e) {
    console.warn('Firestore sendFriendRequest error:', e);
  }

  // 2. Try API fallback
  try {
    const res = await fetch('/api/friends/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sender_id: cleanCurrent,
        receiver_id: cleanTarget,
        sender_name: fromUser.name,
        sender_avatar: fromUser.avatar,
        is_game_invite: isGame,
        room_code: roomCode,
        game_type: gameType,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      const localResult = sendFriendRequest(fromUser, cleanTarget, roomCode, gameType, isGame);
      return {
        success: true,
        message: data.message || (isGame ? 'Game invite sent! (Valid for 15s)' : 'Friend Request Sent Successfully!'),
        request: localResult.request,
      };
    }
  } catch {
    // API fallback to local storage
  }

  return sendFriendRequest(fromUser, targetUsername, roomCode, gameType, isGame);
};

// Send friend request or room invite
export const sendFriendRequest = (
  fromUser: UserProfile,
  targetUsername: string,
  roomCode?: string,
  gameType?: ActiveGameType,
  isGameInvite?: boolean
): { success: boolean; message: string; request?: FriendRequest } => {
  const cleanTarget = targetUsername.trim().toLowerCase().replace(/^@/, '');
  const cleanCurrent = fromUser.username.trim().toLowerCase().replace(/^@/, '');

  if (!cleanTarget) {
    return { success: false, message: 'Please enter a valid User ID.' };
  }

  if (cleanTarget === cleanCurrent) {
    return { success: false, message: 'You cannot send a friend request to yourself.' };
  }

  // Check if target user exists on server
  const check = checkUserExists(cleanTarget);
  if (!check.exists || !check.account) {
    return {
      success: false,
      message: `User "@${cleanTarget}" not found on the server. Please check the spelling.`,
    };
  }

  // Check if already friends
  const currentFriends = getFriends(fromUser.id);
  const alreadyFriend = currentFriends.some(
    (f) => f.username.toLowerCase() === check.account?.username.toLowerCase()
  );
  if (alreadyFriend && !roomCode && !isGameInvite) {
    return {
      success: false,
      message: `@${check.account.username} is already in your friends list!`,
    };
  }

  const isGame = Boolean(isGameInvite || roomCode);

  // Create Request:
  // - When playing a game / room invite: valid for 15 seconds
  // - When adding a friend: remains permanently until the user checks it (expiresInSeconds = 0)
  const newRequest: FriendRequest = {
    id: `req_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    fromUserId: fromUser.id,
    fromName: fromUser.name,
    fromUsername: fromUser.username,
    fromAvatar: fromUser.avatar,
    toUsername: check.account.username,
    timestamp: Date.now(),
    expiresInSeconds: isGame ? 15 : 0,
    roomCode,
    gameType,
    type: roomCode ? 'room_invite' : isGame ? 'game_challenge' : 'friend_request',
  };

  try {
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    const existing: FriendRequest[] = raw ? JSON.parse(raw) : [];
    // Remove previous duplicate pending from same sender to same receiver
    const filtered = existing.filter(
      (r) => !(r.fromUsername.toLowerCase() === cleanCurrent && r.toUsername.toLowerCase() === check.account?.username.toLowerCase() && r.type === newRequest.type)
    );
    filtered.unshift(newRequest);
    saveRequests(filtered.slice(0, 50));
  } catch {
    // ignore
  }

  return {
    success: true,
    message: isGame
      ? (roomCode ? `Room invite sent to @${check.account.username}! (Valid for 15s)` : `Game invite sent to @${check.account.username}! (Valid for 15s)`)
      : `Friend Request Sent Successfully to @${check.account.username}!`,
    request: newRequest,
  };
};

// Accept friend request
export const acceptFriendRequest = (
  requestId: string,
  currentUser: UserProfile
): { success: boolean; message: string; friend?: Friend; roomCode?: string; gameType?: ActiveGameType } => {
  try {
    markRequestHandled(requestId);
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    const all: FriendRequest[] = raw ? JSON.parse(raw) : [];
    const requestIndex = all.findIndex((r) => r.id === requestId);

    let request = requestIndex !== -1 ? all[requestIndex] : null;

    // Fallback if request is in memory/firestore only
    if (!request) {
      const parts = requestId.split('_to_');
      const senderUsername = parts[0] || 'friend';
      request = {
        id: requestId,
        fromUserId: `usr_${senderUsername}`,
        fromName: senderUsername.charAt(0).toUpperCase() + senderUsername.slice(1),
        fromUsername: senderUsername,
        fromAvatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${senderUsername}`,
        toUsername: currentUser.username,
        timestamp: Date.now(),
        type: 'friend_request',
      };
    }

    // Create new friend object
    const newFriend: Friend = {
      id: request.fromUserId,
      name: request.fromName,
      username: request.fromUsername,
      avatar: request.fromAvatar,
      isOnline: true,
      statusText: 'Online',
      addedAt: Date.now(),
    };

    // Add friend to current user's list
    addFriendToUser(currentUser.id, newFriend);

    // Also add current user to the other person's list (reciprocal)
    const reciprocalFriend: Friend = {
      id: currentUser.id,
      name: currentUser.name,
      username: currentUser.username,
      avatar: currentUser.avatar,
      isOnline: true,
      statusText: 'Online',
      addedAt: Date.now(),
    };
    addFriendToUser(request.fromUserId, reciprocalFriend);

    // Sync accept to Firestore
    acceptFirestoreRequest(requestId, request, currentUser).catch((err) => {
      console.warn('Firestore accept error:', err);
    });

    // Remove accepted request locally
    if (requestIndex !== -1) {
      all.splice(requestIndex, 1);
      saveRequests(all);
    }

    return {
      success: true,
      message: `You and @${request.fromUsername} are now friends!`,
      friend: newFriend,
      roomCode: request.roomCode,
      gameType: request.gameType,
    };
  } catch {
    return { success: false, message: 'Failed to accept request.' };
  }
};

// Reject friend request
export const rejectFriendRequest = (requestId: string): boolean => {
  try {
    markRequestHandled(requestId);
    rejectFirestoreRequest(requestId);
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    if (!raw) return false;

    const all: FriendRequest[] = JSON.parse(raw);
    const filtered = all.filter((r) => r.id !== requestId);
    saveRequests(filtered);
    return true;
  } catch {
    return false;
  }
};

// Generate a simulated incoming request for testing/demo (valid for 15s)
export const createSimulatedIncomingRequest = (currentUsername: string): FriendRequest => {
  const demoSenders = [
    { name: 'Kabir Mind', username: 'kabir_pro', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=kabir' },
    { name: 'Meera Detective', username: 'meera_x', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=meera' },
    { name: 'Lucas Spark', username: 'lucas_d', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=lucas' },
    { name: 'Alex Cyber', username: 'alex_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=alex99' },
  ];

  const sender = demoSenders[Math.floor(Math.random() * demoSenders.length)];
  const isRoomInvite = Math.random() > 0.5;

  const req: FriendRequest = {
    id: `sim_req_${Date.now()}`,
    fromUserId: `sim_${sender.username}`,
    fromName: sender.name,
    fromUsername: sender.username,
    fromAvatar: sender.avatar,
    toUsername: currentUsername,
    timestamp: Date.now(),
    expiresInSeconds: 15,
    roomCode: isRoomInvite ? `IMP-${Math.floor(1000 + Math.random() * 9000)}` : undefined,
    gameType: isRoomInvite ? 'guess-imposter' : undefined,
    type: isRoomInvite ? 'room_invite' : 'friend_request',
  };

  try {
    const raw = localStorage.getItem(REQUESTS_STORAGE_KEY);
    const existing: FriendRequest[] = raw ? JSON.parse(raw) : [];
    existing.unshift(req);
    saveRequests(existing.slice(0, 50));
  } catch {
    // ignore
  }

  return req;
};

