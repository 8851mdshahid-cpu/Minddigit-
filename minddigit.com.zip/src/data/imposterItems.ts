import { ImposterItemPair } from '../types';

export const IMPOSTER_ITEM_PAIRS: ImposterItemPair[] = [
  {
    id: 'item-fruits-lemon-banana',
    category: 'Fruits & Food',
    majorityItem: 'Lemon',
    majorityEmoji: '🍋',
    imposterItem: 'Banana',
    imposterEmoji: '🍌',
    sampleClues: {
      majority: [
        'This is very sour and juicy.',
        'People squeeze this into water in hot summer.',
        'It has a yellow textured skin and tangy citrus flavor.',
        'Great with tea, salads, and drinks.',
      ],
      imposter: [
        'It is a soft, sweet yellow fruit.',
        'You peel it before eating and it is rich in potassium.',
        'Monkeys famously love this snack.',
        'It is long, curved, and very sweet.',
      ],
    },
  },
  {
    id: 'item-drinks-coffee-tea',
    category: 'Hot Beverages',
    majorityItem: 'Coffee',
    majorityEmoji: '☕',
    imposterItem: 'Tea',
    imposterEmoji: '🍵',
    sampleClues: {
      majority: [
        'Brewed from dark roasted aromatic beans.',
        'Gives an instant caffeine boost in early mornings.',
        'Can be served as espresso, latte, or cappuccino.',
        'Has a rich, slightly bitter dark taste.',
      ],
      imposter: [
        'Brewed by steeping dried herbal leaves in boiling water.',
        'Very popular in Asian and British cultures.',
        'Can be green, black, or herbal with mint.',
        'Often enjoyed with a tea bag and honey.',
      ],
    },
  },
  {
    id: 'item-food-pizza-burger',
    category: 'Fast Food',
    majorityItem: 'Pizza',
    majorityEmoji: '🍕',
    imposterItem: 'Burger',
    imposterEmoji: '🍔',
    sampleClues: {
      majority: [
        'Baked round dough with melted mozzarella cheese.',
        'Sliced into triangular pieces in a cardboard box.',
        'Classic toppings include tomato sauce and herbs.',
        'Very popular at weekend parties.',
      ],
      imposter: [
        'Has a grilled patty between two soft sesame buns.',
        'Usually served with crunchy French fries and ketchup.',
        'Can have layers of lettuce, tomato, and cheese.',
        'A handheld sandwich meal.',
      ],
    },
  },
  {
    id: 'item-travel-airplane-rocket',
    category: 'Aviation & Space',
    majorityItem: 'Airplane',
    majorityEmoji: '✈️',
    imposterItem: 'Rocket',
    imposterEmoji: '🚀',
    sampleClues: {
      majority: [
        'Flies commercial passengers across cities with two wings.',
        'Takes off and lands on international airport runways.',
        'Pilots fly it high inside the clouds.',
        'Has windows along the sides and seats for hundreds.',
      ],
      imposter: [
        'Blasts vertically up with immense fire and thrust.',
        'Leaves Earths atmosphere to reach outer space.',
        'Astronauts ride this to the Moon or Mars.',
        'Has massive booster engines that detach.',
      ],
    },
  },
  {
    id: 'item-music-guitar-piano',
    category: 'Music Instruments',
    majorityItem: 'Guitar',
    majorityEmoji: '🎸',
    imposterItem: 'Piano',
    imposterEmoji: '🎹',
    sampleClues: {
      majority: [
        'Has six strings and you strum or pluck them.',
        'Very common in rock, pop, and acoustic campfire songs.',
        'Can be acoustic or electric with an amplifier.',
        'You hold it with a strap across your shoulder.',
      ],
      imposter: [
        'Has 88 black and white keys pressed with fingers.',
        'Large wooden instrument standing with pedals below.',
        'Famous classical composers wrote masterpieces on it.',
        'Produces sound when felt hammers strike internal strings.',
      ],
    },
  },
  {
    id: 'item-pets-cat-dog',
    category: 'Household Pets',
    majorityItem: 'Cat',
    majorityEmoji: '🐱',
    imposterItem: 'Dog',
    imposterEmoji: '🐶',
    sampleClues: {
      majority: [
        'Purrs softly when petted and walks silently.',
        'Very agile climber with sharp retractable claws.',
        'Says meow and loves napping in sunbeams.',
        'Often chases laser pointers and mice.',
      ],
      imposter: [
        'Barks joyfully and wags its tail when greeting you.',
        'Loves going on outdoor walks and catching tennis balls.',
        'Known as human’s most loyal best friend.',
        'Can learn tricks like sit, stay, and roll over.',
      ],
    },
  },
  {
    id: 'item-weather-rain-snow',
    category: 'Weather Nature',
    majorityItem: 'Rain',
    majorityEmoji: '🌧️',
    imposterItem: 'Snow',
    imposterEmoji: '❄️',
    sampleClues: {
      majority: [
        'Liquid water droplets falling down from gray clouds.',
        'You open an umbrella or wear a raincoat.',
        'Creates puddles on the ground and fresh earthy smell.',
        'Helps plants and trees grow green.',
      ],
      imposter: [
        'Soft white frozen ice crystals falling quietly in winter.',
        'Kids use this to build snowmen and throw snowballs.',
        'Covers the landscape in a cold white blanket.',
        'Melts into liquid when the temperature rises.',
      ],
    },
  },
  {
    id: 'item-tech-laptop-phone',
    category: 'Gadgets',
    majorityItem: 'Laptop',
    majorityEmoji: '💻',
    imposterItem: 'Smartphone',
    imposterEmoji: '📱',
    sampleClues: {
      majority: [
        'Opens up like a clamshell with a physical keyboard.',
        'Placed on a work desk or lap for coding and typing.',
        'Has a trackpad and USB ports on the sides.',
        'Runs desktop software and full browser windows.',
      ],
      imposter: [
        'Fits conveniently right inside your pocket.',
        'You swipe and tap on the glass touch screen.',
        'Used to call people, text on WhatsApp, and take photos.',
        'Has front and rear cameras and mobile cellular connection.',
      ],
    },
  },
];
