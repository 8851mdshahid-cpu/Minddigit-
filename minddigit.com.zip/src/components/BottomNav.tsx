import React from 'react';
import { Home, MessageCircle, UserPlus, Plus } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';

interface BottomNavProps {
  currentTab: 'home' | 'chat' | 'profile';
  onSelectTab: (tab: 'home' | 'chat' | 'profile') => void;
  user: UserProfile;
  onOpenAddFriend?: () => void;
  pendingRequestsCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  user,
  onOpenAddFriend,
  pendingRequestsCount = 0,
}) => {
  const userInitial = user.name ? user.name.trim().charAt(0).toUpperCase() : 'M';

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-lg border-t border-slate-200/80 px-4 py-1.5 shadow-lg">
      <div className="max-w-md mx-auto flex items-center justify-around">
        
        {/* 1. HOME TAB */}
        <button
          id="bottom-tab-home"
          type="button"
          onClick={() => {
            sound.playClick();
            onSelectTab('home');
          }}
          className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === 'home'
              ? 'text-blue-600 font-extrabold scale-105'
              : 'text-slate-500 hover:text-blue-600 font-semibold'
          }`}
        >
          <Home className={`w-5 h-5 ${currentTab === 'home' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[10px] tracking-wider uppercase">Home</span>
        </button>

        {/* 2. ADD FRIEND (+) PROMINENT BUTTON IN OPEN NAVIGATION */}
        <button
          id="bottom-tab-add-friend"
          type="button"
          onClick={() => {
            sound.playPop();
            if (onOpenAddFriend) onOpenAddFriend();
          }}
          className="flex flex-col items-center justify-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer text-indigo-600 hover:text-indigo-800 group relative"
          title="Add Friend (+)"
        >
          <div className="relative">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/25 group-hover:scale-110 transition-transform">
              <Plus className="w-5 h-5 stroke-[3]" />
            </div>
            {pendingRequestsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 text-white rounded-full text-[8px] font-black flex items-center justify-center animate-pulse">
                {pendingRequestsCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-black tracking-wider uppercase text-indigo-600">
            Add Friend
          </span>
        </button>

        {/* 3. CHAT TAB */}
        <button
          id="bottom-tab-chat"
          type="button"
          onClick={() => {
            sound.playPop();
            onSelectTab('chat');
          }}
          className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === 'chat'
              ? 'text-emerald-500 font-extrabold scale-105'
              : 'text-emerald-600/90 hover:text-emerald-500 font-semibold'
          }`}
        >
          <MessageCircle className={`w-5 h-5 ${currentTab === 'chat' ? 'stroke-[2.5] fill-emerald-50' : 'stroke-2'}`} />
          <span className="text-[10px] tracking-wider uppercase text-emerald-600">Chat</span>
        </button>

        {/* 4. PROFILE TAB */}
        <button
          id="bottom-tab-profile"
          type="button"
          onClick={() => {
            sound.playPop();
            onSelectTab('profile');
          }}
          className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 rounded-xl transition-all cursor-pointer ${
            currentTab === 'profile'
              ? 'text-amber-700 font-extrabold scale-105'
              : 'text-amber-600/90 hover:text-amber-700 font-semibold'
          }`}
        >
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-stone-700 to-stone-900 border border-amber-300 flex items-center justify-center text-white text-[9px] font-black shadow-xs">
            {userInitial}
          </div>
          <span className="text-[10px] tracking-wider uppercase text-amber-600">Profile</span>
        </button>

      </div>
    </nav>
  );
};
