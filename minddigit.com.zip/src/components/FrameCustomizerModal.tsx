import React from 'react';
import { X, Check, Sparkles, Palette, Crown, Shield } from 'lucide-react';
import { UserProfile } from '../types';
import { AVATAR_FRAMES, AvatarFrame } from '../utils/frames';
import { sound } from '../utils/audio';

interface FrameCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onSelectFrame: (frameId: string) => void;
}

export const FrameCustomizerModal: React.FC<FrameCustomizerModalProps> = ({
  isOpen,
  onClose,
  user,
  onSelectFrame,
}) => {
  if (!isOpen) return null;

  const currentFrameId = user.avatarFrame || 'default';
  const userInitial = user.name ? user.name.trim().charAt(0).toUpperCase() : 'M';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-md bg-white rounded-[32px] p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-tr from-amber-500 to-yellow-400 rounded-xl text-white shadow-xs">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">चेंज फ्रेम (Avatar Frames)</h2>
              <p className="text-[11px] text-slate-500">Select an avatar border & frame style</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Preview of Current Selected Frame */}
        <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl p-4 mb-4 text-center text-white flex flex-col items-center justify-center border border-slate-800 shadow-inner">
          <div className="relative mb-2">
            {/* Avatar with current frame */}
            {(() => {
              const activeFrame = AVATAR_FRAMES.find((f) => f.id === currentFrameId) || AVATAR_FRAMES[0];
              return (
                <div className={`relative w-20 h-20 rounded-full flex items-center justify-center bg-stone-900 text-amber-300 font-serif font-black text-3xl transition-all duration-300 ${activeFrame.borderClass}`}>
                  <span>{userInitial}</span>
                  {activeFrame.badgeEmoji && (
                    <span className="absolute -top-2.5 -right-2 text-xl drop-shadow-md animate-bounce">
                      {activeFrame.badgeEmoji}
                    </span>
                  )}
                  <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-1 border-2 border-white shadow-xs flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3.5]" />
                  </div>
                </div>
              );
            })()}
          </div>
          <div className="text-sm font-black text-white">{user.name}</div>
          <div className="text-xs font-mono text-cyan-300">@{user.username}</div>
          <div className="text-[10px] text-amber-300/90 mt-1 font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            <span>Active Frame: {AVATAR_FRAMES.find((f) => f.id === currentFrameId)?.name}</span>
          </div>
        </div>

        {/* Frame Selection Options */}
        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          {AVATAR_FRAMES.map((frame: AvatarFrame) => {
            const isSelected = currentFrameId === frame.id;
            return (
              <button
                key={frame.id}
                type="button"
                onClick={() => {
                  sound.playPop();
                  onSelectFrame(frame.id);
                }}
                className={`w-full p-3 rounded-2xl border transition-all text-left flex items-center justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-amber-50/80 border-amber-400 ring-2 ring-amber-300 shadow-sm'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full bg-slate-900 text-white font-serif font-bold text-sm flex items-center justify-center shrink-0 ${frame.borderClass}`}>
                    <span>{frame.icon}</span>
                  </div>
                  <div>
                    <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <span>{frame.hindiName}</span>
                      <span className="text-[10px] font-mono text-slate-500 font-normal">({frame.name})</span>
                    </div>
                    <div className="text-[11px] text-slate-500 leading-tight mt-0.5">{frame.description}</div>
                  </div>
                </div>

                <div className="shrink-0 ml-2">
                  {isSelected ? (
                    <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-xs">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-full border-2 border-slate-300" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Done button */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl active:scale-98 transition-all cursor-pointer shadow-md"
          >
            Save & Close (सेव करें)
          </button>
        </div>

      </div>
    </div>
  );
};
