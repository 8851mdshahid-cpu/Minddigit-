import React, { useRef } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface PinInputProps {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  length?: number;
  label?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  showToggleMask?: boolean;
}

export const PinInput: React.FC<PinInputProps> = ({
  id = 'mpin-input',
  value,
  onChange,
  length = 6,
  label,
  disabled = false,
  autoFocus = false,
  showToggleMask = true,
}) => {
  const [isMasked, setIsMasked] = React.useState(true);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const digits = value.split('').slice(0, length);
  while (digits.length < length) {
    digits.push('');
  }

  const handleChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const char = e.target.value.replace(/[^0-9]/g, '').slice(-1);
    const newDigits = [...digits];
    newDigits[index] = char;
    const newValue = newDigits.join('');
    onChange(newValue);

    // Auto-focus next input if digit entered
    if (char && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!digits[index] && index > 0) {
        const newDigits = [...digits];
        newDigits[index - 1] = '';
        onChange(newDigits.join(''));
        inputRefs.current[index - 1]?.focus();
      } else {
        const newDigits = [...digits];
        newDigits[index] = '';
        onChange(newDigits.join(''));
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < length - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/[^0-9]/g, '').slice(0, length);
    if (pasted) {
      onChange(pasted);
      const nextFocus = Math.min(pasted.length, length - 1);
      inputRefs.current[nextFocus]?.focus();
    }
  };

  return (
    <div className="space-y-1.5 w-full">
      {label && (
        <div className="flex items-center justify-between px-1">
          <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
            {label}
          </label>
          {showToggleMask && (
            <button
              type="button"
              onClick={() => setIsMasked(!isMasked)}
              className="text-[11px] text-slate-400 hover:text-blue-600 font-semibold flex items-center gap-1 cursor-pointer transition-colors"
            >
              {isMasked ? (
                <>
                  <Eye className="w-3.5 h-3.5" />
                  <span>Show PIN</span>
                </>
              ) : (
                <>
                  <EyeOff className="w-3.5 h-3.5" />
                  <span>Hide PIN</span>
                </>
              )}
            </button>
          )}
        </div>
      )}

      {/* Digit Boxes */}
      <div className="flex items-center justify-center gap-1 sm:gap-2 w-full">
        {Array.from({ length }).map((_, index) => {
          const digit = digits[index] || '';
          const isFilled = Boolean(digit);

          return (
            <input
              key={index}
              ref={(el) => {
                inputRefs.current[index] = el;
              }}
              id={`${id}-digit-${index}`}
              type={isMasked ? 'password' : 'text'}
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={1}
              value={digit}
              disabled={disabled}
              autoFocus={autoFocus && index === 0}
              onChange={(e) => handleChange(index, e)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onPaste={handlePaste}
              onFocus={(e) => e.target.select()}
              className={`flex-1 min-w-[34px] max-w-[48px] h-11 sm:h-12 text-center text-lg sm:text-2xl font-black font-mono rounded-2xl border transition-all outline-none cursor-pointer ${
                isFilled
                  ? 'bg-blue-50/80 border-blue-500 text-blue-900 shadow-xs ring-1 ring-blue-500/30'
                  : 'bg-slate-50 border-slate-200 text-slate-800 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20'
              }`}
            />
          );
        })}
      </div>
    </div>
  );
};
