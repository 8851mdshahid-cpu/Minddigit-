import React, { useState, useEffect } from 'react';
import { ArrowLeft, Trophy, Brain, RefreshCw, Coins, Sparkles, Check, X } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';

interface GamePatternMatrixProps {
  user: UserProfile;
  onBack: () => void;
  onGameEnd: (won: boolean, scoreGained: number, coinsGained: number) => void;
}

export const GamePatternMatrix: React.FC<GamePatternMatrixProps> = ({
  user,
  onBack,
  onGameEnd,
}) => {
  const [level, setLevel] = useState<number>(1);
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [activeTile, setActiveTile] = useState<number | null>(null);
  const [isDisplaying, setIsDisplaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [gameWon, setGameWon] = useState<boolean>(false);

  // Generate sequence for current level
  const startLevel = (currentLevel: number) => {
    setIsDisplaying(true);
    setUserSequence([]);
    const seqLength = currentLevel + 2;
    const newSeq: number[] = [];
    for (let i = 0; i < seqLength; i++) {
      newSeq.push(Math.floor(Math.random() * 4));
    }
    setSequence(newSeq);

    // Playback sequence
    let step = 0;
    const interval = setInterval(() => {
      if (step < newSeq.length) {
        const tile = newSeq[step];
        setActiveTile(tile);
        sound.playPop();
        setTimeout(() => setActiveTile(null), 350);
        step++;
      } else {
        clearInterval(interval);
        setIsDisplaying(false);
      }
    }, 600);
  };

  useEffect(() => {
    startLevel(1);
  }, []);

  const handleTileClick = (index: number) => {
    if (isDisplaying || isGameOver) return;
    sound.playClick();
    setActiveTile(index);
    setTimeout(() => setActiveTile(null), 200);

    const nextUserSeq = [...userSequence, index];
    setUserSequence(nextUserSeq);

    // Check correctness
    const currentStep = nextUserSeq.length - 1;
    if (nextUserSeq[currentStep] !== sequence[currentStep]) {
      // Wrong move!
      sound.playLose();
      setIsGameOver(true);
      setGameWon(false);
      onGameEnd(false, (level - 1) * 10, 2);
      return;
    }

    // Check if completed sequence
    if (nextUserSeq.length === sequence.length) {
      sound.playWin();
      if (level >= 5) {
        // Won the full game!
        setIsGameOver(true);
        setGameWon(true);
        onGameEnd(true, 100, 25);
      } else {
        // Next level
        setTimeout(() => {
          setLevel((l) => l + 1);
          startLevel(level + 1);
        }, 600);
      }
    }
  };

  const colors = [
    'from-rose-500 to-red-600 border-rose-400',
    'from-blue-500 to-indigo-600 border-blue-400',
    'from-amber-400 to-orange-500 border-amber-300',
    'from-emerald-400 to-teal-600 border-emerald-300',
  ];

  return (
    <div className="w-full max-w-sm bg-white/90 backdrop-blur-md rounded-3xl p-5 shadow-xl border border-white flex flex-col items-center select-none animate-in fade-in duration-200">
      
      {/* Top Header */}
      <div className="w-full flex items-center justify-between mb-4">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 px-3 py-1 bg-purple-100 text-purple-900 rounded-full font-black text-xs">
          <Brain className="w-3.5 h-3.5 text-purple-600" />
          <span>PATTERN MATRIX</span>
        </div>

        <div className="flex items-center gap-1 font-mono font-black text-sm bg-purple-50 px-2.5 py-1 rounded-xl text-purple-900 border border-purple-200">
          <span>Level {level}/5</span>
        </div>
      </div>

      {!isGameOver ? (
        <div className="w-full flex flex-col items-center">
          
          <div className="text-xs font-bold text-slate-600 mb-3 text-center">
            {isDisplaying ? (
              <span className="text-purple-600 animate-pulse font-black">👀 Memorize the Pattern Sequence...</span>
            ) : (
              <span className="text-emerald-700 font-black">✨ Repeat the Sequence! ({userSequence.length}/{sequence.length})</span>
            )}
          </div>

          {/* 2x2 Matrix Board */}
          <div className="grid grid-cols-2 gap-3 w-full p-2 max-w-[280px]">
            {[0, 1, 2, 3].map((idx) => {
              const isActive = activeTile === idx;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleTileClick(idx)}
                  disabled={isDisplaying}
                  className={`h-28 rounded-2xl bg-gradient-to-br ${colors[idx]} border-2 shadow-md transition-all cursor-pointer flex items-center justify-center text-3xl font-black text-white ${
                    isActive
                      ? 'scale-105 brightness-125 ring-4 ring-white shadow-xl'
                      : 'opacity-90 hover:opacity-100 active:scale-95'
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>

        </div>
      ) : (
        /* Game Over / Victory */
        <div className="w-full flex flex-col items-center text-center py-4 animate-in zoom-in-95 duration-200">
          <div className="text-5xl mb-2">{gameWon ? '👑' : '🧩'}</div>
          <h3 className="text-xl font-black text-slate-900">
            {gameWon ? 'Master Mind Unlocked!' : 'Pattern Misstep!'}
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            {gameWon ? 'You cleared all 5 pattern memory rounds!' : `You reached Level ${level} out of 5.`}
          </p>

          <div className="my-4 p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-500 fill-amber-400" />
            <span className="text-sm font-black text-amber-900">
              +{gameWon ? 25 : 5} Tokens Earned!
            </span>
          </div>

          <div className="flex gap-2 w-full mt-2">
            <button
              type="button"
              onClick={() => {
                sound.playPop();
                setLevel(1);
                setIsGameOver(false);
                setGameWon(false);
                startLevel(1);
              }}
              className="flex-1 py-3 bg-purple-600 text-white font-black rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md hover:bg-purple-700 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>TRY AGAIN</span>
            </button>

            <button
              type="button"
              onClick={() => {
                sound.playClick();
                onBack();
              }}
              className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer transition-colors"
            >
              EXIT
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
