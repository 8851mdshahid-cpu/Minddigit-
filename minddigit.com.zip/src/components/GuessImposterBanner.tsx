import React, { useState } from 'react';
import { Play, ArrowRight, Mic, Users, Radio, Coins, Volume2, ShieldCheck, HelpCircle } from 'lucide-react';
import { sound } from '../utils/audio';

interface GuessImposterBannerProps {
  onPlayClick: () => void;
  userTokens?: number;
}

export const GuessImposterBanner: React.FC<GuessImposterBannerProps> = ({
  onPlayClick,
  userTokens = 150,
}) => {
  const [showDetails, setShowDetails] = useState(false);

  const handleCardClick = () => {
    sound.playPop();
    setShowDetails((prev) => !prev);
  };

  const handlePlayAction = (e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playPop();
    onPlayClick();
  };

  return (
    <div
      id="guess-imposter-game-card"
      onClick={handleCardClick}
      className="group relative w-full bg-white/85 backdrop-blur-md rounded-3xl overflow-hidden cursor-pointer border border-white shadow-lg hover:shadow-xl transition-all duration-300 select-none"
    >
      {/* Geometric gradient backdrop overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 via-rose-500/5 to-amber-500/10 pointer-events-none" />

      <div className="relative p-5 sm:p-6 flex flex-col z-10">
        
        {/* Upper Main Hero Section */}
        <div className="flex flex-col items-center text-center gap-4">
          
          <div className="flex items-center justify-between w-full">
            <span className="text-purple-600 font-black tracking-widest text-[10px] uppercase px-2.5 py-1 bg-purple-100/70 rounded-full border border-purple-200">
              🎙️ NEW VOICE GAME
            </span>
            <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 shadow-2xs flex items-center gap-1">
              <Coins className="w-3 h-3 text-amber-500 fill-amber-400" />
              <span>Win up to +50 🪙</span>
            </span>
          </div>

          {/* Imposter Visual Badge */}
          <div className="relative flex items-center justify-center my-1">
            <div className="w-36 h-36 bg-white/70 backdrop-blur-sm rounded-3xl -rotate-6 flex items-center justify-center shadow-md border border-white group-hover:rotate-0 transition-transform duration-300 relative">
              <div className="w-24 h-24 bg-gradient-to-br from-purple-600 via-indigo-600 to-slate-900 rounded-2xl shadow-xl flex flex-col items-center justify-center rotate-6 group-hover:rotate-0 transition-transform duration-300">
                <span className="text-4xl leading-none mb-1">
                  🎭
                </span>
                <span className="text-[9px] font-black text-purple-200 uppercase tracking-widest">
                  3P • 1 Imposter
                </span>
              </div>

              {/* Floating Voice Wave Badge */}
              <div className="absolute -bottom-2 -right-2 bg-white px-2 py-1 rounded-xl shadow-md border border-purple-100 flex items-center gap-1 text-[10px] font-black text-purple-700">
                <Mic className="w-3 h-3 text-purple-600 animate-pulse" />
                <span>Live Mic</span>
              </div>
            </div>
          </div>

          {/* Text & Info */}
          <div className="flex flex-col items-center text-center w-full">
            <h2 className="text-2xl font-black text-slate-900 mb-1 tracking-tight">
              Guess the Imposter <span className="text-purple-600">Voice Arena</span>
            </h2>

            <p className="text-slate-600 text-xs max-w-xs mb-4 leading-relaxed font-medium">
              3 Players. 2 get the same secret item, 1 gets a different item. Record timed voice clues and vote out the imposter!
            </p>

            {/* Play Button & Action Strip */}
            <div className="flex flex-col w-full gap-2">
              <button
                id="play-imposter-game-button"
                type="button"
                onClick={handlePlayAction}
                className="w-full py-3.5 px-6 bg-purple-600 text-white font-black rounded-2xl shadow-lg shadow-purple-500/25 hover:bg-purple-700 active:scale-98 transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>PLAY IMPOSTER (2 🪙)</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playPop();
                  setShowDetails(!showDetails);
                }}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors text-xs cursor-pointer"
              >
                {showDetails ? 'Hide Features ▲' : 'View All Features ▼'}
              </button>
            </div>
          </div>

        </div>

        {/* Expandable Features & Voice Rules (Shown on Click) */}
        {showDetails && (
          <div className="mt-5 pt-4 border-t border-slate-200/80 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-3 text-left">
              Game Rules & Voice Mechanics
            </div>

            <div className="flex flex-col gap-2.5 text-left">
              
              {/* 1. Item Distribution */}
              <div className="p-3 rounded-xl bg-purple-50/80 border border-purple-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-purple-800 font-extrabold text-xs">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>1. Secret Item Assignment</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • 2 players get the <strong>same item</strong> (e.g. Lemon 🍋).<br />
                  • 1 player gets a <strong>different item</strong> (e.g. Banana 🍌).
                </p>
              </div>

              {/* 2. Audio Clue Recording */}
              <div className="p-3 rounded-xl bg-rose-50/80 border border-rose-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-rose-800 font-extrabold text-xs">
                  <Mic className="w-3.5 h-3.5" />
                  <span>2. Timed Voice Turn & Clue</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • Mic activates on your turn.<br />
                  • Record a clue describing your item without naming it.
                </p>
              </div>

              {/* 3. Review & Voting */}
              <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-amber-800 font-extrabold text-xs">
                  <Volume2 className="w-3.5 h-3.5 text-amber-600" />
                  <span>3. Playback & Voting</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • Replay audio recordings and vote for the Imposter to win <strong>+35 to +50 Tokens</strong>!
                </p>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
