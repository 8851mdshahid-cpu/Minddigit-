import React, { useState, useEffect } from 'react';
import { Sparkles, Coins, Gift, Play, Flame, Timer, ArrowRight, RefreshCw } from 'lucide-react';
import { sound } from '../utils/audio';

interface LuckyScrollAdBannerProps {
  onOpenScrollModal: () => void;
}

const STORAGE_SCROLL_KEY = 'minddigit_lucky_scroll_state_v2';

export const LuckyScrollAdBanner: React.FC<LuckyScrollAdBannerProps> = ({
  onOpenScrollModal,
}) => {
  const [chancesLeft, setChancesLeft] = useState<number>(2);
  const [timeRemainingStr, setTimeRemainingStr] = useState<string>('');

  useEffect(() => {
    const updateBannerStatus = () => {
      try {
        const today = new Date().toDateString();
        const raw = localStorage.getItem(STORAGE_SCROLL_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed.lastDate !== today) {
            setChancesLeft(2);
            setTimeRemainingStr('');
          } else {
            setChancesLeft(parsed.chancesLeft ?? 2);
            if (parsed.cooldownEnd && parsed.cooldownEnd > Date.now()) {
              const diff = parsed.cooldownEnd - Date.now();
              const hours = Math.floor(diff / (1000 * 60 * 60));
              const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
              setTimeRemainingStr(`${hours}h ${mins}m`);
            } else {
              setTimeRemainingStr('');
            }
          }
        } else {
          setChancesLeft(2);
        }
      } catch {
        setChancesLeft(2);
      }
    };

    updateBannerStatus();
    const interval = setInterval(updateBannerStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      id="daily-lucky-scroll-ad-banner"
      onClick={() => {
        sound.playPop();
        onOpenScrollModal();
      }}
      className="group relative w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 rounded-2xl p-3 text-white shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer overflow-hidden border border-amber-300 select-none mb-3.5"
    >
      {/* Animated shimmer highlight */}
      <div className="absolute inset-0 bg-white/15 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 pointer-events-none" />

      <div className="relative flex items-center justify-between gap-2.5 z-10">
        
        {/* Left: Animated spinning scroll icon & titles */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center text-xl shadow-inner shrink-0 group-hover:rotate-12 transition-transform">
            🎰
          </div>
          
          <div className="flex flex-col text-left min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider bg-white/25 px-1.5 py-0.2 rounded-md">
                DAILY SPONSOR SCROLL
              </span>
              {chancesLeft > 0 ? (
                <span className="text-[10px] font-black bg-amber-900/30 text-amber-100 px-1.5 py-0.2 rounded-md">
                  {chancesLeft} Spins Left
                </span>
              ) : (
                <span className="text-[10px] font-black bg-slate-900/40 text-amber-200 px-1.5 py-0.2 rounded-md flex items-center gap-0.5">
                  <Timer className="w-2.5 h-2.5" />
                  <span>{timeRemainingStr || 'Cooldown'}</span>
                </span>
              )}
            </div>

            <h3 className="text-xs font-black tracking-tight leading-tight mt-0.5 truncate text-white">
              Spin to Win <span className="text-yellow-200">10 🪙</span> or <span className="text-yellow-200">20 🪙 Jackpot</span>!
            </h3>
          </div>
        </div>

        {/* Right CTA Button */}
        <div className="shrink-0">
          <div className="flex items-center gap-1 bg-white text-amber-900 font-black text-[11px] px-2.5 py-1.5 rounded-xl shadow-sm group-hover:bg-amber-50 group-hover:scale-105 transition-all">
            <span>{chancesLeft > 0 ? 'SPIN NOW' : 'NEXT TRY'}</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </div>
        </div>

      </div>
    </div>
  );
};
