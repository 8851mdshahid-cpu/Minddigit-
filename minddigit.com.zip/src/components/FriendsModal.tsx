import React, { useState, useEffect } from 'react';
import {
  X,
  UserPlus,
  Bell,
  Users,
  Search,
  Check,
  Clock,
  Gamepad2,
  AlertCircle,
  CheckCircle2,
  Trash2,
  Zap,
  ArrowLeft,
  Send,
  Sparkles,
} from 'lucide-react';
import { UserProfile, ActiveGameType } from '../types';
import { sound } from '../utils/audio';
import {
  Friend,
  FriendRequest,
  getFriends,
  getIncomingRequests,
  searchUserRecord,
  sendFriendRequest,
  sendFriendRequestAsync,
  acceptFriendRequest,
  rejectFriendRequest,
  removeFriendFromUser,
  createSimulatedIncomingRequest,
  getRemovedFriends,
} from '../utils/friends';
import { subscribeToIncomingRequests } from '../utils/firebaseFriends';

interface FriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  initialTab?: 'add' | 'notifications' | 'friends';
  onStartGameWithFriend: (
    friend: Friend,
    gameType?: ActiveGameType,
    roomCode?: string
  ) => void;
  onRequestsUpdated?: () => void;
}

interface FoundUserProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
}

export const FriendsModal: React.FC<FriendsModalProps> = ({
  isOpen,
  onClose,
  user,
  initialTab = 'add',
  onStartGameWithFriend,
  onRequestsUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'add' | 'notifications' | 'friends'>(initialTab);
  const [userIdInput, setUserIdInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [foundUser, setFoundUser] = useState<FoundUserProfile | null>(null);
  
  // Toast / Alert state
  const [toast, setToast] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
  } | null>(null);

  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<FriendRequest[]>([]);
  const [now, setNow] = useState<number>(Date.now());

  // Show auto-dismissing toast
  const showToast = (type: 'success' | 'error' | 'info', message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast((current) => (current?.message === message ? null : current));
    }, 4500);
  };

  // Load friends and requests
  const refreshData = () => {
    setFriendsList(getFriends(user.id));
    setIncomingRequests(getIncomingRequests(user.username));
    if (onRequestsUpdated) onRequestsUpdated();
  };

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setUserIdInput('');
      setFoundUser(null);
      setToast(null);
      refreshData();

      // Listen to real-time incoming Firestore requests
      const unsubscribe = subscribeToIncomingRequests(user.username, (firestoreReqs) => {
        const localReqs = getIncomingRequests(user.username);
        // Merge by unique id
        const merged = [...(firestoreReqs || [])];
        localReqs.forEach((lr) => {
          if (!merged.some((mr) => mr.id === lr.id)) {
            merged.push(lr);
          }
        });
        setIncomingRequests(merged);
      });

      return () => {
        if (unsubscribe) unsubscribe();
      };
    }
  }, [isOpen, initialTab, user.id, user.username]);

  // Active 1-second interval timer for 15-second request countdowns
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  // 1. Handle Search User by User ID
  const handleSearchUser = async () => {
    const query = userIdInput.trim();
    if (!query) {
      sound.playLose();
      showToast('error', 'Please enter a User ID to search.');
      return;
    }

    sound.playPop();
    setIsSearching(true);
    setFoundUser(null);
    setToast(null);

    try {
      const result = await searchUserRecord(query);
      setIsSearching(false);

      if (result.exists && result.account) {
        sound.playWin();
        setFoundUser(result.account);
      } else {
        sound.playLose();
        showToast('error', 'User not found');
      }
    } catch {
      setIsSearching(false);
      sound.playLose();
      showToast('error', 'User not found');
    }
  };

  // 2. Handle Send Friend Request
  const handleSendFriendRequest = async () => {
    if (!foundUser) return;

    sound.playPop();
    setIsSending(true);

    try {
      const result = await sendFriendRequestAsync(user, foundUser.username, undefined, undefined, false);
      setIsSending(false);

      if (result.success) {
        sound.playWin();
        showToast('success', result.message || 'Friend Request Sent Successfully!');
        refreshData();
      } else {
        sound.playLose();
        showToast('error', result.message || 'Failed to send friend request.');
      }
    } catch {
      setIsSending(false);
      sound.playLose();
      showToast('error', 'Failed to send friend request.');
    }
  };

  // 3. Handle Accept Request (Takes user into room if roomCode exists!)
  const handleAccept = (req: FriendRequest) => {
    sound.playWin();
    // Immediately remove from pending UI state so it doesn't get stuck in the queue
    setIncomingRequests((prev) => prev.filter((r) => r.id !== req.id));
    const result = acceptFriendRequest(req.id, user);
    refreshData();

    if (result.success && result.friend) {
      if (result.roomCode) {
        // Automatically join friend's room!
        onStartGameWithFriend(result.friend, result.gameType || 'guess-imposter', result.roomCode);
        onClose();
      } else {
        showToast('success', `You and @${result.friend.username} are now friends! Added to friends list.`);
        setActiveTab('friends');
      }
    }
  };

  // 4. Handle Reject Request
  const handleReject = (reqId: string) => {
    sound.playClick();
    setIncomingRequests((prev) => prev.filter((r) => r.id !== reqId));
    rejectFriendRequest(reqId);
    refreshData();
    showToast('info', 'Request declined.');
  };

  // 5. Handle Remove Friend (Permanently blocks re-addition by default lists)
  const handleRemoveFriend = (friendUsername: string) => {
    sound.playClick();
    const updated = removeFriendFromUser(user.id, friendUsername, user.username);
    setFriendsList(updated);
    if (onRequestsUpdated) onRequestsUpdated();
    showToast('info', `Removed @${friendUsername} from friends (दोबारा नहीं आएगा).`);
  };

  // 6. Simulate an incoming request for instant testing
  const handleSimulateIncoming = () => {
    sound.playPop();
    createSimulatedIncomingRequest(user.username);
    refreshData();
    setActiveTab('notifications');
    showToast('info', 'Generated a demo incoming request (Valid for 15s)!');
  };

  // Suggested platform users (strictly excluding removed users)
  const removedUsernames = getRemovedFriends(user.id);
  const platformSuggestions = [
    { name: 'Rohan Pro', username: 'rohan_duel', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan_pro', isOnline: true },
    { name: 'Zara Star', username: 'zara_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara', isOnline: true },
    { name: 'Kabir Mind', username: 'kabir_pro', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=kabir', isOnline: false },
    { name: 'Meera Detective', username: 'meera_x', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=meera', isOnline: false },
  ].filter((p) => !removedUsernames.includes(p.username.toLowerCase()));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-[32px] p-5 sm:p-6 w-full max-w-md shadow-2xl border border-slate-100 relative max-h-[92vh] overflow-y-auto flex flex-col">
        
        {/* Close Button */}
        <button
          type="button"
          id="btn-close-friends-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors cursor-pointer z-10"
          title="Close Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        <div className="text-center pt-1 mb-4">
          <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-2">
            <span>Friends & Social</span>
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Search users, send requests & challenge friends
          </p>
        </div>

        {/* 3 Nav Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 rounded-2xl mb-4 select-none">
          
          {/* Tab 1: Add Friend */}
          <button
            type="button"
            id="tab-add-friend"
            onClick={() => {
              sound.playClick();
              setActiveTab('add');
              setToast(null);
            }}
            className={`py-2 px-1 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer ${
              activeTab === 'add'
                ? 'bg-white text-blue-600 shadow-xs scale-102'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Add Friend</span>
          </button>

          {/* Tab 2: Notifications (With active badge & 15s timer) */}
          <button
            type="button"
            id="tab-notifications"
            onClick={() => {
              sound.playClick();
              setActiveTab('notifications');
              setToast(null);
            }}
            className={`py-2 px-1 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer relative ${
              activeTab === 'notifications'
                ? 'bg-white text-purple-600 shadow-xs scale-102'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Requests</span>
            {incomingRequests.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-black flex items-center justify-center animate-pulse">
                {incomingRequests.length}
              </span>
            )}
          </button>

          {/* Tab 3: My Friends */}
          <button
            type="button"
            id="tab-my-friends"
            onClick={() => {
              sound.playClick();
              setActiveTab('friends');
              setToast(null);
            }}
            className={`py-2 px-1 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer ${
              activeTab === 'friends'
                ? 'bg-white text-emerald-600 shadow-xs scale-102'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Friends ({friendsList.length})</span>
          </button>

        </div>

        {/* Dynamic Toast / Alert Banner */}
        {toast && (
          <div
            id="toast-friend-feedback"
            className={`mb-3 p-3 rounded-2xl text-xs font-bold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-150 ${
              toast.type === 'success'
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                : toast.type === 'error'
                ? 'bg-rose-50 border border-rose-200 text-rose-800'
                : 'bg-blue-50 border border-blue-200 text-blue-800'
            }`}
          >
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />}
            {toast.type === 'info' && <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />}
            <span className="flex-1">{toast.message}</span>
            <button
              type="button"
              onClick={() => setToast(null)}
              className="p-1 hover:bg-black/5 rounded-lg text-slate-400 hover:text-slate-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 1: ADD FRIEND WORKFLOW (SEARCH & SEND REQUEST) */}
        {/* ======================================================== */}
        {activeTab === 'add' && (
          <div className="flex flex-col gap-4 animate-in fade-in duration-150">
            
            {/* Case A: Search Form (When no user is currently selected in profile card) */}
            {!foundUser ? (
              <>
                <div className="p-4 bg-gradient-to-br from-blue-50/90 to-indigo-50/60 border border-blue-200/80 rounded-2xl flex flex-col gap-3">
                  <label htmlFor="input-search-userid" className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                    <Search className="w-4 h-4 text-blue-600" />
                    <span>Search User ID:</span>
                  </label>

                  <div className="relative flex items-center">
                    <span className="absolute left-3.5 text-slate-400 font-mono font-bold text-sm">@</span>
                    <input
                      id="input-search-userid"
                      type="text"
                      placeholder="Enter User ID (e.g. rohan_duel or shahid8851)"
                      value={userIdInput}
                      onChange={(e) => {
                        setUserIdInput(e.target.value);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && userIdInput.trim()) {
                          handleSearchUser();
                        }
                      }}
                      className="w-full pl-8 pr-24 py-3 bg-white border-2 border-blue-300 rounded-xl font-mono text-sm font-bold text-slate-900 focus:outline-none focus:ring-3 focus:ring-blue-200 focus:border-blue-500 transition-all shadow-inner"
                      autoFocus
                    />
                    
                    <button
                      type="button"
                      id="btn-search-user"
                      onClick={handleSearchUser}
                      disabled={isSearching}
                      className="absolute right-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-lg transition-all shadow-xs cursor-pointer flex items-center gap-1 active:scale-95 disabled:opacity-50"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>{isSearching ? 'Searching...' : 'Search'}</span>
                    </button>
                  </div>

                  <div className="text-[11px] text-slate-500 leading-tight">
                    Type any player&apos;s User ID and click <strong>Search</strong> to query the database.
                  </div>
                </div>

                {/* Your Own User ID Card (So user can share it with friends) */}
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Your User ID</span>
                    <span className="text-xs font-mono font-black text-slate-800">@{user.username}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(user.username);
                      sound.playPop();
                      showToast('success', `Copied your User ID (@${user.username}) to clipboard!`);
                    }}
                    className="px-2.5 py-1 text-xs font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors cursor-pointer"
                  >
                    Copy ID
                  </button>
                </div>

                {/* Quick Suggested Online Players */}
                <div className="flex flex-col gap-2">
                  <span className="text-[11px] font-black uppercase text-slate-400 tracking-wider text-left">
                    Suggested Players Online:
                  </span>

                  <div className="flex flex-col gap-1.5">
                    {platformSuggestions.map((p) => {
                      const isAlreadyFriend = friendsList.some(
                        (f) => f.username.toLowerCase() === p.username.toLowerCase()
                      );
                      const isCurrentUser = user.username.toLowerCase() === p.username.toLowerCase();

                      if (isCurrentUser) return null;

                      return (
                        <div
                          key={p.username}
                          className="p-2.5 bg-white border border-slate-200 rounded-xl flex items-center justify-between shadow-2xs hover:bg-slate-50 transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="relative">
                              <img
                                src={p.avatar}
                                alt={p.name}
                                referrerPolicy="no-referrer"
                                className={`w-8 h-8 rounded-full border bg-purple-50 ${
                                  p.isOnline ? 'border-slate-200' : 'border-rose-200 opacity-85'
                                }`}
                              />
                              {p.isOnline ? (
                                <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full" title="Online" />
                              ) : (
                                <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-600 rounded-full flex items-center justify-center border border-white shadow-2xs" title="Offline (Red Tick)">
                                  <Check className="w-2 h-2 text-white stroke-[3.5]" />
                                </div>
                              )}
                            </div>
                            <div className="text-left">
                              <div className="text-xs font-black text-slate-900 flex items-center gap-1">
                                <span>{p.name}</span>
                                {!p.isOnline && (
                                  <span className="inline-flex items-center text-rose-600 shrink-0" title="Offline">
                                    <Check className="w-2.5 h-2.5 text-rose-600 stroke-[3.5]" />
                                  </span>
                                )}
                              </div>
                              <div className="text-[10px] font-mono text-slate-400">@{p.username}</div>
                            </div>
                          </div>

                          {isAlreadyFriend ? (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200 flex items-center gap-1">
                              <Check className="w-3 h-3" /> Friends
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                setUserIdInput(p.username);
                                sound.playPop();
                                setFoundUser({
                                  id: `usr_${p.username}`,
                                  name: p.name,
                                  username: p.username,
                                  avatar: p.avatar,
                                });
                              }}
                              className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-black rounded-lg border border-blue-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Search className="w-3 h-3" />
                              <span>View</span>
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            ) : (
              /* Case B: User Found -> Display User Profile Card (Left Avatar, Right/Top Name, Right/Bottom User ID, Bottom Buttons) */
              <div className="p-5 bg-gradient-to-br from-indigo-50/90 via-purple-50/50 to-blue-50/80 border-2 border-indigo-200 rounded-3xl flex flex-col gap-4 shadow-md animate-in fade-in zoom-in-95 duration-150">
                
                <div className="text-[10px] font-black uppercase text-indigo-500 tracking-wider text-left flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>User Record Found</span>
                </div>

                {/* User Profile Card Structure:
                    - Left: User Profile Picture / Avatar Logo (`user_avatar`)
                    - Right/Top: User Name (`full_name`)
                    - Right/Bottom: User ID (`user_id`)
                */}
                <div className="flex items-center gap-4 bg-white p-3.5 rounded-2xl border border-indigo-100 shadow-xs">
                  {/* Left: User Profile Picture / Avatar Logo */}
                  <div className="relative shrink-0">
                    <img
                      src={foundUser.avatar}
                      alt={foundUser.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-2 border-indigo-300 bg-indigo-50 shadow-inner"
                    />
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" title="Online" />
                  </div>

                  {/* Right: Top Name & Bottom User ID */}
                  <div className="flex flex-col text-left flex-1 min-w-0">
                    {/* Right/Top: User Name */}
                    <div className="text-sm sm:text-base font-black text-slate-900 truncate">
                      {foundUser.name}
                    </div>

                    {/* Right/Bottom: User ID */}
                    <div className="mt-0.5 inline-flex items-center gap-1">
                      <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 font-mono font-bold text-xs rounded-md border border-indigo-200 truncate">
                        @{foundUser.username}
                      </span>
                    </div>

                    <div className="text-[10px] text-slate-400 mt-1">
                      Ready to connect & challenge to games
                    </div>
                  </div>
                </div>

                {/* Bottom Buttons: "Send Friend Request" and "Back" */}
                <div className="flex items-center gap-2 pt-1">
                  {/* Back Button */}
                  <button
                    type="button"
                    id="btn-back-search"
                    onClick={() => {
                      sound.playClick();
                      setFoundUser(null);
                      setToast(null);
                    }}
                    className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Back</span>
                  </button>

                  {/* Send Friend Request Button */}
                  <button
                    type="button"
                    id="btn-send-friend-request"
                    onClick={handleSendFriendRequest}
                    disabled={isSending}
                    className="flex-2 py-2.5 px-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs rounded-xl shadow-md shadow-blue-500/20 transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSending ? 'Sending...' : 'Send Friend Request'}</span>
                  </button>
                </div>

              </div>
            )}

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: NOTIFICATIONS & REQUESTS (PERMANENT & 15S IN-GAME) */}
        {/* ======================================================== */}
        {activeTab === 'notifications' && (
          <div className="flex flex-col gap-3 animate-in fade-in duration-150">
            
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-slate-500">
                Incoming Requests
              </span>
              <button
                type="button"
                onClick={handleSimulateIncoming}
                className="text-[11px] font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 px-2.5 py-1 rounded-lg border border-purple-200 transition-colors cursor-pointer flex items-center gap-1"
                title="Generate a test incoming request"
              >
                <Zap className="w-3 h-3 text-amber-500" />
                <span>+ Test Invite</span>
              </button>
            </div>

            {incomingRequests.length === 0 ? (
              <div className="py-8 px-4 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl flex flex-col items-center gap-2">
                <Bell className="w-8 h-8 text-slate-300" />
                <span className="text-xs font-bold text-slate-500">
                  No active friend requests right now.
                </span>
                <p className="text-[11px] text-slate-400 max-w-xs">
                  When someone adds your User ID (@{user.username}), it will appear here and remain until you accept or reject it!
                </p>
                <button
                  type="button"
                  onClick={handleSimulateIncoming}
                  className="mt-2 px-3 py-1.5 bg-purple-600 text-white rounded-xl font-bold text-xs shadow-xs hover:bg-purple-700 transition-colors cursor-pointer"
                >
                  ⚡ Send Demo Friend Request
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {incomingRequests.map((req) => {
                  const hasTimer = Boolean(req.expiresInSeconds && req.expiresInSeconds > 0);
                  const elapsedSeconds = Math.floor((now - req.timestamp) / 1000);
                  const remainingSeconds = hasTimer && req.expiresInSeconds
                    ? Math.max(0, req.expiresInSeconds - elapsedSeconds)
                    : null;
                  const isExpired = hasTimer && remainingSeconds !== null && remainingSeconds <= 0;
                  const progressPercent = hasTimer && req.expiresInSeconds && remainingSeconds !== null
                    ? Math.max(0, (remainingSeconds / req.expiresInSeconds) * 100)
                    : 100;

                  return (
                    <div
                      key={req.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col gap-2 shadow-xs ${
                        isExpired
                          ? 'bg-slate-100 border-slate-200 opacity-60'
                          : req.type === 'room_invite' || req.type === 'game_challenge'
                          ? 'bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-300'
                          : 'bg-white border-blue-200'
                      }`}
                    >
                      {/* Sender Info */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={req.fromAvatar}
                            alt={req.fromName}
                            referrerPolicy="no-referrer"
                            className="w-9 h-9 rounded-full border border-purple-200 bg-purple-50"
                          />
                          <div className="text-left">
                            <div className="text-xs font-black text-slate-900 flex items-center gap-1">
                              <span>{req.fromName}</span>
                              {req.type === 'room_invite' && (
                                <span className="text-[9px] bg-purple-600 text-white font-bold px-1.5 py-0.5 rounded">
                                  ROOM INVITE
                                </span>
                              )}
                              {req.type === 'game_challenge' && (
                                <span className="text-[9px] bg-indigo-600 text-white font-bold px-1.5 py-0.5 rounded">
                                  GAME CHALLENGE
                                </span>
                              )}
                              {req.type === 'friend_request' && (
                                <span className="text-[9px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.5 rounded">
                                  FRIEND REQUEST
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] font-mono text-slate-500">
                              @{req.fromUsername}
                            </div>
                          </div>
                        </div>

                        {/* Status / Timer countdown */}
                        {hasTimer ? (
                          <div className="flex items-center gap-1 font-mono text-xs font-black">
                            <Clock className={`w-3.5 h-3.5 ${isExpired ? 'text-slate-400' : 'text-amber-600 animate-spin'}`} />
                            <span className={isExpired ? 'text-slate-400' : 'text-amber-700'}>
                              {isExpired ? 'Expired' : `${remainingSeconds}s`}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-[10px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            <span>Pending (Saved)</span>
                          </div>
                        )}
                      </div>

                      {/* Visual Countdown Progress Bar for 15s Timer */}
                      {hasTimer && !isExpired && (
                        <div className="w-full h-1 bg-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all duration-1000"
                            style={{ width: `${progressPercent}%` }}
                          />
                        </div>
                      )}

                      {/* Invite Description */}
                      <div className="text-[11px] text-slate-600 text-left font-medium">
                        {req.type === 'room_invite'
                          ? `Invited you to join room #${req.roomCode}! Accept to join the game directly.`
                          : req.type === 'game_challenge'
                          ? `Challenged you to a game match (15s)!`
                          : `Wants to add you as a friend on MindDigit. Will remain until you respond.`}
                      </div>

                      {/* Action Buttons: Accept / Reject */}
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => handleReject(req.id)}
                          className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
                        >
                          Reject ✕
                        </button>

                        <button
                          type="button"
                          onClick={() => handleAccept(req)}
                          disabled={isExpired}
                          className={`flex-2 py-2 rounded-xl font-black text-xs transition-all flex items-center justify-center gap-1 shadow-xs cursor-pointer ${
                            isExpired
                              ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/20 active:scale-95'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                          <span>{req.type === 'room_invite' ? 'Accept & Join Room' : 'Accept Request'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: MY FRIENDS (CLICK TO PLAY / CHALLENGE TO GAME) */}
        {/* ======================================================== */}
        {activeTab === 'friends' && (
          <div className="flex flex-col gap-3 animate-in fade-in duration-150">
            
            <div className="text-xs font-bold text-slate-500 text-left px-1 flex items-center justify-between">
              <span>Your Active Friends ({friendsList.length})</span>
              <span className="text-[10px] text-slate-500 font-bold">
                {friendsList.filter((f) => f.isOnline).length} Online • {friendsList.filter((f) => !f.isOnline).length} Offline
              </span>
            </div>

            {friendsList.length === 0 ? (
              <div className="py-8 px-4 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl flex flex-col items-center gap-2">
                <Users className="w-8 h-8 text-slate-300" />
                <span className="text-xs font-bold text-slate-500">
                  No friends added yet.
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTab('add')}
                  className="mt-2 px-3 py-1.5 bg-blue-600 text-white rounded-xl font-bold text-xs shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  + Add Your First Friend
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {friendsList.map((friend) => (
                  <div
                    key={friend.username}
                    className={`p-3 border rounded-2xl flex items-center justify-between shadow-2xs hover:shadow-sm transition-all ${
                      friend.isOnline
                        ? 'bg-white border-slate-200 hover:border-purple-300'
                        : 'bg-slate-50/90 border-slate-200 hover:border-rose-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="relative">
                        <img
                          src={friend.avatar}
                          alt={friend.name}
                          referrerPolicy="no-referrer"
                          className={`w-10 h-10 rounded-full border bg-purple-50 ${
                            friend.isOnline ? 'border-purple-200' : 'border-rose-300 grayscale-[25%]'
                          }`}
                        />
                        {/* Status indicator on avatar: green dot if online, red circular sticker if offline */}
                        {friend.isOnline ? (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full shadow-xs" title="Online" />
                        ) : (
                          <div
                            className="absolute -top-1 -right-1 w-4 h-4 bg-rose-600 rounded-full flex items-center justify-center border-2 border-white shadow-xs"
                            title="Offline (लाल गोल स्टिकर)"
                          >
                            <span className="w-1.5 h-1.5 bg-white rounded-full" />
                          </div>
                        )}
                      </div>
                      <div className="text-left">
                        <div className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                          <span>{friend.name}</span>
                          {!friend.isOnline ? (
                            <span className="inline-flex items-center gap-0.5 text-rose-700 bg-rose-100 border border-rose-200 font-bold text-[9px] px-1.5 py-0.2 rounded-md" title="Offline">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-600" />
                              <span>Offline</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-0.5 text-emerald-700 bg-emerald-100 border border-emerald-200 font-bold text-[9px] px-1.5 py-0.2 rounded-md" title="Online">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                              <span>Online</span>
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] font-mono text-slate-400">@{friend.username}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {/* Play / Invite Button: Online plays, Offline shows warning */}
                      <button
                        type="button"
                        onClick={() => {
                          if (friend.isOnline) {
                            sound.playWin();
                            onStartGameWithFriend(friend, 'guess-imposter');
                            onClose();
                          } else {
                            sound.playLose();
                            sendFriendRequest(user, friend.username, undefined, 'guess-imposter', true);
                            showToast('error', `⚠️ ${friend.name} (@${friend.username}) अभी Offline है! वो ऑनलाइन नहीं है इसलिए उसके बदले कोई फेक बॉट नहीं खेलेगा। जब वो ऑनलाइन आएगा तभी रियल-टाइम मैच होगा।`);
                          }
                        }}
                        className={`px-3 py-1.5 font-black text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1 active:scale-95 ${
                          friend.isOnline
                            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white'
                            : 'bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-200'
                        }`}
                        title={friend.isOnline ? 'Start game with this online friend' : 'This friend is currently offline'}
                      >
                        <Gamepad2 className="w-3.5 h-3.5" />
                        <span>{friend.isOnline ? 'Play' : 'Invite (Offline)'}</span>
                      </button>

                      {/* Remove Friend */}
                      <button
                        type="button"
                        onClick={() => handleRemoveFriend(friend.username)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                        title="Remove Friend"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
