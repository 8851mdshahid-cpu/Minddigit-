import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  ArrowLeft, Timer, Trophy, Zap, RefreshCw, Coins, Sparkles, Check, X, 
  Users, User, Swords, Flame, RotateCcw, AlertTriangle, CheckCircle2, XCircle, Heart, Eye, ArrowRight
} from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { Friend, getFriends, getActiveOnlineUsernames } from '../utils/friends';

interface GameBridgerProps {
  user: UserProfile;
  initialOpponent?: { name: string; username: string; avatar?: string };
  onBack: () => void;
  onGameEnd: (won: boolean, scoreGained: number, coinsGained: number) => void;
  onRetry?: () => void;
}

export type BridgerGameMode = 'solo' | 'friend';

interface BridgerQuestion {
  id: number;
  question: string;
  category: string;
  hint: string;
  options: string[];
  correctIndex: number;
}

const BRIDGER_QUESTIONS_POOL: BridgerQuestion[] = [
  {
    id: 1,
    question: "What is the primary bridge connecting a client browser to an API server?",
    category: "Tech & Logic",
    hint: "Think HTTP request/response protocol",
    options: ["HTTP/REST Protocol", "USB Cable", "Power Grid", "BIOS Chip"],
    correctIndex: 0,
  },
  {
    id: 2,
    question: "If a digital bridge holds 6 data packets and 2 cross every second, how long for all 6?",
    category: "Math Bridge",
    hint: "Divide total packets by rate",
    options: ["2 Seconds", "3 Seconds", "6 Seconds", "12 Seconds"],
    correctIndex: 1,
  },
  {
    id: 3,
    question: "Which iconic suspension bridge connects San Francisco to Marin County?",
    category: "World Bridges",
    hint: "Famous orange vermilion landmark",
    options: ["Brooklyn Bridge", "Golden Gate Bridge", "Tower Bridge", "Sydney Harbour Bridge"],
    correctIndex: 1,
  },
  {
    id: 4,
    question: "In networking, what device bridges two distinct network segments together?",
    category: "Cyber Net",
    hint: "Inspects MAC addresses",
    options: ["Network Bridge", "Speaker", "Cooling Fan", "Hard Drive"],
    correctIndex: 0,
  },
  {
    id: 5,
    question: "Solve the bridge sequence: 3, 6, 12, 24, __?",
    category: "Pattern Logic",
    hint: "Each step doubles the previous value",
    options: ["36", "40", "48", "52"],
    correctIndex: 2,
  },
  {
    id: 6,
    question: "Which bridge type uses diagonal triangular units to distribute weight?",
    category: "Architecture",
    hint: "Often made of steel geometric triangles",
    options: ["Truss Bridge", "Rope Bridge", "Pontoon Bridge", "Arch Bridge"],
    correctIndex: 0,
  },
  {
    id: 7,
    question: "If Team Alpha has 2 points and Team Beta has 3 points in a 5-round match, who wins?",
    category: "Game Rules",
    hint: "Target is 3 or more points to secure victory",
    options: ["Team Beta (3 pts)", "Team Alpha (2 pts)", "It is a Draw", "Both Lose"],
    correctIndex: 0,
  },
  {
    id: 8,
    question: "What is the largest living bridge made from rubber tree roots located in Meghalaya?",
    category: "Nature Bridges",
    hint: "Grown over centuries by the Khasi people",
    options: ["Living Root Bridge", "Bamboo Walk", "Vine Crossing", "Stone Arch"],
    correctIndex: 0,
  },
  {
    id: 9,
    question: "Find the bridge equation: If X + 15 = 45, what is X?",
    category: "Math Bridge",
    hint: "Subtract 15 from 45",
    options: ["25", "30", "35", "40"],
    correctIndex: 1,
  },
  {
    id: 10,
    question: "In logic gates, which gate acts as a universal bridge for all Boolean expressions?",
    category: "Logic Gates",
    hint: "NOT-AND gate",
    options: ["NAND Gate", "OR Gate", "XOR Gate", "BUFFER Gate"],
    correctIndex: 0,
  }
];

const TOTAL_ROUNDS = 5; // Exactly 5 rounds / 5 questions as requested
const ROUND_TIME_LIMIT = 6; // 6 seconds timing

export const GameBridger: React.FC<GameBridgerProps> = ({
  user,
  initialOpponent,
  onBack,
  onGameEnd,
  onRetry,
}) => {
  const [gameMode, setGameMode] = useState<BridgerGameMode>(initialOpponent ? 'friend' : 'solo');
  const [isGameStarted, setIsGameStarted] = useState<boolean>(false);
  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);

  // 5 Rounds Gameplay
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [activeQuestions, setActiveQuestions] = useState<BridgerQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<BridgerQuestion | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(ROUND_TIME_LIMIT);
  const [isRoundLocked, setIsRoundLocked] = useState<boolean>(false);
  
  // Points (1 point per round question)
  const [userPoints, setUserPoints] = useState<number>(0);
  const [friendPoints, setFriendPoints] = useState<number>(0);
  const [userSelectedOption, setUserSelectedOption] = useState<number | null>(null);

  // Banner showing who answered first and if correct/wrong
  const [firstAnswerBanner, setFirstAnswerBanner] = useState<{
    playerName: string;
    isCorrect: boolean;
    text: string;
  } | null>(null);

  // Match Finished
  const [isMatchFinished, setIsMatchFinished] = useState<boolean>(false);
  const [matchWinner, setMatchWinner] = useState<'user' | 'friend' | 'draw' | null>(null);

  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const friendTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Load friends and strictly check logged-in / active online status
  useEffect(() => {
    const list = getFriends(user.id);
    setFriendsList(list);

    if (initialOpponent) {
      const matched = list.find((f) => f.username.toLowerCase() === initialOpponent.username.toLowerCase());
      if (matched) {
        setSelectedFriend(matched);
      } else {
        setSelectedFriend({
          id: 'init_opp',
          name: initialOpponent.name,
          username: initialOpponent.username,
          avatar: initialOpponent.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${initialOpponent.username}`,
          isOnline: true,
          addedAt: Date.now(),
        });
      }
    } else {
      // Pick first online friend if available, else first friend
      const onlineFriend = list.find((f) => f.isOnline);
      setSelectedFriend(onlineFriend || list[0] || null);
    }
  }, [user.id, initialOpponent]);

  // Start 5-round Match
  const startMatch = (mode: BridgerGameMode) => {
    sound.playPop();
    setGameMode(mode);
    setIsGameStarted(true);
    setIsMatchFinished(false);
    setMatchWinner(null);
    setCurrentRound(1);
    setUserPoints(0);
    setFriendPoints(0);
    setUserSelectedOption(null);
    setFirstAnswerBanner(null);
    setIsRoundLocked(false);

    // Pick 5 random questions for the 5 rounds
    const shuffled = [...BRIDGER_QUESTIONS_POOL].sort(() => Math.random() - 0.5).slice(0, TOTAL_ROUNDS);
    setActiveQuestions(shuffled);
    setCurrentQuestion(shuffled[0]);
    setTimeLeft(ROUND_TIME_LIMIT);
  };

  // Next round
  const advanceToNextRound = (nextRoundNumber: number) => {
    if (nextRoundNumber > TOTAL_ROUNDS) {
      finalizeMatch();
      return;
    }

    setCurrentRound(nextRoundNumber);
    setUserSelectedOption(null);
    setFirstAnswerBanner(null);
    setIsRoundLocked(false);
    setCurrentQuestion(activeQuestions[nextRoundNumber - 1]);
    setTimeLeft(ROUND_TIME_LIMIT);
  };

  // Finalize 5 Rounds Result
  // Rules:
  // - 5 rounds total, 5 questions
  // - Each person earns 1 point for answering correctly first
  // - Whoever has >= 3 points will WIN
  // - Whoever has <= 2 points will LOSE
  const finalizeMatch = () => {
    setIsMatchFinished(true);
    setIsRoundLocked(true);
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (friendTimerRef.current) clearTimeout(friendTimerRef.current);

    if (gameMode === 'solo') {
      // Solo game: score generated, >= 3 points wins
      const won = userPoints >= 3;
      const scoreGenerated = userPoints * 20; // e.g. 3 pts = 60, 5 pts = 100
      const coinsGained = won ? 15 : 5;

      if (won) {
        sound.playWin();
        confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
      } else {
        sound.playLose();
      }
      onGameEnd(won, scoreGenerated, coinsGained);
    } else {
      // Friend 1v1 duel:
      // Winner has >= 3 points, Loser has <= 2 points
      let winner: 'user' | 'friend' | 'draw' = 'draw';
      if (userPoints >= 3) {
        winner = 'user';
      } else if (friendPoints >= 3) {
        winner = 'friend';
      } else {
        winner = userPoints > friendPoints ? 'user' : friendPoints > userPoints ? 'friend' : 'draw';
      }

      setMatchWinner(winner);
      const won = winner === 'user';
      const scoreGenerated = userPoints * 25;
      const coinsGained = won ? 25 : winner === 'draw' ? 8 : 3;

      if (won) {
        sound.playWin();
        confetti({ particleCount: 85, spread: 75, origin: { y: 0.6 } });
      } else {
        sound.playLose();
      }
      onGameEnd(won, scoreGenerated, coinsGained);
    }
  };

  // 6-Second Timer Countdown Hook
  useEffect(() => {
    if (!isGameStarted || isMatchFinished || isRoundLocked) return;

    timerIntervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerIntervalRef.current!);
          handleRoundTimeout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isGameStarted, isMatchFinished, isRoundLocked, currentRound]);

  // Friend AI / Opponent simulation in Friend Duel Mode
  useEffect(() => {
    if (!isGameStarted || isMatchFinished || isRoundLocked || gameMode !== 'friend' || !currentQuestion) {
      return;
    }

    // Friend reaction time within 2.3s - 4.9s
    const reactionDelayMs = Math.floor(Math.random() * 2400) + 2300;
    const willAnswerCorrect = Math.random() < 0.72;

    friendTimerRef.current = setTimeout(() => {
      if (isRoundLocked || isMatchFinished) return;

      if (willAnswerCorrect) {
        handleFriendAnswer(true);
      } else {
        handleFriendAnswer(false);
      }
    }, reactionDelayMs);

    return () => {
      if (friendTimerRef.current) clearTimeout(friendTimerRef.current);
    };
  }, [isGameStarted, isMatchFinished, isRoundLocked, currentRound, gameMode, currentQuestion]);

  // Handle User Option Click
  const handleUserSelectOption = (index: number) => {
    if (!currentQuestion || isRoundLocked || isMatchFinished) return;
    setUserSelectedOption(index);

    const isCorrect = index === currentQuestion.correctIndex;

    if (isCorrect) {
      sound.playWin();
      setIsRoundLocked(true);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (friendTimerRef.current) clearTimeout(friendTimerRef.current);

      // 1 point awarded
      setUserPoints((prev) => prev + 1);

      // Display name on screen that player answered first and correctly
      setFirstAnswerBanner({
        playerName: user.name || user.username || 'You',
        isCorrect: true,
        text: `${user.name || 'You'} answered first! Correct (+1 Point)`,
      });

      confetti({ particleCount: 30, spread: 50, origin: { y: 0.5 } });

      setTimeout(() => {
        advanceToNextRound(currentRound + 1);
      }, 1200);

    } else {
      // Wrong Answer!
      sound.playLower();

      // Show "wrong answer" and do NOT give point
      setFirstAnswerBanner({
        playerName: user.name || 'You',
        isCorrect: false,
        text: 'Wrong Answer!',
      });

      if (gameMode === 'solo') {
        setIsRoundLocked(true);
        setTimeout(() => {
          advanceToNextRound(currentRound + 1);
        }, 900);
      } else {
        // In friend duel: dismiss after 800ms to allow opponent to answer
        setTimeout(() => {
          setFirstAnswerBanner((prev) => (prev?.isCorrect === false ? null : prev));
        }, 800);
      }
    }
  };

  // Handle Friend Answer (in 2-Player Friend Duel)
  const handleFriendAnswer = (isCorrect: boolean) => {
    if (isRoundLocked || isMatchFinished || !currentQuestion) return;
    const friendName = selectedFriend?.name || 'Friend';

    if (isCorrect) {
      sound.playLower();
      setIsRoundLocked(true);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

      // Friend gets 1 point
      setFriendPoints((prev) => prev + 1);

      // Opponent answered first
      setFirstAnswerBanner({
        playerName: friendName,
        isCorrect: true,
        text: `${friendName} answered first! Correct (+1 Point)`,
      });

      setTimeout(() => {
        advanceToNextRound(currentRound + 1);
      }, 1200);
    } else {
      // Friend wrong answer
      setFirstAnswerBanner({
        playerName: friendName,
        isCorrect: false,
        text: `${friendName} gave a Wrong Answer!`,
      });

      setTimeout(() => {
        setFirstAnswerBanner((prev) => (prev?.isCorrect === false ? null : prev));
      }, 800);
    }
  };

  // Timeout for round
  const handleRoundTimeout = () => {
    if (isRoundLocked || isMatchFinished) return;
    sound.playLose();
    setIsRoundLocked(true);

    setFirstAnswerBanner({
      playerName: '',
      isCorrect: false,
      text: `Time Expired! (Correct: ${currentQuestion?.options[currentQuestion?.correctIndex || 0]})`,
    });

    setTimeout(() => {
      advanceToNextRound(currentRound + 1);
    }, 1100);
  };

  // ==========================================
  // VIEW 1: LOBBY & MODE SELECTION
  // ==========================================
  if (!isGameStarted) {
    const isFriendOnline = selectedFriend?.isOnline ?? false;

    return (
      <div className="w-full max-w-sm bg-white/95 backdrop-blur-md rounded-3xl p-5 shadow-2xl border border-white flex flex-col items-center select-none animate-in fade-in duration-200">
        
        {/* Top Header */}
        <div className="w-full flex items-center justify-between mb-4">
          <button
            id="bridger-back-btn"
            type="button"
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-100 text-indigo-900 rounded-full font-black text-xs">
            <Sparkles className="w-3.5 h-3.5 fill-indigo-500 text-indigo-600" />
            <span>BRIDGER DUEL</span>
          </div>

          <div className="flex items-center gap-1 font-black text-xs text-amber-800 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
            <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span>{user.coins}</span>
          </div>
        </div>

        {/* Hero Artwork Box */}
        <div className="w-full bg-gradient-to-br from-indigo-900 via-indigo-800 to-purple-900 rounded-3xl p-5 text-white flex flex-col items-center text-center shadow-lg relative overflow-hidden mb-4 border border-indigo-700/50">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center mb-2 shadow-inner border border-white/20">
            <span className="text-2xl">🌉</span>
          </div>
          <h2 className="text-xl font-black tracking-tight">Bridger</h2>
          <p className="text-xs text-indigo-200 mt-1 max-w-[250px]">
            5 Rounds • 5 Questions • 1 Point per Round
          </p>
          <div className="mt-3 flex items-center gap-2 text-[11px] font-bold bg-black/30 px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>3+ Points to WIN • ≤2 Points LOSE</span>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="w-full grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl mb-4">
          <button
            id="tab-bridger-solo"
            type="button"
            onClick={() => {
              sound.playClick();
              setGameMode('solo');
            }}
            className={`py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              gameMode === 'solo'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span>Solo Game</span>
          </button>

          <button
            id="tab-bridger-friend"
            type="button"
            onClick={() => {
              sound.playClick();
              setGameMode('friend');
            }}
            className={`py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              gameMode === 'friend'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Swords className="w-3.5 h-3.5 text-rose-500" />
            <span>Friend Duel</span>
          </button>
        </div>

        {/* Mode Explanations & Friend Selection */}
        {gameMode === 'solo' ? (
          <div className="w-full bg-blue-50/80 border border-blue-100 rounded-2xl p-4 mb-4 text-left">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <h4 className="text-xs font-black text-blue-950 uppercase tracking-wider">Solo Game (No Computer)</h4>
            </div>
            <p className="text-xs text-blue-800/80 leading-relaxed">
              Play directly without a computer opponent. Answer 5 questions within 6 seconds each. Score at least 3 points out of 5 to win!
            </p>
          </div>
        ) : (
          <div className="w-full flex flex-col gap-2.5 mb-4 text-left">
            <div className="flex items-center justify-between px-1">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-500">
                Choose Friend Opponent:
              </label>
              {selectedFriend && (
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 ${
                  selectedFriend.isOnline ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${selectedFriend.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                  <span>{selectedFriend.isOnline ? 'ONLINE' : 'OFFLINE'}</span>
                </span>
              )}
            </div>
            
            {friendsList.length > 0 ? (
              <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                {friendsList.map((fr) => {
                  const isSelected = selectedFriend?.username === fr.username;
                  return (
                    <button
                      key={fr.id}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        setSelectedFriend(fr);
                      }}
                      className={`flex flex-col items-center p-2 rounded-2xl border transition-all cursor-pointer min-w-[76px] shrink-0 relative ${
                        isSelected
                          ? 'bg-indigo-50 border-indigo-500 shadow-sm ring-2 ring-indigo-400/20'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="relative mb-1">
                        <img
                          src={fr.avatar}
                          alt={fr.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-full bg-white shadow-xs border border-slate-100"
                        />
                        {/* Real-time Login Presence Indicator */}
                        {fr.isOnline ? (
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" title="Online (Logged In)" />
                        ) : (
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-rose-500 border-2 border-white" title="Offline (Not Logged In)" />
                        )}
                      </div>
                      <span className="text-[10px] font-bold text-slate-800 truncate max-w-[68px]">
                        {fr.name.split(' ')[0]}
                      </span>
                      <span className={`text-[8px] font-black uppercase ${fr.isOnline ? 'text-emerald-600' : 'text-slate-400'}`}>
                        {fr.isOnline ? 'Online' : 'Offline'}
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
                No friends added yet. Please add a friend from the top bar!
              </div>
            )}

            {/* Online Status Info Note */}
            <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>
                Players logged in (like account holder <strong>Md Shahid</strong>) are displayed with green online status.
              </span>
            </div>
          </div>
        )}

        {/* Start Game Button */}
        <button
          id="bridger-start-btn"
          type="button"
          onClick={() => startMatch(gameMode)}
          className="w-full py-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-800 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-lg shadow-indigo-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Sparkles className="w-4 h-4 fill-white" />
          <span>Start {gameMode === 'solo' ? 'Solo Match' : 'Friend Duel'} (5 Rounds)</span>
        </button>

      </div>
    );
  }

  // ==========================================
  // VIEW 2: ACTIVE 5-ROUNDS GAMEPLAY (6s per round)
  // ==========================================
  const timerPercentage = Math.max(0, Math.min(100, (timeLeft / ROUND_TIME_LIMIT) * 100));
  const isUrgentTimer = timeLeft <= 2;

  return (
    <div className="w-full max-w-sm bg-white/95 backdrop-blur-md rounded-3xl p-5 shadow-2xl border border-white flex flex-col items-center select-none relative animate-in fade-in duration-200">
      
      {/* Top Bar */}
      <div className="w-full flex items-center justify-between mb-3">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            setIsGameStarted(false);
          }}
          className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 px-3 py-1 bg-indigo-100 text-indigo-900 rounded-full font-black text-xs">
          <span>ROUND {currentRound} OF {TOTAL_ROUNDS}</span>
        </div>

        {/* 6-Second Clock Indicator */}
        <div className={`flex items-center gap-1 font-mono font-black text-sm px-3 py-1 rounded-xl transition-colors ${
          isUrgentTimer 
            ? 'bg-rose-100 text-rose-700 animate-pulse' 
            : 'bg-slate-100 text-slate-800'
        }`}>
          <Timer className={`w-3.5 h-3.5 ${isUrgentTimer ? 'text-rose-600' : 'text-indigo-600'}`} />
          <span>{timeLeft}s</span>
        </div>
      </div>

      {/* 6-Second Timer Bar */}
      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-3.5 border border-slate-200/60 shadow-inner">
        <div 
          className={`h-full transition-all duration-300 rounded-full ${
            isUrgentTimer 
              ? 'bg-rose-500 shadow-sm shadow-rose-500/50' 
              : 'bg-gradient-to-r from-indigo-500 to-purple-600'
          }`}
          style={{ width: `${timerPercentage}%` }}
        />
      </div>

      {/* Point Scoreboard: 1 Point per Round (≥3 Points to Win) */}
      <div className="w-full grid grid-cols-2 gap-2 mb-3">
        {/* User Card */}
        <div className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
          <img
            src={user.avatar}
            alt={user.name}
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-full bg-white shadow-xs border border-slate-200 shrink-0"
          />
          <div className="flex-1 min-w-0 text-left">
            <span className="text-[11px] font-black text-slate-800 truncate block">
              {user.name?.split(' ')[0] || 'You'}
            </span>
            <span className="text-xs font-black text-indigo-600 font-mono">
              {userPoints} {userPoints === 1 ? 'Point' : 'Points'}
            </span>
          </div>
        </div>

        {/* Friend Card (or Target in Solo Mode) */}
        {gameMode === 'friend' ? (
          <div className="flex items-center gap-2 p-2.5 bg-rose-50/70 border border-rose-200/80 rounded-2xl">
            <img
              src={selectedFriend?.avatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=bridger_duel'}
              alt={selectedFriend?.name || 'Friend'}
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-full bg-white shadow-xs border border-rose-200 shrink-0"
            />
            <div className="flex-1 min-w-0 text-left">
              <span className="text-[11px] font-black text-slate-800 truncate block">
                {selectedFriend?.name?.split(' ')[0] || 'Friend'}
              </span>
              <span className="text-xs font-black text-rose-600 font-mono">
                {friendPoints} {friendPoints === 1 ? 'Point' : 'Points'}
              </span>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between px-3 py-2 bg-indigo-50/80 border border-indigo-200/80 rounded-2xl">
            <div className="text-left">
              <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider block">
                Win Target
              </span>
              <span className="text-xs font-black text-indigo-950 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-500" />
                ≥ 3 Points
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Questions
              </span>
              <span className="text-xs font-black text-slate-800 font-mono">
                {currentRound}/{TOTAL_ROUNDS}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Question Display Box */}
      {currentQuestion && (
        <div className="w-full p-4.5 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl text-white flex flex-col items-center justify-center shadow-xl my-1 relative overflow-hidden border border-indigo-800/60 min-h-[110px] text-center">
          <div className="flex items-center justify-between w-full mb-1 px-1 text-[10px] font-black uppercase tracking-wider text-indigo-300">
            <span>{currentQuestion.category}</span>
            <span>Question {currentRound}/{TOTAL_ROUNDS}</span>
          </div>

          <p className="text-sm sm:text-base font-black text-indigo-100 leading-snug drop-shadow-sm px-1">
            {currentQuestion.question}
          </p>

          <span className="text-[10px] text-indigo-300/80 italic mt-2">
            💡 {currentQuestion.hint}
          </span>
        </div>
      )}

      {/* DYNAMIC MIDDLE BANNER (Name of whoever answers first / Wrong answer alert) */}
      <div className="w-full min-h-[44px] my-2 flex items-center justify-center">
        {firstAnswerBanner ? (
          <div className={`w-full py-2.5 px-4 rounded-2xl flex items-center justify-center gap-2 text-xs font-black shadow-md animate-in zoom-in-95 duration-150 ${
            firstAnswerBanner.isCorrect
              ? 'bg-emerald-500 text-white shadow-emerald-500/25'
              : 'bg-rose-500 text-white shadow-rose-500/25 animate-shake'
          }`}>
            {firstAnswerBanner.isCorrect ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 shrink-0" />
            )}
            <span className="truncate">{firstAnswerBanner.text}</span>
          </div>
        ) : (
          <div className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
            <span>Answer first in 6 seconds to win the point!</span>
          </div>
        )}
      </div>

      {/* 4 Rapid Options Selection Grid */}
      <div className="grid grid-cols-2 gap-2.5 w-full mt-1">
        {currentQuestion?.options.map((optionText, idx) => {
          const isSelected = userSelectedOption === idx;
          const isCorrectAnswer = idx === currentQuestion.correctIndex;

          let buttonStyle = "bg-slate-100 hover:bg-slate-200/90 text-slate-800 border-slate-200";
          if (isRoundLocked && isCorrectAnswer) {
            buttonStyle = "bg-emerald-500 text-white border-emerald-600 shadow-md scale-102";
          } else if (isSelected && !isCorrectAnswer) {
            buttonStyle = "bg-rose-500 text-white border-rose-600 animate-shake";
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isRoundLocked}
              onClick={() => handleUserSelectOption(idx)}
              className={`py-3.5 px-2 rounded-2xl font-bold text-xs border-2 transition-all duration-150 cursor-pointer shadow-xs active:scale-95 disabled:cursor-not-allowed flex items-center justify-center text-center ${buttonStyle}`}
            >
              {optionText}
            </button>
          );
        })}
      </div>

      {/* ==========================================
          CENTER RESULT POPUP MODAL (5-Round Outcome)
          ========================================== */}
      {isMatchFinished && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xs bg-white rounded-3xl p-6 border-2 border-white shadow-2xl text-center flex flex-col items-center gap-4 animate-in zoom-in-95 duration-200">
            
            {/* Status Icon & Title */}
            <div className="flex flex-col items-center">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-2 shadow-inner ${
                gameMode === 'solo'
                  ? userPoints >= 3
                    ? 'bg-emerald-100 text-emerald-600'
                    : 'bg-rose-100 text-rose-600'
                  : matchWinner === 'user'
                  ? 'bg-emerald-100 text-emerald-600'
                  : matchWinner === 'friend'
                  ? 'bg-rose-100 text-rose-600'
                  : 'bg-amber-100 text-amber-600'
              }`}>
                {gameMode === 'solo' ? (
                  userPoints >= 3 ? <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" /> : <XCircle className="w-8 h-8 text-rose-600" />
                ) : matchWinner === 'user' ? (
                  <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" />
                ) : matchWinner === 'friend' ? (
                  <Swords className="w-8 h-8 text-rose-600" />
                ) : (
                  <Sparkles className="w-8 h-8 text-amber-600" />
                )}
              </div>
              
              <h2 className={`text-2xl font-black tracking-tight ${
                gameMode === 'solo'
                  ? userPoints >= 3 ? 'text-emerald-600' : 'text-rose-600'
                  : matchWinner === 'user'
                  ? 'text-emerald-600'
                  : matchWinner === 'friend'
                  ? 'text-rose-600'
                  : 'text-amber-600'
              }`}>
                {gameMode === 'solo' 
                  ? (userPoints >= 3 ? 'Win' : 'Loose')
                  : matchWinner === 'user' 
                  ? 'Win' 
                  : matchWinner === 'friend' 
                  ? 'Loose' 
                  : 'Draw'}
              </h2>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">
                {gameMode === 'solo'
                  ? (userPoints >= 3 ? `You won with ${userPoints} points (≥ 3)!` : `You lost with ${userPoints} points (≤ 2).`)
                  : matchWinner === 'user'
                  ? `You won with ${userPoints} points against ${selectedFriend?.name || 'Friend'}!`
                  : matchWinner === 'friend'
                  ? `${selectedFriend?.name || 'Friend'} won with ${friendPoints} points!`
                  : 'Both finished with equal points!'}
              </p>
            </div>

            {/* Middle Screen / Card showing final points & rule summary */}
            <div className="w-full bg-gradient-to-b from-slate-50 to-slate-100/90 rounded-2xl p-4 border border-slate-200 shadow-inner flex flex-col items-center justify-center">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-500" />
                <span>{gameMode === 'solo' ? 'Your Points (out of 5)' : 'Final Points'}</span>
              </span>
              <div className="text-4xl font-black font-mono text-indigo-600 bg-white px-6 py-2 rounded-xl shadow-xs border border-indigo-100 my-1">
                {userPoints} {gameMode === 'friend' ? ` - ${friendPoints}` : ' / 5'}
              </div>
              <span className="text-[10px] text-slate-500 mt-1">
                {userPoints >= 3 ? '🎉 3 or more points = VICTORY' : '💔 2 points or less = DEFEAT'}
              </span>
            </div>

            {/* Primary Retry Button */}
            <button
              id="bridger-retry-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                if (onRetry) {
                  onRetry();
                } else {
                  setIsGameStarted(false);
                }
              }}
              className="w-full py-3.5 bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-800 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-indigo-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry</span>
            </button>

            {/* Back to Home Button */}
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                onBack();
              }}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Back to Home
            </button>

          </div>
        </div>
      )}

    </div>
  );
};
