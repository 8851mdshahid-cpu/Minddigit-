import React from 'react';
import { Check, Coins, UserPlus, Bell, Code2 } from 'lucide-react';
import { MinddigitEmblem } from './MinddigitEmblem';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { getFrameById } from '../utils/frames';

interface NavbarProps {
  user: UserProfile;
  onOpenStats: () => void;
  onOpenTokens?: () => void;
  onOpenAddFriend?: () => void;
  onOpenNotifications?: () => void;
  onOpenSourceCode?: () => void;
  pendingRequestsCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onOpenStats,
  onOpenTokens,
  onOpenAddFriend,
  onOpenNotifications,
  onOpenSourceCode,
  pendingRequestsCount = 0,
}) => {
  // Extract user initial ('M' for Md Shahid or first character)
  const userInitial = user.name ? user.name.trim().charAt(0).toUpperCase() : 'M';
  const activeFrame = getFrameById(user.avatarFrame);

  return (
    <header className="w-full sticky top-0 z-40 bg-white/85 backdrop-blur-md border-b border-white/60 shadow-xs px-2.5 sm:px-4 py-2 select-none">
      <div className="max-w-md mx-auto flex items-center justify-between gap-1.5">
        
        {/* Left: App Logo with circular emblem & MindDigit title */}
        <div className="flex items-center gap-1.5 sm:gap-2 select-none shrink-0">
          <MinddigitEmblem size={32} />
          <div className="flex items-center">
            <span className="font-black text-base sm:text-xl tracking-tight text-slate-900">
              Mind<span className="text-blue-600">Digit</span>
            </span>
          </div>
        </div>

        {/* Right Section: Add Friend (+) Button, Bell Notification Icon, Tokens Pill, Code Viewer, & Avatar */}
        <div className="flex items-center gap-1 sm:gap-2">
          
          {/* Source Code Viewer Button */}
          {onOpenSourceCode && (
            <button
              id="navbar-source-code-btn"
              type="button"
              onClick={() => {
                sound.playPop();
                onOpenSourceCode();
              }}
              className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-blue-600 border border-slate-200 rounded-full transition-all cursor-pointer active:scale-95 flex items-center justify-center"
              title="View App Code (HTML, CSS, TypeScript)"
            >
              <Code2 className="w-4 h-4 text-blue-600" />
            </button>
          )}

          {/* 1. ADD FRIEND (+) BUTTON IN OPEN NAVIGATION */}
          {onOpenAddFriend && (
            <button
              id="navbar-add-friend-btn"
              type="button"
              onClick={() => {
                sound.playPop();
                onOpenAddFriend();
              }}
              className="flex items-center gap-1 bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-200 text-blue-700 px-2 sm:px-2.5 py-1 rounded-full shadow-2xs cursor-pointer transition-all active:scale-95 text-xs font-black"
              title="Add Friend - Search User ID"
            >
              <UserPlus className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden xs:inline sm:inline">Add Friend</span>
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-black">
                +
              </span>
            </button>
          )}

          {/* 2. NOTIFICATIONS BELL ICON (Shows incoming friend requests) */}
          {onOpenNotifications && (
            <button
              id="navbar-notifications-bell"
              type="button"
              onClick={() => {
                sound.playPop();
                onOpenNotifications();
              }}
              className="relative p-1.5 bg-slate-50 hover:bg-purple-50 text-slate-600 hover:text-purple-700 border border-slate-200 hover:border-purple-300 rounded-full transition-colors cursor-pointer active:scale-95"
              title={pendingRequestsCount > 0 ? `${pendingRequestsCount} Friend Request(s)` : 'Notifications & Friend Requests'}
            >
              <Bell className={`w-4 h-4 ${pendingRequestsCount > 0 ? 'text-purple-600 animate-wiggle' : ''}`} />
              {pendingRequestsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[9px] font-black flex items-center justify-center border-2 border-white animate-pulse">
                  {pendingRequestsCount}
                </span>
              )}
            </button>
          )}

          {/* 3. Tokens Balance Pill directly in header */}
          <button
            id="navbar-tokens-badge"
            type="button"
            onClick={() => {
              sound.playPop();
              if (onOpenTokens) onOpenTokens();
              else onOpenStats();
            }}
            className="flex items-center gap-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-2 sm:px-2.5 py-1 rounded-full shadow-2xs cursor-pointer transition-all active:scale-95"
            title={`${user.coins} Tokens - Click to earn more`}
          >
            <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span className="text-xs font-black text-amber-900">{user.coins} 🪙</span>
          </button>

          {/* 4. User Avatar with Frame */}
          <div 
            id="user-profile-badge"
            onClick={() => {
              sound.playPop();
              onOpenStats();
            }}
            className="relative cursor-pointer group select-none shrink-0"
            title={`${user.name} (@${user.username}) - Click to view ID & Settings`}
          >
            <div className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gradient-to-tr from-stone-800 to-stone-900 text-amber-200 font-serif font-black text-xs sm:text-sm flex items-center justify-center transition-all group-hover:scale-105 ${activeFrame.borderClass}`}>
              <span>{userInitial}</span>
              {activeFrame.badgeEmoji && (
                <span className="absolute -top-1.5 -right-1 text-[10px]">
                  {activeFrame.badgeEmoji}
                </span>
              )}
            </div>
            {/* Online pulsing tick on avatar corner */}
            <div 
              className="absolute -bottom-0.5 -right-0.5 bg-emerald-500 text-white rounded-full p-0.5 border border-white shadow-xs flex items-center justify-center"
              title="Online"
            >
              <Check className="w-2 h-2 stroke-[3.5]" />
            </div>
          </div>

        </div>

      </div>
    </header>
  );
};



