import React from 'react';
import { X, Trophy, Flame, Coins, Gamepad2, Award, LogOut, Volume2, VolumeX, HelpCircle, Check, ShieldCheck, Code2, Palette } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { getFrameById } from '../utils/frames';

interface UserStatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenRules: () => void;
  onOpenSourceCode?: () => void;
  onOpenFrameCustomizer?: () => void;
  onLogout: () => void;
}

export const UserStatsModal: React.FC<UserStatsModalProps> = ({
  isOpen,
  onClose,
  user,
  isMuted,
  onToggleMute,
  onOpenRules,
  onOpenSourceCode,
  onOpenFrameCustomizer,
  onLogout,
}) => {
  if (!isOpen) return null;

  const winRate = user.gamesPlayed > 0 
    ? Math.round((user.gamesWon / user.gamesPlayed) * 100) 
    : 0;

  const userInitial = user.name ? user.name.trim().charAt(0).toUpperCase() : 'M';
  const activeFrame = getFrameById(user.avatarFrame);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-sm bg-white rounded-[32px] p-6 shadow-2xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header Actions (Speaker Sound Toggle, Question Mark Rules, Close) */}
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            {/* 1. Speaker / Sound Toggle inside ID */}
            <button
              id="id-sound-toggle-button"
              type="button"
              onClick={() => {
                onToggleMute();
                sound.playClick();
              }}
              className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer ${
                isMuted
                  ? 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                  : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
              }`}
              title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-blue-600" />}
              <span>{isMuted ? 'Muted' : 'Sound ON'}</span>
            </button>

            {/* 2. Question Mark / Help Rules inside ID */}
            <button
              id="id-rules-button"
              type="button"
              onClick={() => {
                sound.playPop();
                onClose();
                onOpenRules();
              }}
              className="p-2 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200/80 text-amber-800 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
              title="How to play / Game Rules"
            >
              <HelpCircle className="w-4 h-4 text-amber-600" />
              <span>Rules</span>
            </button>
          </div>

          {/* Close button */}
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Profile Card */}
        <div className="flex flex-col items-center text-center mb-4">
          <div className="relative mb-2.5">
            <div className={`relative w-16 h-16 rounded-full bg-gradient-to-tr from-stone-800 via-stone-900 to-black text-amber-200 font-serif font-black text-2xl flex items-center justify-center transition-all ${activeFrame.borderClass}`}>
              <span>{userInitial}</span>
              {activeFrame.badgeEmoji && (
                <span className="absolute -top-2 -right-1 text-base drop-shadow-xs">
                  {activeFrame.badgeEmoji}
                </span>
              )}
            </div>
            {/* Blinking Live Tick Badge */}
            <div className="absolute -bottom-1 -right-1 bg-emerald-500 text-white rounded-full p-1 border-2 border-white shadow-xs flex items-center justify-center">
              <Check className="w-3 h-3 stroke-[3.5]" />
            </div>
          </div>
          
          <h3 className="font-extrabold text-lg text-slate-900 flex items-center gap-1.5">
            {user.name}
            {user.isAdmin && (
              <span className="text-[10px] font-black bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-300">
                ADMIN
              </span>
            )}
          </h3>

          <div className="flex items-center gap-2 mt-1">
            {user.username && (
              <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
                User ID: @{user.username}
              </span>
            )}
            
            {onOpenFrameCustomizer && (
              <button
                type="button"
                onClick={() => {
                  sound.playPop();
                  onOpenFrameCustomizer();
                }}
                className="text-[11px] font-bold text-amber-800 bg-amber-100/90 hover:bg-amber-200 border border-amber-300 px-2.5 py-0.5 rounded-full flex items-center gap-1 transition-all cursor-pointer shadow-2xs active:scale-95"
                title="Change Avatar Frame"
              >
                <Palette className="w-3 h-3 text-amber-600" />
                <span>चेंज फ्रेम</span>
              </button>
            )}
          </div>
          <span className="text-xs text-slate-400 font-medium mt-1">{user.email}</span>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 text-center">
            <Coins className="w-4 h-4 text-amber-500 mx-auto mb-1" />
            <div className="text-lg font-black font-mono text-slate-900">{user.coins}</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Total Coins</div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 text-center">
            <Trophy className="w-4 h-4 text-blue-500 mx-auto mb-1" />
            <div className="text-lg font-black font-mono text-slate-900">{user.score}</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Highest Score</div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 text-center">
            <Flame className="w-4 h-4 text-orange-500 mx-auto mb-1" />
            <div className="text-lg font-black font-mono text-slate-900">{user.currentStreak}</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Current Streak</div>
          </div>

          <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 text-center">
            <Award className="w-4 h-4 text-purple-500 mx-auto mb-1" />
            <div className="text-lg font-black font-mono text-slate-900">{user.bestStreak}</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Best Streak</div>
          </div>
        </div>

        {/* Total Games & Winrate */}
        <div className="mt-2.5 bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-around">
          <div className="text-center">
            <Gamepad2 className="w-4 h-4 text-slate-600 mx-auto mb-1" />
            <div className="text-base font-black font-mono text-slate-900">{user.gamesPlayed}</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Played</div>
          </div>
          <div className="h-6 w-px bg-slate-200" />
          <div className="text-center">
            <div className="text-base font-black font-mono text-emerald-600">{winRate}%</div>
            <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">Win Rate</div>
          </div>
        </div>

        {/* View Source Code Button */}
        {onOpenSourceCode && (
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
              onOpenSourceCode();
            }}
            className="w-full mt-2.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-black rounded-xl flex items-center justify-center gap-2 border border-slate-200 transition-all cursor-pointer active:scale-98"
          >
            <Code2 className="w-4 h-4 text-blue-600" />
            <span>View Full App Source Code (HTML, CSS, TS)</span>
          </button>
        )}

        {/* Action Buttons: Logout & Close */}
        <div className="mt-4 flex items-center gap-2">
          <button
            id="modal-logout-button"
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
              onLogout();
            }}
            className="flex-1 py-3 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-black rounded-xl flex items-center justify-center gap-1.5 border border-rose-200/60 transition-all cursor-pointer active:scale-98"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout Account</span>
          </button>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="flex-1 py-3 bg-slate-900 text-white text-xs font-bold rounded-xl hover:bg-slate-800 active:scale-98 transition-all cursor-pointer"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};

