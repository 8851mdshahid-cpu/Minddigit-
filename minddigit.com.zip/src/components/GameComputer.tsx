import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { ArrowLeft, RefreshCw, Lightbulb, Sparkles, Coins, Bot, User, Check, Timer, ArrowUp, ArrowDown, Lock, Key, ChevronRight, HelpCircle, Dices, RotateCcw, Trophy } from 'lucide-react';
import { DifficultyLevel, UserProfile } from '../types';
import { sound } from '../utils/audio';
import { GuessNumberBadge } from './GuessNumberBadge';

interface GuessItem {
  who: 'You' | 'Computer';
  guess: number;
  direction: 'higher' | 'lower' | 'correct';
  timestamp: number;
}

interface GameComputerProps {
  difficulty: DifficultyLevel;
  user: UserProfile;
  onBack: () => void;
  onGameEnd: (won: boolean, score: number, coins: number) => void;
  onRetry?: () => void;
}

export const GameComputer: React.FC<GameComputerProps> = ({
  difficulty,
  user,
  onBack,
  onGameEnd,
  onRetry,
}) => {
  const maxRange = difficulty === 'easy' ? 50 : difficulty === 'hard' ? 500 : 100;
  const tokenReward = difficulty === 'easy' ? 10 : difficulty === 'normal' ? 20 : 50;
  const maxChances = 10;
  const turnTimerLimit = 25; // 25-second timer per turn

  // Phases: 'setup_number' -> 'playing' -> 'won' | 'lost' | 'draw'
  const [gamePhase, setGamePhase] = useState<'setup_number' | 'playing' | 'won' | 'lost' | 'draw'>('setup_number');
  
  // Secret numbers
  const [userSecretNumber, setUserSecretNumber] = useState<number | null>(null);
  const [computerSecretNumber, setComputerSecretNumber] = useState<number>(0);
  
  // Input states
  const [setupInput, setSetupInput] = useState<string>('');
  const [currentInput, setCurrentInput] = useState<string>('');
  const [setupError, setSetupError] = useState<string>('');
  
  // Turn & Timer
  const [turn, setTurn] = useState<'user' | 'computer'>('user');
  const [timeLeft, setTimeLeft] = useState<number>(turnTimerLimit);
  
  // 10 Chances tracking
  const [userChancesLeft, setUserChancesLeft] = useState<number>(maxChances);
  const [computerChancesLeft, setComputerChancesLeft] = useState<number>(maxChances);
  
  const [userLastGuess, setUserLastGuess] = useState<number | null>(null);
  const [computerLastGuess, setComputerLastGuess] = useState<number | null>(null);

  const [feedback, setFeedback] = useState<string>(`Type your secret number between 1 and ${maxRange}!`);
  const [hintUsed, setHintUsed] = useState<boolean>(false);
  const [hintText, setHintText] = useState<string>('');
  
  // Horizontal Sliding Guesses History
  const [history, setHistory] = useState<GuessItem[]>([]);
  const slidingBoxRef = useRef<HTMLDivElement>(null);

  // Auto-scroll sliding box to end when new guess is made
  useEffect(() => {
    if (slidingBoxRef.current) {
      slidingBoxRef.current.scrollTo({
        left: slidingBoxRef.current.scrollWidth,
        behavior: 'smooth',
      });
    }
  }, [history]);

  const initGame = () => {
    const compSecret = Math.floor(Math.random() * maxRange) + 1;
    setComputerSecretNumber(compSecret);
    setUserSecretNumber(null);
    setSetupInput('');
    setSetupError('');
    setUserChancesLeft(maxChances);
    setComputerChancesLeft(maxChances);
    setUserLastGuess(null);
    setComputerLastGuess(null);
    setHistory([]);
    setTurn('user');
    setTimeLeft(turnTimerLimit);
    setGamePhase('setup_number');
    setCurrentInput('');
    setFeedback(`Step 1: Type your number (1-${maxRange}) for the AI to guess!`);
    setHintUsed(false);
    setHintText('');
  };

  useEffect(() => {
    initGame();
  }, [difficulty]);

  // Handle User Confirming Their Secret Number (Step 1)
  const handleConfirmSecretNumber = (numToSet?: number) => {
    const rawVal = numToSet !== undefined ? numToSet : parseInt(setupInput, 10);
    if (isNaN(rawVal) || rawVal < 1 || rawVal > maxRange) {
      sound.playLose();
      setSetupError(`Please enter a valid number between 1 and ${maxRange}`);
      return;
    }

    sound.playWin();
    setUserSecretNumber(rawVal);
    setSetupError('');
    setGamePhase('playing');
    setTurn('user');
    setTimeLeft(turnTimerLimit);
    setFeedback(`Your number is locked (${rawVal})! Guess AI's number in 25s (1-${maxRange}).`);
  };

  // 25s Timer Countdown
  useEffect(() => {
    if (gamePhase !== 'playing') return;
    if (timeLeft <= 0) {
      if (turn === 'user') {
        sound.playLose();
        setFeedback(`⏰ 25s timer expired! Computer's turn.`);
        setTurn('computer');
        setTimeLeft(turnTimerLimit);
      } else {
        setFeedback(`⏰ Computer time up! Your turn.`);
        setTurn('user');
        setTimeLeft(turnTimerLimit);
      }
      return;
    }

    const timer = setTimeout(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [gamePhase, turn, timeLeft, turnTimerLimit]);

  // Computer Turn Logic (Computer tries to guess user's secret number)
  useEffect(() => {
    if (gamePhase !== 'playing' || turn !== 'computer') return;

    const timeout = setTimeout(() => {
      const targetUserSecret = userSecretNumber || 50;
      // Smart AI guess around user's secret
      let compGuess: number;
      if (Math.random() < 0.35) {
        // AI makes an educated guess
        const jitter = Math.floor(Math.random() * 15) - 7;
        compGuess = Math.max(1, Math.min(maxRange, targetUserSecret + jitter));
      } else {
        compGuess = Math.floor(Math.random() * maxRange) + 1;
      }

      const rem = computerChancesLeft - 1;
      setComputerChancesLeft(rem);
      setComputerLastGuess(compGuess);

      if (compGuess === targetUserSecret) {
        sound.playLose();
        setGamePhase('lost');
        setFeedback(`🤖 Computer guessed your number (${compGuess}) correctly!`);
        onGameEnd(false, 30, 1);
        return;
      }

      const direction = compGuess < targetUserSecret ? 'higher' : 'lower';
      const newHistoryItem: GuessItem = {
        who: 'Computer',
        guess: compGuess,
        direction,
        timestamp: Date.now(),
      };
      setHistory((prev) => [...prev, newHistoryItem]);
      setFeedback(`Computer guessed ${compGuess} (${direction === 'higher' ? '▲ Higher' : '▼ Lower'}). Your turn!`);

      if (rem <= 0 && userChancesLeft <= 0) {
        setGamePhase('draw');
        setFeedback(`Both used all 10 chances! AI's secret was ${computerSecretNumber}.`);
        onGameEnd(false, 20, 1);
        return;
      }

      setTurn('user');
      setTimeLeft(turnTimerLimit);
    }, 1500);

    return () => clearTimeout(timeout);
  }, [turn, gamePhase, computerChancesLeft, userChancesLeft, userSecretNumber, computerSecretNumber, maxRange]);

  // User Guess Submission (User tries to guess computer's secret number)
  const handleUserGuess = () => {
    if (turn !== 'user' || gamePhase !== 'playing') return;

    const num = parseInt(currentInput, 10);
    if (isNaN(num) || num < 1 || num > maxRange) {
      sound.playLose();
      setFeedback(`Please enter a valid number between 1 and ${maxRange}`);
      return;
    }

    const rem = userChancesLeft - 1;
    setUserChancesLeft(rem);
    setUserLastGuess(num);
    setCurrentInput('');

    if (num === computerSecretNumber) {
      sound.playWin();
      confetti({ particleCount: 150, spread: 85, origin: { y: 0.6 } });
      setGamePhase('won');
      setFeedback(`🎉 BINGO! You guessed the AI's secret number ${computerSecretNumber}! You won +${tokenReward} Tokens!`);
      const newHistoryItem: GuessItem = {
        who: 'You',
        guess: num,
        direction: 'correct',
        timestamp: Date.now(),
      };
      setHistory((prev) => [...prev, newHistoryItem]);
      onGameEnd(true, 400 + rem * 30, tokenReward);
      return;
    }

    const direction = num < computerSecretNumber ? 'higher' : 'lower';
    if (direction === 'higher') sound.playHigher();
    else sound.playLower();

    const newHistoryItem: GuessItem = {
      who: 'You',
      guess: num,
      direction,
      timestamp: Date.now(),
    };
    setHistory((prev) => [...prev, newHistoryItem]);
    setFeedback(`You guessed ${num} (${direction === 'higher' ? '▲ Higher' : '▼ Lower'}). Computer's turn!`);

    if (rem <= 0 && computerChancesLeft <= 0) {
      setGamePhase('draw');
      setFeedback(`Both players used all 10 chances! Secret was ${computerSecretNumber}.`);
      onGameEnd(false, 20, 1);
      return;
    }

    setTurn('computer');
    setTimeLeft(turnTimerLimit);
  };

  const handleKeypadPress = (digit: string) => {
    sound.playClick();
    if (gamePhase === 'setup_number') {
      if (setupInput.length < 4) {
        setSetupInput((prev) => prev + digit);
        if (setupError) setSetupError('');
      }
      return;
    }

    if (turn !== 'user' || gamePhase !== 'playing') return;
    if (currentInput.length < 4) {
      setCurrentInput((prev) => prev + digit);
    }
  };

  const handleKeypadClear = () => {
    sound.playClick();
    if (gamePhase === 'setup_number') {
      setSetupInput('');
      setSetupError('');
    } else {
      setCurrentInput('');
    }
  };

  const handleGetHint = () => {
    if (hintUsed || gamePhase !== 'playing') return;
    sound.playPop();
    setHintUsed(true);

    const isEven = computerSecretNumber % 2 === 0;
    setHintText(`💡 Hint: The secret is ${isEven ? 'EVEN' : 'ODD'} & within 1-${maxRange}`);
  };

  return (
    <div className="w-full max-w-md mx-auto px-3 sm:px-4 pt-2 pb-24 select-none font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Top Bar with Difficulty Badge and Timer & Your Secret Number Display */}
      <div className="flex items-center justify-between mb-3 px-1">
        <button
          id="computer-back-button"
          type="button"
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/70 backdrop-blur-xs border border-white text-slate-700 font-bold text-xs hover:bg-white transition-all shadow-2xs cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Exit Game</span>
        </button>

        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-black uppercase px-2.5 py-1 rounded-full bg-white/80 border border-white text-blue-700 shadow-2xs">
            {difficulty} (1-{maxRange})
          </span>
          <span className="text-[11px] font-black px-2.5 py-1 rounded-full bg-amber-100 border border-amber-200 text-amber-900 flex items-center gap-1 shadow-2xs">
            <Coins className="w-3 h-3 text-amber-500 fill-amber-400" />
            <span>+{tokenReward}</span>
          </span>
        </div>

        {/* 25s Timer */}
        <div className={`flex items-center gap-1 px-3 py-1 rounded-full font-black text-xs shadow-2xs ${
          timeLeft <= 5 ? 'bg-rose-500 text-white animate-pulse' : 'bg-white/80 text-slate-800'
        }`}>
          <Timer className="w-3.5 h-3.5" />
          <span>{gamePhase === 'setup_number' ? '25s' : `${timeLeft}s`}</span>
        </div>
      </div>

      {/* Prominent Header Banner Showing "Your number is: XX" in the Countdown/Status Counter */}
      {userSecretNumber !== null && (
        <div className="mb-3 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-2.5 rounded-2xl shadow-md border border-white/40 flex items-center justify-between animate-in fade-in duration-300">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
              <Lock className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-100 block">
                Your Secret Number
              </span>
              <span className="text-sm font-black tracking-tight text-white">
                Your number is: <span className="font-mono text-amber-300 text-base">{userSecretNumber}</span>
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[9px] font-bold text-blue-200 uppercase block">Opponent Secret</span>
            <span className="text-xs font-black font-mono text-white/90 bg-white/10 px-2 py-0.5 rounded-md">
              {gamePhase === 'won' || gamePhase === 'lost' ? computerSecretNumber : '?? (Hidden)'}
            </span>
          </div>
        </div>
      )}

      {/* STEP 1: "TYPE YOUR NUMBER" SETUP SCREEN */}
      {gamePhase === 'setup_number' && (
        <div className="bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-white shadow-lg flex flex-col gap-4 text-center mb-3 animate-in zoom-in-95 duration-200">
          <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 mx-auto flex items-center justify-center shadow-inner">
            <Key className="w-6 h-6" />
          </div>

          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
              Step 1: Game Setup
            </span>
            <h2 className="text-lg font-black text-slate-900 mt-1.5">
              Type Your Number
            </h2>
            <p className="text-xs font-medium text-slate-500 mt-1 max-w-xs mx-auto">
              Enter your secret number (1-{maxRange}). The AI will try to guess your number, while you guess the AI's number!
            </p>
          </div>

          {/* Number Display Box */}
          <div className="bg-slate-50 border-2 border-blue-400/80 rounded-2xl py-3 px-4 flex items-center justify-center">
            <input
              id="setup-secret-number-input"
              type="text"
              readOnly
              value={setupInput}
              placeholder="e.g. 55"
              className="w-full text-center text-3xl font-black font-mono text-blue-700 bg-transparent outline-none placeholder:text-slate-300"
            />
          </div>

          {setupError && (
            <p className="text-xs font-bold text-rose-600 bg-rose-50 py-1 px-3 rounded-xl border border-rose-200">
              {setupError}
            </p>
          )}

          {/* Quick Choice / Randomizer */}
          <div className="flex items-center justify-center gap-1.5 flex-wrap">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Quick pick:</span>
            {[25, 42, 55, 77].filter((n) => n <= maxRange).map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => {
                  sound.playPop();
                  setSetupInput(num.toString());
                  if (setupError) setSetupError('');
                }}
                className="px-2.5 py-1 bg-white hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-700 cursor-pointer shadow-2xs active:scale-95"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                sound.playPop();
                const rand = Math.floor(Math.random() * maxRange) + 1;
                setSetupInput(rand.toString());
                if (setupError) setSetupError('');
              }}
              className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl text-xs font-bold text-amber-800 cursor-pointer shadow-2xs flex items-center gap-1 active:scale-95"
            >
              <Dices className="w-3 h-3 text-amber-600" />
              <span>Random</span>
            </button>
          </div>

          {/* Confirm Button */}
          <button
            id="confirm-secret-number-btn"
            type="button"
            onClick={() => handleConfirmSecretNumber()}
            className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-blue-500/25 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Lock Number & Start Guessing</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2-Player Heads Up: You (@username) with tick vs Computer with ? */}
      {gamePhase !== 'setup_number' && (
        <div className="grid grid-cols-2 gap-2.5 mb-3">
          {/* YOU */}
          <div className={`p-3 rounded-2xl border transition-all relative ${
            turn === 'user'
              ? 'bg-blue-50/90 border-blue-400 shadow-sm ring-1 ring-blue-400/50'
              : 'bg-white/70 border-white shadow-2xs'
          }`}>
            {/* Small box on the corner of our ID displaying our number selection */}
            <div 
              id="computer-game-user-selection-corner-badge"
              className="absolute -top-2.5 -right-2 bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-xl px-2.5 py-0.5 shadow-md border-2 border-white flex items-center gap-1.5 z-20 animate-in zoom-in-90"
              title="Your selected number"
            >
              <span className="text-[8px] font-black uppercase tracking-wider text-blue-200">Selected:</span>
              <span className="text-xs font-black font-mono tracking-tight bg-white/20 px-1.5 py-0.2 rounded-md">
                {currentInput ? currentInput : userLastGuess !== null ? userLastGuess : userSecretNumber ? userSecretNumber : '--'}
              </span>
            </div>

            <div className="flex items-center gap-2 mb-1.5">
              <div className="relative">
                <div className="w-7 h-7 rounded-full bg-slate-900 text-amber-300 font-serif font-black text-xs flex items-center justify-center">
                  {user.name ? user.name.charAt(0).toUpperCase() : 'M'}
                </div>
                <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full" title="Online" />
              </div>
              <div className="text-left overflow-hidden">
                <div className="text-xs font-black text-slate-900 truncate">{user.name}</div>
                <div className="text-[9px] font-mono text-blue-600 truncate">@{user.username}</div>
              </div>
            </div>
            <div className="text-[10px] font-bold text-slate-500 flex justify-between mb-1">
              <span>Chances:</span>
              <span className="font-black text-blue-700">{userChancesLeft}/10</span>
            </div>
            <div className="bg-white rounded-xl p-2 border border-slate-100 flex items-center justify-between shadow-2xs">
              <span className="text-sm font-black font-mono">{userLastGuess !== null ? userLastGuess : '--'}</span>
              <div className={`w-5 h-5 rounded-md flex items-center justify-center ${
                userLastGuess !== null ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-300'
              }`}>
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            </div>
          </div>

          {/* COMPUTER */}
          <div className={`p-3 rounded-2xl border transition-all ${
            turn === 'computer'
              ? 'bg-purple-50/90 border-purple-400 shadow-sm ring-1 ring-purple-400/50'
              : 'bg-white/70 border-white shadow-2xs'
          }`}>
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-7 h-7 rounded-full bg-purple-600 text-white font-black text-xs flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="text-left overflow-hidden">
                <div className="text-xs font-black text-slate-900">AI Computer</div>
                <div className="text-[9px] font-mono text-purple-600">@bot_mind</div>
              </div>
            </div>
            <div className="text-[10px] font-bold text-slate-500 flex justify-between mb-1">
              <span>Chances:</span>
              <span className="font-black text-purple-700">{computerChancesLeft}/10</span>
            </div>
            <div className="bg-white rounded-xl p-2 border border-slate-100 flex items-center justify-between shadow-2xs">
              <span className="text-sm font-black font-mono">{computerLastGuess !== null ? computerLastGuess : '?'}</span>
              <div className="w-5 h-5 rounded-md bg-purple-100 text-purple-700 flex items-center justify-center font-black text-xs">
                ?
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Visual Wooden Shield Emblem from User Photo */}
      {gamePhase !== 'setup_number' && (
        <div className="flex justify-center my-1">
          <GuessNumberBadge
            size="md"
            mysteryText={gamePhase === 'won' || gamePhase === 'lost' ? `${computerSecretNumber}` : '??'}
            hintText={hintText || '. HIGHER OR LOWER .'}
            guesses={
              history.length > 0
                ? history.map((h) => ({
                    num: h.guess,
                    dir: h.direction === 'lower' ? 'high' : h.direction === 'higher' ? 'low' : 'equal',
                  }))
                : [
                    { num: 42, dir: 'low' },
                    { num: 55, dir: 'low' },
                    { num: 61, dir: 'low' },
                    { num: 65, dir: 'high' },
                  ]
            }
            lives={userChancesLeft}
          />
        </div>
      )}

      {/* Dialogue Speech Bubble */}
      <div className="w-full bg-[#FCF9F2] border border-[#EBE3D3] rounded-2xl p-2.5 mb-2.5 text-center shadow-xs">
        <p className="text-xs font-extrabold text-slate-800 leading-snug">
          {feedback}
        </p>
        {hintText && (
          <p className="text-[11px] font-bold text-amber-700 mt-1 bg-amber-50 rounded-lg py-0.5 px-2">
            {hintText}
          </p>
        )}
      </div>

      {/* LONG HORIZONTAL SLIDING BOX ABOVE THE TYPING FIELD */}
      {gamePhase !== 'setup_number' && (
        <div className="w-full bg-white/90 backdrop-blur-md rounded-2xl p-2.5 border border-white shadow-sm mb-2.5">
          <div className="flex items-center justify-between mb-1.5 px-1">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1">
              <span>Guess History & Arrows (Slide to view)</span>
            </span>
            <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              {history.length} Guess(es)
            </span>
          </div>

          {/* Horizontally scrollable / sliding carousel track */}
          <div
            ref={slidingBoxRef}
            className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scroll-smooth no-scrollbar"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {history.length === 0 ? (
              <div className="w-full py-2 px-3 text-center text-xs font-medium text-slate-400 bg-slate-50/80 rounded-xl border border-dashed border-slate-200">
                Your guesses with upward (▲ Higher) or downward (▼ Lower) arrows will slide here!
              </div>
            ) : (
              history.map((item, idx) => {
                const isHigher = item.direction === 'higher';
                const isLower = item.direction === 'lower';
                const isCorrect = item.direction === 'correct';

                return (
                  <div
                    key={idx}
                    className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold border shadow-xs transition-transform transform active:scale-95 animate-in slide-in-from-right-4 duration-200 ${
                      isCorrect
                        ? 'bg-amber-100 border-amber-300 text-amber-900 ring-2 ring-amber-400/40'
                        : isHigher
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                        : 'bg-rose-50 border-rose-300 text-rose-900'
                    }`}
                  >
                    <span className="text-[10px] uppercase font-black text-slate-500">
                      {item.who === 'You' ? 'You:' : 'AI:'}
                    </span>
                    <span className="text-sm font-black font-mono">
                      {item.guess}
                    </span>
                    
                    {/* Arrow Indicator: Upward arrow for Higher, Downward arrow for Lower */}
                    <div className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded-md font-black text-[10px] ${
                      isCorrect
                        ? 'bg-amber-500 text-white'
                        : isHigher
                        ? 'bg-emerald-600 text-white'
                        : 'bg-rose-600 text-white'
                    }`}>
                      {isHigher && <ArrowUp className="w-3 h-3 stroke-[3]" />}
                      {isLower && <ArrowDown className="w-3 h-3 stroke-[3]" />}
                      {isCorrect && <span>★</span>}
                      <span>{isHigher ? 'HIGHER' : isLower ? 'LOWER' : 'MATCH'}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Input Field + GUESS Button */}
      <div className="flex items-center gap-2 mb-3">
        <div className="flex-1 bg-white rounded-2xl border-2 border-cyan-400/80 shadow-xs px-4 py-2 flex items-center justify-center">
          <input
            id="number-guess-input"
            type="text"
            readOnly
            value={gamePhase === 'setup_number' ? setupInput : currentInput}
            placeholder={
              gamePhase === 'setup_number'
                ? 'Enter your number...'
                : turn === 'user'
                ? 'Tap Keypad (1-100)...'
                : 'AI Thinking...'
            }
            className="w-full text-center text-xl font-black font-mono text-slate-800 bg-transparent outline-none placeholder:text-slate-300"
          />
        </div>

        <button
          id="guess-action-btn"
          type="button"
          disabled={gamePhase === 'setup_number' ? !setupInput : turn !== 'user' || gamePhase !== 'playing'}
          onClick={gamePhase === 'setup_number' ? () => handleConfirmSecretNumber() : handleUserGuess}
          className={`py-3 px-6 rounded-2xl font-black text-sm tracking-wider uppercase transition-all shadow-md active:scale-95 cursor-pointer ${
            (gamePhase === 'setup_number' && setupInput) || (turn === 'user' && gamePhase === 'playing')
              ? 'bg-[#14B8A6] hover:bg-[#0D9488] text-white shadow-teal-500/25'
              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
          }`}
        >
          {gamePhase === 'setup_number' ? 'SET' : 'GUESS'}
        </button>
      </div>

      {/* Pastel Keypad */}
      <div className="bg-white/60 backdrop-blur-xs rounded-3xl p-3 border border-white shadow-sm flex flex-col gap-2 mb-3">
        {/* Row 1 */}
        <div className="grid grid-cols-6 gap-1.5">
          {[
            { num: '1', bg: 'bg-[#BEE9E8]' },
            { num: '2', bg: 'bg-[#C7F9CC]' },
            { num: '3', bg: 'bg-[#FFF3B0]' },
            { num: '4', bg: 'bg-[#FDE2E4]' },
            { num: '5', bg: 'bg-[#FFD7BA]' },
            { num: '6', bg: 'bg-[#E2ECE9]' },
          ].map(({ num, bg }) => (
            <button
              key={num}
              type="button"
              onClick={() => handleKeypadPress(num)}
              className={`h-11 rounded-2xl ${bg} text-slate-800 font-black text-base flex items-center justify-center shadow-xs hover:brightness-95 active:scale-90 transition-all cursor-pointer`}
            >
              {num}
            </button>
          ))}
        </div>

        {/* Row 2 */}
        <div className="grid grid-cols-6 gap-1.5">
          {[
            { num: '7', bg: 'bg-[#A2D2FF]' },
            { num: '8', bg: 'bg-[#D8F3DC]' },
            { num: '9', bg: 'bg-[#FDF0D5]' },
            { num: '0', bg: 'bg-[#FBC4AB]' },
          ].map(({ num, bg }) => (
            <button
              key={num}
              type="button"
              onClick={() => handleKeypadPress(num)}
              className={`h-11 rounded-2xl ${bg} text-slate-800 font-black text-base flex items-center justify-center shadow-xs hover:brightness-95 active:scale-90 transition-all cursor-pointer`}
            >
              {num}
            </button>
          ))}
          <button
            type="button"
            onClick={handleKeypadClear}
            className="col-span-2 h-11 rounded-2xl bg-white border border-slate-200 text-slate-700 font-black text-xs uppercase flex items-center justify-center shadow-xs hover:bg-slate-50 active:scale-90 transition-all cursor-pointer"
          >
            CLEAR
          </button>
        </div>
      </div>

      {/* Bottom Actions: Clue & Reset */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={handleGetHint}
          disabled={hintUsed || gamePhase !== 'playing'}
          className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
            hintUsed || gamePhase !== 'playing' ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-amber-200 shadow-2xs'
          }`}
        >
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
          <span>{hintUsed ? 'Clue Used' : 'Free Clue'}</span>
        </button>

        <button
          type="button"
          onClick={initGame}
          className="px-3 py-1.5 rounded-xl bg-white/80 border border-slate-200 text-slate-700 hover:bg-white text-xs font-bold flex items-center gap-1.5 shadow-2xs cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
          <span>Restart</span>
        </button>
      </div>

      {/* CENTER RESULT POPUP MODAL (When number is found / game ends) */}
      {(gamePhase === 'won' || gamePhase === 'lost' || gamePhase === 'draw') && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xs bg-white rounded-3xl p-6 border-2 border-white shadow-2xl text-center flex flex-col items-center gap-4 animate-in zoom-in-95 duration-200">
            
            {/* Status Icon & Title */}
            <div className="flex flex-col items-center">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-2 shadow-inner ${
                gamePhase === 'lost'
                  ? 'bg-rose-100 text-rose-600'
                  : gamePhase === 'won'
                  ? 'bg-emerald-100 text-emerald-600'
                  : 'bg-amber-100 text-amber-600'
              }`}>
                {gamePhase === 'lost' ? (
                  <Bot className="w-8 h-8" />
                ) : gamePhase === 'won' ? (
                  <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" />
                ) : (
                  <HelpCircle className="w-8 h-8" />
                )}
              </div>
              
              <h2 className={`text-2xl font-black tracking-tight ${
                gamePhase === 'lost'
                  ? 'text-rose-600'
                  : gamePhase === 'won'
                  ? 'text-emerald-600'
                  : 'text-amber-600'
              }`}>
                {gamePhase === 'lost' ? 'Loose' : gamePhase === 'won' ? 'Win' : 'Draw'}
              </h2>
              <p className="text-xs font-semibold text-slate-500 mt-0.5">
                {gamePhase === 'lost'
                  ? 'AI guessed your number!'
                  : gamePhase === 'won'
                  ? `You found the AI's number! (+${tokenReward} Tokens)`
                  : 'Both ran out of chances!'}
              </p>
            </div>

            {/* Small screen / card showing opponent's number in the middle */}
            <div className="w-full bg-gradient-to-b from-slate-50 to-slate-100/90 rounded-2xl p-4 border border-slate-200 shadow-inner flex flex-col items-center justify-center">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1">
                <Key className="w-3.5 h-3.5 text-slate-400" />
                <span>Opponent's Number</span>
              </span>
              <div className="text-4xl font-black font-mono text-blue-700 bg-white px-6 py-2 rounded-xl shadow-xs border border-blue-100 my-1">
                {computerSecretNumber}
              </div>
            </div>

            {/* Primary Retry Button */}
            <button
              id="computer-game-retry-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                if (onRetry) {
                  onRetry();
                } else {
                  onBack();
                }
              }}
              className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-blue-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry</span>
            </button>

          </div>
        </div>
      )}

    </div>
  );
};

