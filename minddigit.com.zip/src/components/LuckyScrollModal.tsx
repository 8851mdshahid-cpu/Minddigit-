import React, { useState, useEffect, useRef } from 'react';
import { X, Sparkles, Trophy, Flame, Timer, Gift, Play, ArrowRight, RefreshCw, Volume2, Coins } from 'lucide-react';
import { sound } from '../utils/audio';

interface LuckyScrollModalProps {
  isOpen: boolean;
  onClose: () => void;
  userCoins: number;
  onAwardTokens: (amount: number) => void;
}

interface ScrollItem {
  id: number;
  label: string;
  points: number;
  badge: string;
  bgGradient: string;
  borderColor: string;
  textColor: string;
}

// 10 Items configured with exact requested probability:
// - 10-points: 4 out of 10 (40%)
// - 20-points: 1 out of 10 (10%)
// - 2-points: 2 out of 10 (20%)
// - 0-points / Try Again: 3 out of 10 (30%)
export const SCROLL_REEL_ITEMS: ScrollItem[] = [
  { id: 0, label: '10 Tokens', points: 10, badge: '🪙 +10', bgGradient: 'from-blue-500 to-indigo-600', borderColor: 'border-blue-300', textColor: 'text-blue-600' },
  { id: 1, label: '2 Tokens', points: 2, badge: '🪙 +2', bgGradient: 'from-emerald-500 to-teal-600', borderColor: 'border-emerald-300', textColor: 'text-emerald-600' },
  { id: 2, label: '10 Tokens', points: 10, badge: '🪙 +10', bgGradient: 'from-blue-500 to-indigo-600', borderColor: 'border-blue-300', textColor: 'text-blue-600' },
  { id: 3, label: '20 Tokens', points: 20, badge: '⭐ +20 JACKPOT', bgGradient: 'from-amber-500 via-orange-500 to-yellow-500', borderColor: 'border-amber-300', textColor: 'text-amber-600' },
  { id: 4, label: 'Try Again', points: 0, badge: '❌ 0', bgGradient: 'from-slate-500 to-slate-700', borderColor: 'border-slate-300', textColor: 'text-slate-500' },
  { id: 5, label: '10 Tokens', points: 10, badge: '🪙 +10', bgGradient: 'from-blue-500 to-indigo-600', borderColor: 'border-blue-300', textColor: 'text-blue-600' },
  { id: 6, label: '2 Tokens', points: 2, badge: '🪙 +2', bgGradient: 'from-emerald-500 to-teal-600', borderColor: 'border-emerald-300', textColor: 'text-emerald-600' },
  { id: 7, label: 'Try Again', points: 0, badge: '❌ 0', bgGradient: 'from-slate-500 to-slate-700', borderColor: 'border-slate-300', textColor: 'text-slate-500' },
  { id: 8, label: '10 Tokens', points: 10, badge: '🪙 +10', bgGradient: 'from-blue-500 to-indigo-600', borderColor: 'border-blue-300', textColor: 'text-blue-600' },
  { id: 9, label: 'Try Again', points: 0, badge: '❌ 0', bgGradient: 'from-slate-500 to-slate-700', borderColor: 'border-slate-300', textColor: 'text-slate-500' },
];

const STORAGE_SCROLL_KEY = 'minddigit_lucky_scroll_state_v2';

export const LuckyScrollModal: React.FC<LuckyScrollModalProps> = ({
  isOpen,
  onClose,
  userCoins,
  onAwardTokens,
}) => {
  const [chancesLeft, setChancesLeft] = useState<number>(2);
  const [cooldownEnd, setCooldownEnd] = useState<number>(0);
  const [timeRemainingStr, setTimeRemainingStr] = useState<string>('00:00:00');
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [lastWonItem, setLastWonItem] = useState<ScrollItem | null>(null);
  const [showWinConfetti, setShowWinConfetti] = useState<boolean>(false);

  // Strip of duplicated reel items for seamless infinite scroll animation
  const reelContainerRef = useRef<HTMLDivElement>(null);
  const repeatedItems = [
    ...SCROLL_REEL_ITEMS,
    ...SCROLL_REEL_ITEMS,
    ...SCROLL_REEL_ITEMS,
    ...SCROLL_REEL_ITEMS,
    ...SCROLL_REEL_ITEMS,
  ];

  // Load and refresh daily state
  useEffect(() => {
    try {
      const today = new Date().toDateString();
      const raw = localStorage.getItem(STORAGE_SCROLL_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed.lastDate !== today) {
          // New day -> 2 free chances given!
          setChancesLeft(2);
          setCooldownEnd(0);
          localStorage.setItem(STORAGE_SCROLL_KEY, JSON.stringify({ lastDate: today, chancesLeft: 2, cooldownEnd: 0 }));
        } else {
          // Check cooldown
          if (parsed.cooldownEnd && parsed.cooldownEnd > Date.now()) {
            setChancesLeft(parsed.chancesLeft ?? 0);
            setCooldownEnd(parsed.cooldownEnd);
          } else if (parsed.chancesLeft <= 0 && parsed.cooldownEnd <= Date.now()) {
            // Cooldown completed -> reset to 2 chances
            setChancesLeft(2);
            setCooldownEnd(0);
            localStorage.setItem(STORAGE_SCROLL_KEY, JSON.stringify({ lastDate: today, chancesLeft: 2, cooldownEnd: 0 }));
          } else {
            setChancesLeft(parsed.chancesLeft ?? 2);
            setCooldownEnd(parsed.cooldownEnd ?? 0);
          }
        }
      } else {
        // Initial setup -> 2 chances
        setChancesLeft(2);
        setCooldownEnd(0);
        localStorage.setItem(STORAGE_SCROLL_KEY, JSON.stringify({ lastDate: today, chancesLeft: 2, cooldownEnd: 0 }));
      }
    } catch {
      setChancesLeft(2);
    }
  }, [isOpen]);

  // Live Countdown Timer ticking down
  useEffect(() => {
    const timer = setInterval(() => {
      if (cooldownEnd > 0) {
        const diff = cooldownEnd - Date.now();
        if (diff <= 0) {
          // Cooldown finished
          setChancesLeft(2);
          setCooldownEnd(0);
          setTimeRemainingStr('00:00:00');
          try {
            const today = new Date().toDateString();
            localStorage.setItem(STORAGE_SCROLL_KEY, JSON.stringify({ lastDate: today, chancesLeft: 2, cooldownEnd: 0 }));
          } catch {}
        } else {
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          const secs = Math.floor((diff % (1000 * 60)) / 1000);
          setTimeRemainingStr(
            `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
          );
        }
      } else {
        setTimeRemainingStr('00:00:00');
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [cooldownEnd]);

  if (!isOpen) return null;

  // Spin Scroll Handler
  const handleSpinScroll = () => {
    if (isSpinning) return;
    if (chancesLeft <= 0) {
      sound.playLose();
      return;
    }

    sound.playClick();
    setIsSpinning(true);
    setLastWonItem(null);
    setShowWinConfetti(false);

    // Pick winning index based strictly on the 10-item weighted distribution (0 to 9)
    const winningIndex = Math.floor(Math.random() * SCROLL_REEL_ITEMS.length);
    const winningItem = SCROLL_REEL_ITEMS[winningIndex];

    // Card width + margin calculation
    const itemWidth = 110; // width of each card + gap in pixels
    // Target the 3rd repeat block for smooth spinning
    const targetOffset = (2 * SCROLL_REEL_ITEMS.length + winningIndex) * itemWidth;

    if (reelContainerRef.current) {
      reelContainerRef.current.style.transition = 'transform 3.2s cubic-bezier(0.12, 0.8, 0.25, 1)';
      // Center the winning card in the viewport
      const containerWidth = reelContainerRef.current.parentElement?.clientWidth || 320;
      const centerShift = containerWidth / 2 - 50;
      reelContainerRef.current.style.transform = `translateX(-${targetOffset - centerShift}px)`;
    }

    // Play tick sound loop
    let tickCount = 0;
    const tickInterval = setInterval(() => {
      tickCount++;
      sound.playSpinTick();
      if (tickCount > 24) clearInterval(tickInterval);
    }, 120);

    // Conclude spin
    setTimeout(() => {
      clearInterval(tickInterval);
      setIsSpinning(false);
      setLastWonItem(winningItem);

      if (winningItem.points > 0) {
        sound.playWin();
        setShowWinConfetti(true);
        onAwardTokens(winningItem.points);
      } else {
        sound.playLose();
      }

      // Update chances
      const nextChances = chancesLeft - 1;
      setChancesLeft(nextChances);

      let nextCooldown = 0;
      if (nextChances <= 0) {
        // Set 24 hour cooldown timer (or until next morning)
        nextCooldown = Date.now() + 24 * 60 * 60 * 1000;
        setCooldownEnd(nextCooldown);
      }

      try {
        const today = new Date().toDateString();
        localStorage.setItem(
          STORAGE_SCROLL_KEY,
          JSON.stringify({ lastDate: today, chancesLeft: nextChances, cooldownEnd: nextCooldown })
        );
      } catch {}
    }, 3300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-200 select-none">
      <div 
        id="lucky-scroll-modal-content"
        className="relative w-full max-w-sm bg-gradient-to-b from-white via-amber-50/40 to-white rounded-3xl p-5 shadow-2xl border-2 border-amber-300 flex flex-col items-center max-h-[92vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={() => {
            sound.playPop();
            onClose();
          }}
          disabled={isSpinning}
          className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition-colors cursor-pointer active:scale-95 disabled:opacity-50"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Ribbon & Title */}
        <div className="flex flex-col items-center text-center mt-1 mb-3">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-100 border border-amber-300 rounded-full text-amber-900 text-xs font-black mb-1.5 shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-600 fill-amber-500 animate-spin" />
            <span>DAILY LUCKY SCROLL</span>
          </div>

          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            Spin & Win <span className="text-amber-600">Tokens</span>
          </h2>
          
          <p className="text-[11px] font-medium text-slate-500 mt-0.5">
            2 Free Daily Chances • Win <strong className="text-amber-700">10 🪙</strong> or <strong className="text-amber-700">20 🪙 Jackpot</strong>!
          </p>
        </div>

        {/* Chances Status Pills */}
        <div className="w-full flex items-center justify-between bg-amber-100/60 border border-amber-200 px-3 py-2 rounded-2xl mb-3.5">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-orange-500 fill-orange-400" />
            <span className="text-xs font-black text-slate-800">
              Chances: <span className="text-amber-700">{chancesLeft} / 2</span>
            </span>
          </div>

          <div className="flex items-center gap-1">
            <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span className="text-xs font-black text-slate-900">{userCoins} 🪙</span>
          </div>
        </div>

        {/* ========================================================
            THE TOP SCROLL REEL (Slot-machine horizontal spinning track)
            ======================================================== */}
        <div className="w-full relative my-2">
          
          {/* Neon Pointer / Payline Indicator (Center arrow pointing down & up) */}
          <div className="absolute left-1/2 -top-3 -translate-x-1/2 z-20 flex flex-col items-center pointer-events-none">
            <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[10px] border-t-amber-500 filter drop-shadow" />
          </div>

          <div className="absolute left-1/2 -bottom-3 -translate-x-1/2 z-20 flex flex-col items-center pointer-events-none">
            <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-b-[10px] border-b-amber-500 filter drop-shadow" />
          </div>

          {/* Reel Window */}
          <div className="w-full h-32 bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl border-4 border-amber-400 shadow-inner overflow-hidden relative flex items-center">
            
            {/* Center target highlight overlay */}
            <div className="absolute left-1/2 top-0 bottom-0 w-[96px] -translate-x-1/2 bg-amber-400/20 border-x-2 border-amber-300 pointer-events-none z-10" />

            {/* Scrolling Track */}
            <div
              ref={reelContainerRef}
              className="flex items-center gap-3 px-6 select-none will-change-transform"
              style={{ transform: 'translateX(0px)' }}
            >
              {repeatedItems.map((item, idx) => (
                <div
                  key={`${item.id}-${idx}`}
                  className={`w-24 h-24 shrink-0 rounded-2xl bg-gradient-to-br ${item.bgGradient} p-2 flex flex-col items-center justify-center text-center shadow-lg border-2 ${item.borderColor} relative`}
                >
                  <span className="text-2xl mb-1">
                    {item.points === 20 ? '⭐' : item.points === 10 ? '🪙' : item.points === 2 ? '✨' : '💨'}
                  </span>
                  <span className="text-white text-xs font-black leading-tight">
                    {item.label}
                  </span>
                  <span className="text-[9px] font-bold text-amber-200 uppercase mt-0.5">
                    {item.points > 0 ? `+${item.points} 🪙` : 'Miss'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Win / Result Banner Display */}
        {lastWonItem && (
          <div className="w-full my-2.5 p-3 rounded-2xl bg-white border border-amber-200 shadow-sm flex items-center justify-between animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-2">
              <span className="text-2xl">
                {lastWonItem.points > 0 ? '🎉' : '😅'}
              </span>
              <div className="flex flex-col text-left">
                <span className="text-xs font-black text-slate-900">
                  {lastWonItem.points > 0 ? `You Won +${lastWonItem.points} Tokens!` : 'Better luck next spin!'}
                </span>
                <span className="text-[10px] text-slate-500">
                  {lastWonItem.points === 20 ? 'Jackpot Reward' : lastWonItem.points === 10 ? 'Big Win' : 'Result'}
                </span>
              </div>
            </div>
            {lastWonItem.points > 0 && (
              <span className="px-2 py-1 bg-amber-100 text-amber-900 text-xs font-black rounded-lg border border-amber-300">
                +{lastWonItem.points} 🪙
              </span>
            )}
          </div>
        )}

        {/* Odds & Chances Description Breakdown */}
        <div className="w-full my-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-left">
          <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center justify-between">
            <span>Scroll Probability Distribution</span>
            <span className="text-amber-700">Out of 10</span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-center">
            <div className="p-1.5 rounded-lg bg-blue-50 border border-blue-200">
              <div className="text-[10px] font-black text-blue-800">10 Tokens</div>
              <div className="text-xs font-black text-blue-600">4 / 10</div>
            </div>
            <div className="p-1.5 rounded-lg bg-amber-50 border border-amber-200">
              <div className="text-[10px] font-black text-amber-800">20 Tokens</div>
              <div className="text-xs font-black text-amber-600">1 / 10 ⭐</div>
            </div>
            <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-200">
              <div className="text-[10px] font-black text-emerald-800">2 Tokens</div>
              <div className="text-xs font-black text-emerald-600">2 / 10</div>
            </div>
          </div>
        </div>

        {/* Bottom Main Action Button */}
        <div className="w-full flex flex-col gap-2 mt-2">
          {chancesLeft > 0 ? (
            <button
              id="spin-scroll-action-button"
              type="button"
              onClick={handleSpinScroll}
              disabled={isSpinning}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-600 text-white font-black text-sm shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
              <span>{isSpinning ? 'SPINNING SCROLL...' : `SPIN SCROLL (${chancesLeft} Chance${chancesLeft > 1 ? 's' : ''} Left)`}</span>
            </button>
          ) : (
            /* Try After Time Button when 0 chances left */
            <div className="w-full flex flex-col gap-2">
              <button
                type="button"
                disabled
                className="w-full py-3.5 px-4 rounded-2xl bg-slate-200 text-slate-500 font-black text-xs flex flex-col items-center justify-center gap-0.5 border border-slate-300 cursor-not-allowed"
              >
                <div className="flex items-center gap-1.5 text-slate-700 font-black text-xs uppercase tracking-wider">
                  <Timer className="w-3.5 h-3.5 text-slate-600 animate-pulse" />
                  <span>TRY AFTER TIME</span>
                </div>
                <div className="text-amber-800 font-mono font-black text-sm">
                  Next Try In: {timeRemainingStr}
                </div>
              </button>
            </div>
          )}

          {/* Quick Close Button */}
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="w-full py-2 text-slate-500 hover:text-slate-700 font-bold text-xs cursor-pointer transition-colors"
          >
            Back to Games
          </button>
        </div>

      </div>
    </div>
  );
};
