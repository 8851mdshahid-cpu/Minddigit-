import React, { useState } from 'react';
import { Plus, Bell, X, Send, AlertCircle, Gamepad2 } from 'lucide-react';
import { Friend } from '../utils/friends';
import { sound } from '../utils/audio';

interface TopFriendsBarProps {
  friends: Friend[];
  onOpenAddFriend: () => void;
  onOpenNotifications: () => void;
  onSelectFriendToPlay: (friend: Friend) => void;
  pendingRequestsCount: number;
}

export const TopFriendsBar: React.FC<TopFriendsBarProps> = ({
  friends,
  onOpenAddFriend,
  onOpenNotifications,
  onSelectFriendToPlay,
  pendingRequestsCount,
}) => {
  const [offlineNoticeFriend, setOfflineNoticeFriend] = useState<Friend | null>(null);
  const [inviteSentToast, setInviteSentToast] = useState<string | null>(null);

  const onlineCount = friends.filter((f) => f.isOnline).length;

  const handleFriendClick = (friend: Friend) => {
    if (friend.isOnline) {
      sound.playWin();
      onSelectFriendToPlay(friend);
    } else {
      sound.playLose();
      setOfflineNoticeFriend(friend);
    }
  };

  const handleSendOfflineInvite = (friend: Friend) => {
    sound.playPop();
    setInviteSentToast(`✓ @${friend.username} को रूम इनवाइट भेज दिया गया है! जब वो ऑनलाइन आएगा तो जुड़ सकेगा।`);
    setTimeout(() => {
      setInviteSentToast(null);
      setOfflineNoticeFriend(null);
    }, 2500);
  };

  return (
    <div className="w-full mb-3 bg-white/80 backdrop-blur-md border border-white/90 p-2.5 rounded-2xl shadow-xs flex flex-col gap-1.5 select-none relative">
      
      {/* Top row header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] font-black uppercase tracking-wider text-slate-600">
            Friends ({friends.length}) • {onlineCount} Online
          </span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        </div>

        {pendingRequestsCount > 0 ? (
          <button
            type="button"
            onClick={() => {
              sound.playPop();
              onOpenNotifications();
            }}
            className="flex items-center gap-1 text-[10px] font-black text-purple-700 bg-purple-100 hover:bg-purple-200 px-2 py-0.5 rounded-full transition-all cursor-pointer animate-bounce"
          >
            <Bell className="w-3 h-3 text-purple-600" />
            <span>{pendingRequestsCount} Request(s)</span>
          </button>
        ) : (
          <span className="text-[10px] text-slate-400 font-medium">
            Tap online friend to play
          </span>
        )}
      </div>

      {/* Horizontal Carousel of Friends + Add Friend Button */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 no-scrollbar">
        
        {/* ADD FRIEND (+) BUTTON */}
        <button
          type="button"
          onClick={() => {
            sound.playPop();
            onOpenAddFriend();
          }}
          className="flex flex-col items-center justify-center shrink-0 w-14 h-16 rounded-2xl bg-gradient-to-b from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border-2 border-dashed border-blue-300 text-blue-600 transition-all cursor-pointer group active:scale-95 shadow-2xs"
          title="Add a new friend"
        >
          <div className="w-7 h-7 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs group-hover:scale-110 transition-transform">
            <Plus className="w-4 h-4 stroke-[3]" />
          </div>
          <span className="text-[9px] font-black text-blue-700 mt-1 uppercase tracking-tight">
            Add
          </span>
        </button>

        {/* FRIENDS LIST */}
        {friends.map((friend) => (
          <button
            key={friend.username}
            type="button"
            onClick={() => handleFriendClick(friend)}
            className={`flex flex-col items-center shrink-0 w-16 h-17 p-1 rounded-2xl border transition-all cursor-pointer group active:scale-95 shadow-2xs relative text-center ${
              friend.isOnline
                ? 'bg-white hover:bg-purple-50 border-slate-200 hover:border-purple-300'
                : 'bg-rose-50/40 hover:bg-rose-100/50 border-rose-200 hover:border-rose-400 opacity-90'
            }`}
            title={`${friend.name} (@${friend.username}) - ${friend.isOnline ? 'Online (Tap to Play)' : 'Offline (Not Playing)'}`}
          >
            {/* Avatar with status indicator */}
            <div className="relative">
              <img
                src={friend.avatar}
                alt={friend.name}
                referrerPolicy="no-referrer"
                className={`w-7 h-7 rounded-full border bg-purple-50 group-hover:scale-105 transition-transform ${
                  friend.isOnline ? 'border-purple-200' : 'border-rose-300 grayscale-[30%]'
                }`}
              />
              
              {/* Online: Green Dot | Offline: Red Round Sticker with Dot */}
              {friend.isOnline ? (
                <span 
                  className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full shadow-xs" 
                  title="Online (खेलने के लिए तैयार)" 
                />
              ) : (
                <div
                  className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-600 rounded-full flex items-center justify-center border-2 border-white shadow-xs"
                  title="Offline (ऑफलाइन का लाल स्टिकर)"
                >
                  <span className="w-1.5 h-1.5 bg-white rounded-full" />
                </div>
              )}
            </div>

            {/* Friend name */}
            <div className="flex items-center justify-center gap-0.5 w-full mt-0.5 px-0.5">
              <span className="text-[10px] font-black text-slate-800 truncate">
                {friend.name.split(' ')[0]}
              </span>
            </div>
            
            {/* Status badge: PLAY (Online) vs OFFLINE (Red) */}
            <span className={`text-[8px] font-black px-1 py-0.2 rounded-md uppercase tracking-tighter ${
              friend.isOnline 
                ? 'text-emerald-700 bg-emerald-100 border border-emerald-200' 
                : 'text-rose-700 bg-rose-100 border border-rose-200 flex items-center gap-0.5'
            }`}>
              {!friend.isOnline && <span className="w-1 h-1 rounded-full bg-rose-600" />}
              {friend.isOnline ? 'PLAY' : 'OFFLINE'}
            </span>
          </button>
        ))}

        {friends.length === 0 && (
          <div className="flex items-center gap-1.5 px-3 py-2 text-[11px] text-slate-500 font-medium">
            <span>No friends yet. Tap + to add friends!</span>
          </div>
        )}

      </div>

      {/* OFFLINE FRIEND NOTICE MODAL / DIALOG */}
      {offlineNoticeFriend && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl p-5 max-w-xs w-full shadow-2xl border border-rose-200 flex flex-col gap-3 text-center animate-in zoom-in-95 duration-150 relative">
            
            {/* Close Button */}
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setOfflineNoticeFriend(null);
              }}
              className="absolute top-3 right-3 p-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Red Offline Badge & Avatar */}
            <div className="flex flex-col items-center gap-2 pt-1">
              <div className="relative">
                <img
                  src={offlineNoticeFriend.avatar}
                  alt={offlineNoticeFriend.name}
                  referrerPolicy="no-referrer"
                  className="w-16 h-16 rounded-full border-3 border-rose-200 bg-rose-50"
                />
                {/* Red Circular Offline Sticker */}
                <div className="absolute -top-1 -right-1 w-6 h-6 bg-rose-600 rounded-full border-2 border-white flex items-center justify-center shadow-md">
                  <span className="w-2.5 h-2.5 bg-white rounded-full animate-ping" />
                  <span className="w-2.5 h-2.5 bg-white rounded-full absolute" />
                </div>
              </div>

              <div>
                <h3 className="text-base font-black text-slate-900">
                  {offlineNoticeFriend.name}
                </h3>
                <div className="text-xs font-mono text-slate-400">
                  @{offlineNoticeFriend.username}
                </div>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 border border-rose-300 text-rose-700 font-black text-xs">
                <span className="w-2 h-2 rounded-full bg-rose-600" />
                <span>Player is OFFLINE (ऑफलाइन)</span>
              </div>
            </div>

            {/* Explanation message strictly respecting user's requirement */}
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3 text-left flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <p className="text-xs text-rose-900 font-medium leading-relaxed">
                <span className="font-bold">{offlineNoticeFriend.name}</span> अभी ऑनलाइन नहीं है। उसके बदले कोई कंप्यूटर या बॉट नहीं खेलेगा। जब वो ऑनलाइन आएगा, तभी आप दोनों रियल-टाइम लाइव मैच खेल सकेंगे!
              </p>
            </div>

            {/* Invite Status / Actions */}
            {inviteSentToast ? (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold animate-in fade-in">
                {inviteSentToast}
              </div>
            ) : (
              <div className="flex flex-col gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleSendOfflineInvite(offlineNoticeFriend)}
                  className="w-full py-2.5 px-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-1.5 active:scale-95"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Notification Invite</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setOfflineNoticeFriend(null);
                  }}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
                >
                  Close (बंद करें)
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
