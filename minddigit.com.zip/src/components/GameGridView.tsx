import React from 'react';
import { sound } from '../utils/audio';
import { ActiveGameType } from '../types';
import { GameCardCover } from './GameCardCover';
import { Play } from 'lucide-react';

interface GameGridViewProps {
  onSelectGame: (game: ActiveGameType) => void;
  userTokens: number;
}

interface GameItemConfig {
  id: ActiveGameType;
  title: string;
  subtitle: string;
  cardId: string;
  glowColor: string;
}

export const GameGridView: React.FC<GameGridViewProps> = ({
  onSelectGame,
}) => {
  const games: GameItemConfig[] = [
    {
      id: 'guess-number',
      title: 'Guess Number',
      subtitle: 'High-Low Clues',
      cardId: 'game-card-guess-number',
      glowColor: 'bg-cyan-500/15',
    },
    {
      id: 'guess-imposter',
      title: 'Against Imposter',
      subtitle: 'Voice & Detective',
      cardId: 'game-card-guess-imposter',
      glowColor: 'bg-purple-500/15',
    },
    {
      id: 'math-blitz',
      title: 'Math Blitz',
      subtitle: 'Level 10/10 • 5 Rounds • 10 Pts',
      cardId: 'game-card-math-blitz',
      glowColor: 'bg-emerald-500/15',
    },
    {
      id: 'bridger',
      title: 'Bridger',
      subtitle: '5 Rounds • First to Answer',
      cardId: 'game-card-bridger',
      glowColor: 'bg-indigo-500/15',
    },
    {
      id: 'pattern-matrix',
      title: 'Pattern Matrix',
      subtitle: 'Memory & Grid',
      cardId: 'game-card-pattern-matrix',
      glowColor: 'bg-purple-500/15',
    },
  ];

  return (
    <div className="w-full flex flex-col items-center select-none">
      
      {/* 2x2 Responsive Games Grid Container with Uniform Sizing */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 w-full">
        {games.map((game) => (
          <div
            key={game.id}
            id={game.cardId}
            onClick={() => {
              sound.playPop();
              onSelectGame(game.id);
            }}
            className="group relative bg-white/95 hover:bg-white backdrop-blur-md rounded-3xl p-3 sm:p-3.5 border border-white/90 shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer flex flex-col justify-between overflow-hidden active:scale-97 text-center w-full h-[225px] sm:h-[240px]"
          >
            {/* Ambient Corner Glow Accent */}
            <div className={`absolute top-0 right-0 w-24 h-24 ${game.glowColor} rounded-full blur-xl pointer-events-none`} />

            {/* Standardized Aspect-Ratio Artwork Box */}
            <div className="w-full aspect-[16/10] rounded-2xl overflow-hidden shadow-xs group-hover:scale-102 transition-transform duration-200">
              <GameCardCover gameType={game.id} />
            </div>

            {/* Standardized Title & Action Section */}
            <div className="w-full flex items-center justify-between pt-2 px-1">
              <div className="text-left flex-1 min-w-0 pr-1">
                <h3 className="text-xs sm:text-sm font-black text-slate-900 tracking-tight truncate">
                  {game.title}
                </h3>
                <p className="text-[10px] sm:text-[11px] font-bold text-slate-400 truncate">
                  {game.subtitle}
                </p>
              </div>

              {/* Mini Play Icon Button */}
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900 group-hover:bg-blue-600 text-white flex items-center justify-center shadow-xs transition-colors shrink-0">
                <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
