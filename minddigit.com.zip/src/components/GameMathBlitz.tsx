import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  ArrowLeft, Timer, Trophy, Zap, RefreshCw, Coins, Sparkles, Check, X, 
  Users, User, Swords, Flame, RotateCcw, AlertTriangle, CheckCircle2, XCircle, Crown, ShieldAlert
} from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { Friend, getFriends } from '../utils/friends';

interface GameMathBlitzProps {
  user: UserProfile;
  initialOpponent?: { name: string; username: string; avatar?: string };
  onBack: () => void;
  onGameEnd: (won: boolean, scoreGained: number, coinsGained: number) => void;
  onRetry?: () => void;
}

export type MathGameMode = 'solo' | 'friend';

interface MathQuestion {
  id: number;
  expression: string;
  answer: number;
  options: number[];
  difficulty: string;
}

const QUESTION_TIME_LIMIT = 6; // 6 seconds per question
const BASE_ROUNDS = 5; // Exactly 5 rounds base
const POINTS_PER_ROUND = 10; // 10 points awarded per round won
const TARGET_WINS = 3; // 3 correct (30 pts) vs 2 correct (20 pts) to win

export const GameMathBlitz: React.FC<GameMathBlitzProps> = ({
  user,
  initialOpponent,
  onBack,
  onGameEnd,
  onRetry,
}) => {
  // Game Setup & Mode
  const [gameMode, setGameMode] = useState<MathGameMode>(initialOpponent ? 'friend' : 'solo');
  const [isGameStarted, setIsGameStarted] = useState<boolean>(false);
  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(
    initialOpponent 
      ? {
          id: 'init_opp',
          name: initialOpponent.name,
          username: initialOpponent.username,
          avatar: initialOpponent.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${initialOpponent.username}`,
          isOnline: true,
          addedAt: Date.now(),
        }
      : null
  );

  // Gameplay State: 5 Rounds + Tie-Breaker
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [isTieBreakerActive, setIsTieBreakerActive] = useState<boolean>(false);
  const [currentQuestion, setCurrentQuestion] = useState<MathQuestion | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(QUESTION_TIME_LIMIT);
  const [isRoundLocked, setIsRoundLocked] = useState<boolean>(false);
  
  // Points (Awarding 10 points each round)
  const [userPoints, setUserPoints] = useState<number>(0);
  const [friendPoints, setFriendPoints] = useState<number>(0);
  const [userRoundsWon, setUserRoundsWon] = useState<number>(0);
  const [friendRoundsWon, setFriendRoundsWon] = useState<number>(0);

  // Last awarded points banner
  const [pointsAwardedBanner, setPointsAwardedBanner] = useState<{
    awardedTo: string;
    points: number;
    isCorrect: boolean;
    text: string;
  } | null>(null);

  const [userSelectedOption, setUserSelectedOption] = useState<number | null>(null);

  // Match Finished & Top Winner Display
  const [isMatchFinished, setIsMatchFinished] = useState<boolean>(false);
  const [matchWinner, setMatchWinner] = useState<'user' | 'friend' | 'draw' | null>(null);
  const [winnerDisplayName, setWinnerDisplayName] = useState<string>('');

  const friendTimerRef = useRef<NodeJS.Timeout | null>(null);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Load user friends on mount
  useEffect(() => {
    const list = getFriends(user.id);
    setFriendsList(list);
    if (!selectedFriend && list.length > 0) {
      const onlineOne = list.find(f => f.isOnline);
      setSelectedFriend(onlineOne || list[0]);
    }
  }, [user.id]);

  // Math Level 10/10: Generate Level 10 Math challenge questions (challenging arithmetic & 2-step equations)
  const generateLevel10Question = (roundNum: number): MathQuestion => {
    const questionTypes = ['two-step', 'multiplication', 'division', 'add-sub', 'mental-algebra'];
    const qType = questionTypes[Math.floor(Math.random() * questionTypes.length)];

    let expression = '';
    let answer = 0;

    if (qType === 'two-step') {
      const a = Math.floor(Math.random() * 9) + 4; // 4 to 12
      const b = Math.floor(Math.random() * 8) + 3; // 3 to 10
      const c = Math.floor(Math.random() * 25) + 5; // 5 to 29
      const isMinus = Math.random() > 0.5;
      
      if (isMinus) {
        expression = `(${a} × ${b}) - ${c}`;
        answer = (a * b) - c;
      } else {
        expression = `(${a} × ${b}) + ${c}`;
        answer = (a * b) + c;
      }
    } else if (qType === 'multiplication') {
      const a = Math.floor(Math.random() * 12) + 7; // 7 to 18
      const b = Math.floor(Math.random() * 9) + 4; // 4 to 12
      expression = `${a} × ${b}`;
      answer = a * b;
    } else if (qType === 'division') {
      const divisor = Math.floor(Math.random() * 11) + 4; // 4 to 14
      const quotient = Math.floor(Math.random() * 14) + 6; // 6 to 19
      const dividend = divisor * quotient;
      expression = `${dividend} ÷ ${divisor}`;
      answer = quotient;
    } else if (qType === 'add-sub') {
      const a = Math.floor(Math.random() * 65) + 35; // 35 to 99
      const b = Math.floor(Math.random() * 45) + 25; // 25 to 69
      const isAdd = Math.random() > 0.5;
      if (isAdd) {
        expression = `${a} + ${b}`;
        answer = a + b;
      } else {
        const top = Math.max(a, b) + 20;
        const sub = Math.min(a, b);
        expression = `${top} - ${sub}`;
        answer = top - sub;
      }
    } else {
      // Mental Algebra / Speed equation
      const x = Math.floor(Math.random() * 12) + 3;
      const k = Math.floor(Math.random() * 7) + 3;
      const total = x * k + 8;
      expression = `${k}X + 8 = ${total} (Find X)`;
      answer = x;
    }

    // Generate 4 plausible distinct answer options
    const deltaOffsets = [-10, -5, -3, -2, -1, 1, 2, 3, 5, 10];
    const shuffledDeltas = [...deltaOffsets].sort(() => Math.random() - 0.5);
    const optionsSet = new Set<number>([answer]);
    
    for (const delta of shuffledDeltas) {
      if (optionsSet.size >= 4) break;
      const val = answer + delta;
      if (val > 0) optionsSet.add(val);
    }
    while (optionsSet.size < 4) {
      optionsSet.add(answer + optionsSet.size + 4);
    }

    const options = Array.from(optionsSet).sort(() => Math.random() - 0.5);
    return {
      id: roundNum,
      expression,
      answer,
      options,
      difficulty: 'Level 10/10 Master',
    };
  };

  // Start new match (5 Rounds base)
  const startNewMatch = (mode: MathGameMode) => {
    sound.playPop();
    setGameMode(mode);
    setIsGameStarted(true);
    setIsMatchFinished(false);
    setMatchWinner(null);
    setWinnerDisplayName('');
    setCurrentRound(1);
    setIsTieBreakerActive(false);
    setUserPoints(0);
    setFriendPoints(0);
    setUserRoundsWon(0);
    setFriendRoundsWon(0);
    setUserSelectedOption(null);
    setPointsAwardedBanner(null);
    setIsRoundLocked(false);

    const firstQ = generateLevel10Question(1);
    setCurrentQuestion(firstQ);
    setTimeLeft(QUESTION_TIME_LIMIT);
  };

  // Advance to next round or trigger Tie-Breaker if 3-2 not met
  const advanceToNextRound = (nextRoundNum: number, currentUWon: number, currentFWon: number) => {
    if (gameMode === 'solo') {
      // In Solo mode: 5 rounds total
      if (nextRoundNum > BASE_ROUNDS) {
        // Evaluate Solo Win / Loose
        // ≥ 3 correct (≥30 points) = WIN, ≤ 2 correct (≤20 points) = LOOSE
        finishMatch(currentUWon >= TARGET_WINS ? 'user' : 'friend', currentUWon, currentFWon);
        return;
      }
    } else {
      // In 2-Player Friend Duel mode:
      // Check if a decisive victory is reached:
      // e.g. User has 3 wins (30 pts) and Friend has 2 or fewer -> User Wins!
      // e.g. Friend has 3 wins (30 pts) and User has 2 or fewer -> Friend Wins!
      if (currentUWon >= TARGET_WINS && currentUWon > currentFWon) {
        finishMatch('user', currentUWon, currentFWon);
        return;
      }
      if (currentFWon >= TARGET_WINS && currentFWon > currentUWon) {
        finishMatch('friend', currentUWon, currentFWon);
        return;
      }

      // If we finished the 5th round and neither player has 3 wins (e.g. 2-2, 1-1, 2-1 because both made mistakes on some rounds)
      // or if they are tied, enter TIE-BREAKER SUDDEN DEATH rounds!
      if (nextRoundNum > BASE_ROUNDS) {
        setIsTieBreakerActive(true);
      }
    }

    setCurrentRound(nextRoundNum);
    setUserSelectedOption(null);
    setPointsAwardedBanner(null);
    setIsRoundLocked(false);
    const nextQ = generateLevel10Question(nextRoundNum);
    setCurrentQuestion(nextQ);
    setTimeLeft(QUESTION_TIME_LIMIT);
  };

  // Finish Match and Declare Winner at the Top
  const finishMatch = (winner: 'user' | 'friend' | 'draw', finalUWon: number, finalFWon: number) => {
    setIsMatchFinished(true);
    setIsRoundLocked(true);
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    if (friendTimerRef.current) clearTimeout(friendTimerRef.current);

    setMatchWinner(winner);

    const userName = user.name || user.username || 'You';
    const friendName = selectedFriend?.name || 'Opponent';
    const winnerName = winner === 'user' ? userName : winner === 'friend' ? friendName : 'Draw';
    setWinnerDisplayName(winnerName);

    const won = winner === 'user';
    const totalScoreGained = finalUWon * POINTS_PER_ROUND;
    const coinsGained = won ? 25 : winner === 'draw' ? 8 : 3;

    if (won) {
      sound.playWin();
      confetti({ particleCount: 90, spread: 80, origin: { y: 0.55 } });
    } else {
      sound.playLose();
    }

    onGameEnd(won, totalScoreGained, coinsGained);
  };

  // 6-Second Clock Countdown Hook
  useEffect(() => {
    if (!isGameStarted || isMatchFinished || isRoundLocked) return;

    timerIntervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerIntervalRef.current!);
          handleTimeExpired();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isGameStarted, isMatchFinished, isRoundLocked, currentRound]);

  // Friend AI / Opponent simulation in Friend Mode
  useEffect(() => {
    if (!isGameStarted || isMatchFinished || isRoundLocked || gameMode !== 'friend' || !currentQuestion) {
      return;
    }

    // Friend reaction time within 2.3s - 5.0s
    const reactionDelayMs = Math.floor(Math.random() * 2500) + 2300;
    const willAnswerCorrect = Math.random() < 0.75;

    friendTimerRef.current = setTimeout(() => {
      if (isRoundLocked || isMatchFinished) return;

      if (willAnswerCorrect) {
        handleFriendAnswer(true, currentQuestion.answer);
      } else {
        const wrongOpt = currentQuestion.options.find(o => o !== currentQuestion.answer) || 0;
        handleFriendAnswer(false, wrongOpt);
      }
    }, reactionDelayMs);

    return () => {
      if (friendTimerRef.current) clearTimeout(friendTimerRef.current);
    };
  }, [isGameStarted, isMatchFinished, isRoundLocked, currentRound, gameMode, currentQuestion]);

  // Handle Player Option Click
  const handleUserAnswer = (selectedNumber: number) => {
    if (!currentQuestion || isRoundLocked || isMatchFinished) return;
    setUserSelectedOption(selectedNumber);

    const isCorrect = selectedNumber === currentQuestion.answer;

    if (isCorrect) {
      sound.playWin();
      setIsRoundLocked(true);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (friendTimerRef.current) clearTimeout(friendTimerRef.current);

      // Points awarded: +10 Points!
      const newPts = userPoints + POINTS_PER_ROUND;
      const newWins = userRoundsWon + 1;
      setUserPoints(newPts);
      setUserRoundsWon(newWins);

      // Prominent points banner showing 10 points awarded with player name
      const userName = user.name || user.username || 'You';
      setPointsAwardedBanner({
        awardedTo: userName,
        points: POINTS_PER_ROUND,
        isCorrect: true,
        text: `🎉 ${userName} answered first! +10 Points Awarded!`,
      });

      confetti({ particleCount: 30, spread: 50, origin: { y: 0.5 } });

      setTimeout(() => {
        advanceToNextRound(currentRound + 1, newWins, friendRoundsWon);
      }, 1200);

    } else {
      // Wrong Answer!
      sound.playLower();
      
      setPointsAwardedBanner({
        awardedTo: user.name || 'You',
        points: 0,
        isCorrect: false,
        text: '❌ Wrong Answer! No points awarded.',
      });

      if (gameMode === 'solo') {
        setIsRoundLocked(true);
        setTimeout(() => {
          advanceToNextRound(currentRound + 1, userRoundsWon, friendRoundsWon);
        }, 900);
      } else {
        // In 2-Player Friend mode: dismiss banner after 800ms so friend can answer within 6s
        setTimeout(() => {
          setPointsAwardedBanner((prev) => (prev?.isCorrect === false ? null : prev));
        }, 800);
      }
    }
  };

  // Handle Friend Answer (in 2-Player Friend Duel)
  const handleFriendAnswer = (isCorrect: boolean, guessedNum: number) => {
    if (isRoundLocked || isMatchFinished || !currentQuestion) return;
    const friendName = selectedFriend?.name || 'Friend';

    if (isCorrect) {
      sound.playLower();
      setIsRoundLocked(true);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

      const newPts = friendPoints + POINTS_PER_ROUND;
      const newWins = friendRoundsWon + 1;
      setFriendPoints(newPts);
      setFriendRoundsWon(newWins);

      // Friend answered first with +10 points
      setPointsAwardedBanner({
        awardedTo: friendName,
        points: POINTS_PER_ROUND,
        isCorrect: true,
        text: `⚡ ${friendName} answered first! +10 Points Awarded!`,
      });

      setTimeout(() => {
        advanceToNextRound(currentRound + 1, userRoundsWon, newWins);
      }, 1200);
    } else {
      // Friend wrong answer
      setPointsAwardedBanner({
        awardedTo: friendName,
        points: 0,
        isCorrect: false,
        text: `❌ ${friendName} gave a Wrong Answer!`,
      });

      setTimeout(() => {
        setPointsAwardedBanner((prev) => (prev?.isCorrect === false ? null : prev));
      }, 800);
    }
  };

  // Time expired for current 6-second round
  const handleTimeExpired = () => {
    if (isRoundLocked || isMatchFinished) return;
    sound.playLose();
    setIsRoundLocked(true);

    setPointsAwardedBanner({
      awardedTo: '',
      points: 0,
      isCorrect: false,
      text: `⏰ Time's Up! (Correct Answer: ${currentQuestion?.answer})`,
    });

    setTimeout(() => {
      advanceToNextRound(currentRound + 1, userRoundsWon, friendRoundsWon);
    }, 1100);
  };

  // ==========================================
  // VIEW 1: LOBBY & COMPREHENSIVE DESCRIPTION
  // ==========================================
  if (!isGameStarted) {
    return (
      <div className="w-full max-w-sm bg-white/95 backdrop-blur-md rounded-3xl p-5 shadow-2xl border border-white flex flex-col items-center select-none animate-in fade-in duration-200">
        
        {/* Top Bar */}
        <div className="w-full flex items-center justify-between mb-4">
          <button
            id="math-blitz-back-btn"
            type="button"
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-100 text-amber-900 rounded-full font-black text-xs">
            <Zap className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
            <span>MATH LEVEL 10/10</span>
          </div>

          <div className="flex items-center gap-1 font-black text-xs text-amber-800 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
            <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span>{user.coins}</span>
          </div>
        </div>

        {/* Hero Visual Card with Math Level 10/10 & Points Badges */}
        <div className="w-full bg-gradient-to-br from-amber-500 via-orange-500 to-rose-600 rounded-3xl p-5 text-white flex flex-col items-center text-center shadow-lg relative overflow-hidden mb-4 border border-amber-300/30">
          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center mb-2 shadow-inner border border-white/20">
            <Zap className="w-7 h-7 text-white fill-white animate-pulse" />
          </div>
          <h2 className="text-xl font-black tracking-tight flex items-center gap-1.5">
            <span>Math Blitz</span>
            <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded-md font-mono text-amber-200 border border-white/20">
              LEVEL 10/10
            </span>
          </h2>
          <p className="text-xs text-amber-100 mt-1 max-w-[250px]">
            5 Rounds • +10 Points Each • Fast 6s Arithmetic
          </p>
          
          <div className="mt-3 flex items-center gap-2 text-[11px] font-bold bg-black/25 px-3 py-1 rounded-full backdrop-blur-sm border border-white/10">
            <Trophy className="w-3.5 h-3.5 text-amber-300" />
            <span>30 Pts (3 Wins) vs 20 Pts (2 Wins) Rule</span>
          </div>
        </div>

        {/* Detailed Game Description & Rules Box (as requested) */}
        <div className="w-full bg-amber-50/90 border border-amber-200/80 rounded-2xl p-3.5 mb-4 text-left space-y-1.5 shadow-xs">
          <div className="flex items-center gap-1.5 text-amber-950 font-black text-xs uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Game Rules & Point System:</span>
          </div>
          <ul className="text-[11px] text-amber-900/90 space-y-1 font-medium leading-relaxed pl-1">
            <li className="flex items-start gap-1.5">
              <span className="text-amber-600 font-bold">•</span>
              <span><strong>Points:</strong> You receive <strong>10 points</strong> for every round you answer correctly first.</span>
            </li>
            <li className="flex items-start gap-1.5">
              <span className="text-amber-600 font-bold">•</span>
              <span><strong>5 Rounds Match:</strong> 5 speed arithmetic rounds to complete.</span>
            </li>
            <li className="flex items-start gap-1.5">
              <span className="text-amber-600 font-bold">•</span>
              <span><strong>Win Condition:</strong> 3 Correct (30 pts) beats 2 Correct (20 pts).</span>
            </li>
            <li className="flex items-start gap-1.5">
              <span className="text-amber-600 font-bold">•</span>
              <span><strong>Tie-Breaker:</strong> If mistakes occur and scores are tied, <strong>Sudden Death rounds</strong> continue until 3 and 2 victory is decided!</span>
            </li>
            <li className="flex items-start gap-1.5">
              <span className="text-amber-600 font-bold">•</span>
              <span><strong>Winner Honors:</strong> Winner&apos;s name will proudly appear at the <strong>very top</strong>.</span>
            </li>
          </ul>
        </div>

        {/* Mode Selector Tabs */}
        <div className="w-full grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl mb-4">
          <button
            id="tab-mode-solo"
            type="button"
            onClick={() => {
              sound.playClick();
              setGameMode('solo');
            }}
            className={`py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              gameMode === 'solo'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <User className="w-3.5 h-3.5 text-blue-600" />
            <span>Solo Game</span>
          </button>

          <button
            id="tab-mode-friend"
            type="button"
            onClick={() => {
              sound.playClick();
              setGameMode('friend');
            }}
            className={`py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              gameMode === 'friend'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Swords className="w-3.5 h-3.5 text-rose-500" />
            <span>Friend Duel</span>
          </button>
        </div>

        {/* Mode Specific Selection */}
        {gameMode === 'solo' ? (
          <div className="w-full bg-blue-50/70 border border-blue-100 rounded-2xl p-3.5 mb-4 text-left">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <h4 className="text-xs font-black text-blue-950 uppercase tracking-wider">Solo 5-Round Challenge</h4>
            </div>
            <p className="text-xs text-blue-800/80 leading-relaxed">
              Answer 5 challenging Level 10 math equations. Score 30+ points (3 out of 5 correct) to claim victory and have your name featured at the top!
            </p>
          </div>
        ) : (
          <div className="w-full flex flex-col gap-2 mb-4 text-left">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 px-1">
              Select Friend Opponent:
            </label>
            
            {friendsList.length > 0 ? (
              <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                {friendsList.map((fr) => {
                  const isSelected = selectedFriend?.username === fr.username;
                  return (
                    <button
                      key={fr.id}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        setSelectedFriend(fr);
                      }}
                      className={`flex flex-col items-center p-2 rounded-2xl border transition-all cursor-pointer min-w-[72px] shrink-0 ${
                        isSelected
                          ? 'bg-rose-50 border-rose-500 shadow-sm ring-2 ring-rose-400/20'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="relative mb-1">
                        <img
                          src={fr.avatar}
                          alt={fr.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-full bg-white shadow-xs border border-slate-100"
                        />
                        {fr.isOnline && (
                          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white" />
                        )}
                      </div>
                      <span className="text-[10px] font-bold text-slate-800 truncate max-w-[65px]">
                        {fr.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
                No friends added yet. Please add friends from the top bar!
              </div>
            )}
          </div>
        )}

        {/* Start Game Action Button */}
        <button
          id="math-blitz-start-btn"
          type="button"
          onClick={() => startNewMatch(gameMode)}
          className="w-full py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-600 hover:to-rose-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-lg shadow-orange-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
        >
          <Zap className="w-4 h-4 fill-white" />
          <span>Start {gameMode === 'solo' ? 'Solo Match' : 'Friend Duel'} (5 Rounds)</span>
        </button>

      </div>
    );
  }

  // ==========================================
  // VIEW 2: ACTIVE 5-ROUNDS + TIE-BREAKER GAMEPLAY
  // ==========================================
  const timerPercentage = Math.max(0, Math.min(100, (timeLeft / QUESTION_TIME_LIMIT) * 100));
  const isUrgentTimer = timeLeft <= 2;

  return (
    <div className="w-full max-w-sm bg-white/95 backdrop-blur-md rounded-3xl p-5 shadow-2xl border border-white flex flex-col items-center select-none relative animate-in fade-in duration-200">
      
      {/* Top Gameplay Header */}
      <div className="w-full flex items-center justify-between mb-3">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            setIsGameStarted(false);
          }}
          className="p-2 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        {/* Round Badge (Indicates Tie-Breaker if active) */}
        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full font-black text-xs ${
          isTieBreakerActive 
            ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse'
            : 'bg-amber-100 text-amber-900'
        }`}>
          <Zap className="w-3.5 h-3.5 fill-amber-500 text-amber-600" />
          <span>
            {isTieBreakerActive 
              ? `TIE-BREAKER ROUND ${currentRound}` 
              : `ROUND ${currentRound} OF ${BASE_ROUNDS}`}
          </span>
        </div>

        {/* 6s Clock Indicator */}
        <div className={`flex items-center gap-1 font-mono font-black text-sm px-3 py-1 rounded-xl transition-colors ${
          isUrgentTimer 
            ? 'bg-rose-100 text-rose-700 animate-pulse' 
            : 'bg-slate-100 text-slate-800'
        }`}>
          <Timer className={`w-3.5 h-3.5 ${isUrgentTimer ? 'text-rose-600' : 'text-orange-500'}`} />
          <span>{timeLeft}s</span>
        </div>
      </div>

      {/* 6-Second Animated Progress Bar */}
      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-3.5 border border-slate-200/60 shadow-inner">
        <div 
          className={`h-full transition-all duration-300 rounded-full ${
            isUrgentTimer 
              ? 'bg-rose-500 shadow-sm shadow-rose-500/50' 
              : 'bg-gradient-to-r from-amber-500 to-orange-500'
          }`}
          style={{ width: `${timerPercentage}%` }}
        />
      </div>

      {/* Point Scoreboard: 10 Points Awarded per round */}
      <div className="w-full grid grid-cols-2 gap-2 mb-3">
        {/* User Card */}
        <div className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
          <img
            src={user.avatar}
            alt={user.name}
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-full bg-white shadow-xs border border-slate-200 shrink-0"
          />
          <div className="flex-1 min-w-0 text-left">
            <span className="text-[11px] font-black text-slate-800 truncate block">
              {user.name?.split(' ')[0] || 'You'}
            </span>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-blue-600 font-mono">
                {userPoints} pts
              </span>
              <span className="text-[10px] text-slate-400 font-bold">
                ({userRoundsWon} {userRoundsWon === 1 ? 'win' : 'wins'})
              </span>
            </div>
          </div>
        </div>

        {/* Friend Card (or Win Target in Solo Mode) */}
        {gameMode === 'friend' ? (
          <div className="flex items-center gap-2 p-2.5 bg-rose-50/70 border border-rose-200/80 rounded-2xl">
            <img
              src={selectedFriend?.avatar || 'https://api.dicebear.com/7.x/bottts/svg?seed=friend_duel'}
              alt={selectedFriend?.name || 'Friend'}
              referrerPolicy="no-referrer"
              className="w-8 h-8 rounded-full bg-white shadow-xs border border-rose-200 shrink-0"
            />
            <div className="flex-1 min-w-0 text-left">
              <span className="text-[11px] font-black text-slate-800 truncate block">
                {selectedFriend?.name?.split(' ')[0] || 'Friend'}
              </span>
              <div className="flex items-center gap-1">
                <span className="text-xs font-black text-rose-600 font-mono">
                  {friendPoints} pts
                </span>
                <span className="text-[10px] text-slate-400 font-bold">
                  ({friendRoundsWon} {friendRoundsWon === 1 ? 'win' : 'wins'})
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between px-3 py-2 bg-amber-50/80 border border-amber-200/80 rounded-2xl">
            <div className="text-left">
              <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider block">
                Win Target
              </span>
              <span className="text-xs font-black text-amber-950 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-500" />
                ≥ 30 Points (3 Wins)
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Per Round
              </span>
              <span className="text-xs font-black text-emerald-600 font-mono">
                +10 pts
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Arithmetic Equation Box (Math Level 10/10) */}
      {currentQuestion && (
        <div className="w-full py-6 px-4 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 rounded-3xl text-white flex flex-col items-center justify-center shadow-xl my-1 relative overflow-hidden border border-slate-700">
          <div className="flex items-center justify-between w-full px-2 mb-1 text-[10px] font-black font-mono tracking-widest text-amber-300 uppercase">
            <span>⚡ MATH LEVEL 10/10</span>
            <span>+10 PTS ROUND</span>
          </div>
          
          <span className="text-3xl sm:text-4xl font-black font-mono tracking-wider drop-shadow-md text-amber-300 my-1 text-center">
            {currentQuestion.expression}
          </span>
          <span className="text-xs font-black uppercase tracking-widest text-slate-300">
            = ?
          </span>
        </div>
      )}

      {/* DYNAMIC MIDDLE BANNER (Name of winner & 10 Points Awarded display) */}
      <div className="w-full min-h-[46px] my-2 flex items-center justify-center">
        {pointsAwardedBanner ? (
          <div className={`w-full py-2.5 px-4 rounded-2xl flex items-center justify-center gap-2 text-xs font-black shadow-md animate-in zoom-in-95 duration-150 ${
            pointsAwardedBanner.isCorrect
              ? 'bg-emerald-500 text-white shadow-emerald-500/25'
              : 'bg-rose-500 text-white shadow-rose-500/25 animate-shake'
          }`}>
            {pointsAwardedBanner.isCorrect ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 shrink-0" />
            )}
            <span className="truncate">{pointsAwardedBanner.text}</span>
          </div>
        ) : isTieBreakerActive ? (
          <div className="w-full py-2 px-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-[11px] font-black flex items-center justify-center gap-1.5 animate-pulse">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>TIE-BREAKER! +10 Pts per question until 3-2 victory!</span>
          </div>
        ) : (
          <div className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
            <span>Answer first in 6s • 10 Points Awarded Each Round</span>
          </div>
        )}
      </div>

      {/* 4 Rapid Answer Choice Cards */}
      <div className="grid grid-cols-2 gap-2.5 w-full mt-1">
        {currentQuestion?.options.map((opt, idx) => {
          const isSelected = userSelectedOption === opt;
          const isCorrectAnswer = opt === currentQuestion.answer;
          
          let buttonStyle = "bg-slate-100 hover:bg-slate-200/90 text-slate-800 border-slate-200";
          if (isRoundLocked && isCorrectAnswer) {
            buttonStyle = "bg-emerald-500 text-white border-emerald-600 shadow-md scale-102";
          } else if (isSelected && !isCorrectAnswer) {
            buttonStyle = "bg-rose-500 text-white border-rose-600 animate-shake";
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isRoundLocked}
              onClick={() => handleUserAnswer(opt)}
              className={`py-3.5 rounded-2xl font-black font-mono text-2xl border-2 transition-all duration-150 cursor-pointer shadow-xs active:scale-95 disabled:cursor-not-allowed flex items-center justify-center ${buttonStyle}`}
            >
              {opt}
            </button>
          );
        })}
      </div>

      {/* ==========================================
          CENTER RESULT POPUP MODAL (Winner Name At The Top)
          ========================================== */}
      {isMatchFinished && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xs bg-white rounded-3xl p-6 border-2 border-white shadow-2xl text-center flex flex-col items-center gap-3.5 animate-in zoom-in-95 duration-200 relative overflow-hidden">
            
            {/* TOP WINNER NAME BANNER - PROMINENTLY AT THE TOP AS REQUESTED */}
            <div className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 py-2.5 px-4 rounded-2xl text-white shadow-md flex items-center justify-center gap-2">
              <Crown className="w-4 h-4 fill-amber-200 text-amber-100 animate-bounce" />
              <div className="text-left">
                <span className="text-[9px] font-black uppercase tracking-widest text-amber-100 block">
                  WINNER AT THE TOP:
                </span>
                <span className="text-sm font-black tracking-wide uppercase drop-shadow-sm">
                  {winnerDisplayName || (matchWinner === 'user' ? (user.name || 'You') : (selectedFriend?.name || 'Friend'))}
                </span>
              </div>
            </div>

            {/* Status Icon & Match Outcome */}
            <div className="flex flex-col items-center mt-1">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-2 shadow-inner ${
                gameMode === 'solo'
                  ? userPoints >= 30
                    ? 'bg-emerald-100 text-emerald-600'
                    : 'bg-rose-100 text-rose-600'
                  : matchWinner === 'user'
                  ? 'bg-emerald-100 text-emerald-600'
                  : matchWinner === 'friend'
                  ? 'bg-rose-100 text-rose-600'
                  : 'bg-amber-100 text-amber-600'
              }`}>
                {gameMode === 'solo' ? (
                  userPoints >= 30 ? <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" /> : <XCircle className="w-8 h-8 text-rose-600" />
                ) : matchWinner === 'user' ? (
                  <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" />
                ) : matchWinner === 'friend' ? (
                  <Swords className="w-8 h-8 text-rose-600" />
                ) : (
                  <Zap className="w-8 h-8 text-amber-600" />
                )}
              </div>
              
              <h2 className={`text-2xl font-black tracking-tight ${
                gameMode === 'solo' 
                  ? userPoints >= 30 ? 'text-emerald-600' : 'text-rose-600'
                  : matchWinner === 'user'
                  ? 'text-emerald-600'
                  : matchWinner === 'friend'
                  ? 'text-rose-600'
                  : 'text-amber-600'
              }`}>
                {gameMode === 'solo' 
                  ? (userPoints >= 30 ? 'Win' : 'Loose')
                  : matchWinner === 'user' 
                  ? 'Win' 
                  : matchWinner === 'friend' 
                  ? 'Loose' 
                  : 'Draw'}
              </h2>

              <p className="text-xs font-semibold text-slate-500 mt-0.5">
                {gameMode === 'solo'
                  ? (userPoints >= 30 
                      ? `You won with ${userPoints} points (3 out of 5 correct)!` 
                      : `You lost with ${userPoints} points (≤ 20 points).`)
                  : matchWinner === 'user'
                  ? `You won with ${userPoints} pts (${userRoundsWon} wins) vs ${friendPoints} pts (${friendRoundsWon} wins)!`
                  : matchWinner === 'friend'
                  ? `${selectedFriend?.name || 'Friend'} won with ${friendPoints} pts vs ${userPoints} pts!`
                  : 'Both players drew after tie-breaker!'}
              </p>
            </div>

            {/* Middle Screen Card showing final Points & 3 vs 2 Rule */}
            <div className="w-full bg-gradient-to-b from-slate-50 to-slate-100/90 rounded-2xl p-3.5 border border-slate-200 shadow-inner flex flex-col items-center justify-center">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-500" />
                <span>Final Score ({POINTS_PER_ROUND} pts each round)</span>
              </span>
              <div className="text-3xl font-black font-mono text-blue-700 bg-white px-5 py-1.5 rounded-xl shadow-xs border border-blue-100 my-1">
                {userPoints} {gameMode === 'friend' ? ` - ${friendPoints}` : ' / 50 pts'}
              </div>
              <span className="text-[10px] text-slate-500 mt-1 font-semibold">
                {userPoints >= 30 ? '🎉 30+ Points = Victory Achieved!' : '💔 20 Points or Less = Defeat'}
              </span>
            </div>

            {/* Primary Retry Button */}
            <button
              id="math-blitz-retry-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                if (onRetry) {
                  onRetry();
                } else {
                  setIsGameStarted(false);
                }
              }}
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 hover:from-amber-600 hover:to-rose-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-orange-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry</span>
            </button>

            {/* Back to Home Secondary */}
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                onBack();
              }}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Back to Home
            </button>

          </div>
        </div>
      )}

    </div>
  );
};
