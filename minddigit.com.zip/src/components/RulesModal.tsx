import React from 'react';
import { X, HelpCircle, ArrowUp, ArrowDown } from 'lucide-react';
import { sound } from '../utils/audio';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-[2px] select-none animate-in fade-in">
      <div className="w-full max-w-md bg-white rounded-[40px] p-6 sm:p-8 border border-white shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="absolute right-5 top-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="p-2.5 bg-blue-50 text-blue-600 rounded-2xl">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-xl text-slate-900 tracking-tight">
              How to Play Minddigit
            </h3>
            <p className="text-xs text-slate-400">Rules & Strategy Guide</p>
          </div>
        </div>

        <div className="space-y-4 text-xs text-slate-600 font-medium leading-relaxed">
          <div className="p-4 bg-slate-50 rounded-3xl border border-slate-100">
            <div className="font-bold text-slate-900 text-sm mb-1 flex items-center gap-1.5">
              🎯 The Objective
            </div>
            <p className="text-slate-500">
              Guess the hidden secret number between <strong>1 and 100</strong> (or chosen difficulty) within limited lives!
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center">
            <div className="p-3.5 bg-emerald-50/80 rounded-2xl border border-emerald-100">
              <div className="text-emerald-700 font-bold text-xs flex items-center justify-center gap-1">
                <ArrowUp className="w-3.5 h-3.5" /> HIGHER (▲)
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                The secret number is larger than your guess.
              </p>
            </div>

            <div className="p-3.5 bg-rose-50/80 rounded-2xl border border-rose-100">
              <div className="text-rose-700 font-bold text-xs flex items-center justify-center gap-1">
                <ArrowDown className="w-3.5 h-3.5" /> LOWER (▼)
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                The secret number is smaller than your guess.
              </p>
            </div>
          </div>

          <div className="space-y-2 pt-1">
            <div className="font-bold text-slate-900 text-xs uppercase tracking-wider">
              🎮 Available Games
            </div>
            <ul className="space-y-2 list-none">
              <li className="p-3 rounded-2xl bg-blue-50/80 border border-blue-100">
                <strong className="text-blue-900">1. Guess Number (Solo & Online):</strong> Guess the secret number in 10 chances with higher/lower hints and a 25-second timer.
              </li>
              <li className="p-3 rounded-2xl bg-purple-50/80 border border-purple-100">
                <strong className="text-purple-900">2. Guess the Imposter (Voice):</strong> 3 players. 2 get the same secret item, 1 gets a different item. Record timed voice clues, listen to recordings, and vote out the imposter!
              </li>
            </ul>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            sound.playClick();
            onClose();
          }}
          className="w-full mt-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl transition-colors text-sm cursor-pointer shadow-lg shadow-blue-200"
        >
          Got it!
        </button>
      </div>
    </div>
  );
};
