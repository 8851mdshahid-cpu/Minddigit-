import React, { useState } from 'react';
import { Sparkles, ArrowRight, Play, Coins, Users, Bot, Globe, Zap } from 'lucide-react';
import { sound } from '../utils/audio';

interface GuessNumberBannerProps {
  onPlayClick: () => void;
  onOpenAdModal?: () => void;
  userTokens?: number;
}

export const GuessNumberBanner: React.FC<GuessNumberBannerProps> = ({
  onPlayClick,
  onOpenAdModal,
  userTokens = 150,
}) => {
  const [imgError, setImgError] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const handleCardClick = () => {
    sound.playPop();
    setShowDetails((prev) => !prev);
  };

  const handlePlayAction = (e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playPop();
    onPlayClick();
  };

  return (
    <div
      id="guess-number-game-card"
      onClick={handleCardClick}
      className="group relative w-full bg-white/85 backdrop-blur-md rounded-3xl overflow-hidden cursor-pointer border border-white shadow-lg hover:shadow-xl transition-all duration-300 select-none"
    >
      {/* Geometric gradient backdrop overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 via-amber-500/5 to-purple-500/10 pointer-events-none" />

      <div className="relative p-5 sm:p-6 flex flex-col z-10">
        
        {/* Upper Main Hero Section */}
        <div className="flex flex-col items-center text-center gap-4">
          
          <div className="flex items-center justify-between w-full">
            <span className="text-blue-600 font-black tracking-widest text-[10px] uppercase px-2.5 py-1 bg-blue-100/70 rounded-full border border-blue-200">
              ⭐ Featured #1 Game
            </span>
            <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200 shadow-2xs flex items-center gap-1">
              <Coins className="w-3 h-3 text-amber-500 fill-amber-400" />
              <span>Tokens Active</span>
            </span>
          </div>

          {/* Rotated Number Visual Accent */}
          <div className="relative flex items-center justify-center my-1">
            <div className="w-36 h-36 bg-white/70 backdrop-blur-sm rounded-3xl rotate-6 flex items-center justify-center shadow-md border border-white group-hover:rotate-0 transition-transform duration-300 relative">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl shadow-xl flex flex-col items-center justify-center -rotate-6 group-hover:rotate-0 transition-transform duration-300">
                <span className="text-white text-4xl font-black tracking-tighter leading-none">
                  ?
                </span>
                <span className="text-[9px] font-black text-cyan-200 uppercase tracking-widest mt-1">
                  1 to 100
                </span>
              </div>
            </div>
          </div>

          {/* Text & Info */}
          <div className="flex flex-col items-center text-center w-full">
            <h2 className="text-2xl font-black text-slate-900 mb-1 tracking-tight">
              Guess Number <span className="text-blue-600">Arcade Arena</span>
            </h2>

            <p className="text-slate-600 text-xs max-w-xs mb-4 leading-relaxed font-medium">
              Real-time duel or solo vs AI. Guess the mystery secret number between 1 and 100 within 10 turns and 5s timer!
            </p>

            {/* Play Button & Action Strip */}
            <div className="flex flex-col w-full gap-2">
              <button
                id="main-play-button"
                type="button"
                onClick={handlePlayAction}
                className="w-full py-3.5 px-6 bg-blue-600 text-white font-black rounded-2xl shadow-lg shadow-blue-500/25 hover:bg-blue-700 active:scale-98 transition-all flex items-center justify-center gap-2 text-sm cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>PLAY GUESS NUMBER</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  sound.playPop();
                  setShowDetails(!showDetails);
                }}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors text-xs cursor-pointer"
              >
                {showDetails ? 'Hide Features ▲' : 'View All Features ▼'}
              </button>
            </div>
          </div>

        </div>

        {/* Expandable Rest of the Game's Features (Shown on Click) */}
        {showDetails && (
          <div className="mt-5 pt-4 border-t border-slate-200/80 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-3 text-left">
              Complete Game Features & Rules
            </div>

            <div className="flex flex-col gap-2.5 text-left">
              
              {/* 1. Play with Friends Online */}
              <div className="p-3 rounded-xl bg-blue-50/80 border border-blue-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-blue-700 font-extrabold text-xs">
                  <Globe className="w-3.5 h-3.5" />
                  <span>Online Room Duel (10 🪙)</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • Displays your ID & unique shareable code.<br />
                  • 2 Players, 10 chances, 5s timer each.
                </p>
              </div>

              {/* 2. Play with AI Computer */}
              <div className="p-3 rounded-xl bg-indigo-50/80 border border-indigo-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-indigo-700 font-extrabold text-xs">
                  <Bot className="w-3.5 h-3.5" />
                  <span>Play vs Computer (1 🪙)</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • Win <strong>+10, +20, or +50 Tokens</strong> depending on difficulty level.
                </p>
              </div>

              {/* 3. Token Economy & Ads */}
              <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 flex flex-col gap-1">
                <div className="flex items-center gap-1.5 text-amber-800 font-extrabold text-xs">
                  <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                  <span>Free Tokens via Ads</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  • Watch quick sponsor clip for <strong>+20 Free Tokens</strong>.
                </p>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
