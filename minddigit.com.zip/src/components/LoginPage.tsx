import React, { useState, useEffect } from 'react';
import { User, Lock, ArrowRight, Sparkles, RefreshCw, HelpCircle, ShieldCheck, KeyRound, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { MinddigitLogo } from './MinddigitLogo';
import { PinInput } from './PinInput';
import { sound } from '../utils/audio';
import { UserProfile } from '../types';
import { syncUserProfileToFirestore } from '../utils/firebaseFriends';

interface LoginPageProps {
  onSuccess: (user: UserProfile) => void;
}

type AuthTab = 'login' | 'register' | 'forgot';

export interface StoredUserAccount {
  id: string;
  name: string;
  username: string;
  pin: string;
  securityQuestion: string;
  securityAnswer: string;
  avatar: string;
  isAdmin?: boolean;
  coins: number;
  score: number;
  gamesPlayed: number;
  gamesWon: number;
  bestStreak: number;
  currentStreak: number;
}

export const ADMIN_USERNAME = 'shahid8851';
export const ADMIN_PIN = '885113';

const DEFAULT_SECURITY_QUESTIONS = [
  "What is your favorite color?",
  "What is your pet's name?",
  "What city were you born in?",
  "What is your favorite food?",
  "What is your mother's maiden name?",
  "What is your childhood school name?",
];

// Helper to get all registered accounts from localStorage
export const getStoredAccounts = (): StoredUserAccount[] => {
  const adminAccount: StoredUserAccount = {
    id: 'admin-shahid8851',
    name: 'Md Shahid',
    username: 'shahid8851',
    pin: '885113',
    securityQuestion: 'What is your favorite color?',
    securityAnswer: 'Blue',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=shahid8851',
    isAdmin: true,
    coins: 5000,
    score: 12500,
    gamesPlayed: 25,
    gamesWon: 22,
    bestStreak: 12,
    currentStreak: 8,
  };

  const defaultUser: StoredUserAccount = {
    id: 'user-default',
    name: 'Player One',
    username: 'mds_101',
    pin: '123456',
    securityQuestion: 'What is your favorite color?',
    securityAnswer: 'Blue',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=mds_101',
    isAdmin: false,
    coins: 250,
    score: 850,
    gamesPlayed: 5,
    gamesWon: 3,
    bestStreak: 2,
    currentStreak: 1,
  };

  try {
    const raw = localStorage.getItem('minddigit_accounts');
    if (raw) {
      const parsed: StoredUserAccount[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure admin account exists with updated 6-digit PIN and isAdmin flag
        const adminIndex = parsed.findIndex(
          (acc) => acc.username.toLowerCase() === 'shahid8851'
        );
        if (adminIndex === -1) {
          parsed.unshift(adminAccount);
        } else {
          parsed[adminIndex].pin = '885113';
          parsed[adminIndex].isAdmin = true;
          parsed[adminIndex].name = parsed[adminIndex].name || 'Md Shahid';
          parsed[adminIndex].securityQuestion = parsed[adminIndex].securityQuestion || 'What is your favorite color?';
          parsed[adminIndex].securityAnswer = parsed[adminIndex].securityAnswer || 'Blue';
        }
        saveAccounts(parsed);
        return parsed;
      }
    }
  } catch {
    // ignore
  }

  const initialList = [adminAccount, defaultUser];
  saveAccounts(initialList);
  return initialList;
};

export const saveAccounts = (accounts: StoredUserAccount[]) => {
  try {
    localStorage.setItem('minddigit_accounts', JSON.stringify(accounts));
  } catch {
    // ignore
  }
};

// Helper to generate a random username from the first 3 letters/words of the name
export const generateUsernameFromName = (nameInput: string): string => {
  const trimmed = nameInput.trim();
  if (!trimmed) {
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    return `usr_${randomSuffix}`;
  }

  const words = trimmed.split(/\s+/).filter(Boolean);
  let prefix = '';

  if (words.length >= 3) {
    prefix = (words[0][0] + words[1][0] + words[2][0]).toLowerCase();
  } else if (words.length === 2) {
    const combined = (words[0].slice(0, 2) + words[1].slice(0, 2)).toLowerCase().replace(/[^a-z0-9]/g, '');
    prefix = combined.slice(0, 3) || 'usr';
  } else {
    prefix = words[0].replace(/[^a-zA-Z0-9]/g, '').slice(0, 3).toLowerCase() || 'usr';
  }

  if (prefix.length < 3) {
    prefix = prefix.padEnd(3, 'x');
  }

  const randomNum = Math.floor(100 + Math.random() * 900);
  return `${prefix}_${randomNum}`;
};

export const LoginPage: React.FC<LoginPageProps> = ({ onSuccess }) => {
  const [authTab, setAuthTab] = useState<AuthTab>('login');

  // --- LOGIN STATE ---
  const [loginUserId, setLoginUserId] = useState('');
  const [loginPin, setLoginPin] = useState('');

  // --- REGISTER STATE ---
  const [regName, setRegName] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regQuestion, setRegQuestion] = useState(DEFAULT_SECURITY_QUESTIONS[0]);
  const [regAnswer, setRegAnswer] = useState('');
  const [regPin, setRegPin] = useState('');
  const [regConfirmPin, setRegConfirmPin] = useState('');
  const [isUsernameCustomized, setIsUsernameCustomized] = useState(false);

  // --- FORGOT PIN STATE ---
  const [forgotStep, setForgotStep] = useState<'verify' | 'reset'>('verify');
  const [forgotUserId, setForgotUserId] = useState('');
  const [forgotFoundAccount, setForgotFoundAccount] = useState<StoredUserAccount | null>(null);
  const [forgotAnswer, setForgotAnswer] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');

  // General Status
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // On mount, auto-fill default username if available
  useEffect(() => {
    const accounts = getStoredAccounts();
    if (accounts.length > 0) {
      setLoginUserId(accounts[0].username);
    }
  }, []);

  // When name changes in Register tab, auto-assign username
  const handleRegNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newName = e.target.value;
    setRegName(newName);
    setError('');

    if (!isUsernameCustomized) {
      if (newName.trim().length > 0) {
        setRegUsername(generateUsernameFromName(newName));
      } else {
        setRegUsername('');
      }
    }
  };

  const handleRegenerateUsername = () => {
    sound.playClick();
    const newUsername = generateUsernameFromName(regName || 'Player');
    setRegUsername(newUsername);
    setIsUsernameCustomized(false);
  };

  // --- DIRECT LOGIN HELPER ---
  const performDirectLogin = (matched: StoredUserAccount) => {
    setError('');
    setIsLoading(true);
    sound.playWin();

    const profile: UserProfile = {
      id: matched.id,
      name: matched.name,
      username: matched.username,
      email: `${matched.username}@minddigit.local`,
      avatar: matched.avatar,
      pin: matched.pin,
      securityQuestion: matched.securityQuestion,
      securityAnswer: matched.securityAnswer,
      isAdmin: Boolean(matched.isAdmin || matched.username.toLowerCase() === 'shahid8851'),
      isGuest: false,
      coins: matched.coins || 100,
      score: matched.score || 500,
      gamesPlayed: matched.gamesPlayed || 0,
      gamesWon: matched.gamesWon || 0,
      bestStreak: matched.bestStreak || 0,
      currentStreak: matched.currentStreak || 0,
    };

    localStorage.setItem('minddigit_user_profile', JSON.stringify(profile));
    syncUserProfileToFirestore(profile);

    setTimeout(() => {
      onSuccess(profile);
    }, 120);
  };

  // --- AUTO LOGIN ON PIN ENTRY (SILENT ON INCORRECT) ---
  const tryAutoLogin = (pinVal: string, userIdVal: string) => {
    if (pinVal.length !== 6) return;

    const accounts = getStoredAccounts();
    const cleanUserId = userIdVal.trim().replace(/^@/, '').toLowerCase();

    // 1. If User ID is entered, check that specific user
    if (cleanUserId) {
      const matched = accounts.find(
        (acc) =>
          acc.username.toLowerCase() === cleanUserId ||
          acc.name.toLowerCase() === cleanUserId
      );
      if (matched && matched.pin === pinVal) {
        performDirectLogin(matched);
        return;
      }
      // If PIN is incorrect, do nothing (no reaction)
      return;
    }

    // 2. If User ID is not entered yet, check if PIN matches any registered account
    const pinMatch = accounts.find((acc) => acc.pin === pinVal);
    if (pinMatch) {
      performDirectLogin(pinMatch);
      return;
    }
    // Silent: no reaction if PIN does not match
  };

  // --- 1. HANDLE LOGIN ---
  const handleLoginSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const cleanUserId = loginUserId.trim().replace(/^@/, '').toLowerCase();
    const accounts = getStoredAccounts();

    if (loginPin.length === 6) {
      if (cleanUserId) {
        const matched = accounts.find(
          (acc) =>
            acc.username.toLowerCase() === cleanUserId ||
            acc.name.toLowerCase() === cleanUserId
        );
        if (matched && matched.pin === loginPin) {
          performDirectLogin(matched);
          return;
        }
      } else {
        const pinMatch = accounts.find((acc) => acc.pin === loginPin);
        if (pinMatch) {
          performDirectLogin(pinMatch);
          return;
        }
      }
    }
    // Silent: if PIN is incorrect, no reaction
  };

  // --- 2. HANDLE REGISTRATION ---
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playClick();

    const trimmedName = regName.trim();
    const cleanUsername = (regUsername.trim() || generateUsernameFromName(trimmedName || 'Player')).replace(/^@/, '').toLowerCase();

    if (!trimmedName || trimmedName.length < 2) {
      setError('Please enter your full name (at least 2 letters)');
      return;
    }

    const accounts = getStoredAccounts();
    const existing = accounts.find(
      (acc) =>
        acc.username.toLowerCase() === cleanUsername ||
        acc.name.trim().toLowerCase() === trimmedName.toLowerCase()
    );

    if (existing) {
      setError('Already registered. This user is already registered. Please log in with your PIN.');
      return;
    }

    if (!regAnswer.trim()) {
      setError('Please answer your chosen security question');
      return;
    }
    if (regPin.length !== 6) {
      setError('Please create a 6-digit MPIN');
      return;
    }
    if (regConfirmPin.length !== 6) {
      setError('Please confirm your 6-digit MPIN');
      return;
    }
    if (regPin !== regConfirmPin) {
      setError('Both MPINs do not match. Please re-enter.');
      return;
    }

    setError('');
    setIsLoading(true);
    sound.playPop();

    const newAccount: StoredUserAccount = {
      id: `user-${Date.now()}`,
      name: trimmedName,
      username: cleanUsername,
      pin: regPin,
      securityQuestion: regQuestion,
      securityAnswer: regAnswer.trim(),
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanUsername)}`,
      isAdmin: false,
      coins: 100,
      score: 500,
      gamesPlayed: 0,
      gamesWon: 0,
      bestStreak: 0,
      currentStreak: 0,
    };

    accounts.push(newAccount);
    saveAccounts(accounts);

    const profile: UserProfile = {
      ...newAccount,
      email: `${cleanUsername}@minddigit.local`,
      isGuest: false,
    };
    localStorage.setItem('minddigit_user_profile', JSON.stringify(profile));
    syncUserProfileToFirestore(profile);

    setTimeout(() => {
      onSuccess(profile);
    }, 300);
  };

  // --- 3. HANDLE FORGOT PIN / RECOVERY ---
  const handleForgotLookupAndVerify = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playClick();

    const cleanId = forgotUserId.trim().replace(/^@/, '').toLowerCase();
    if (!cleanId) {
      setError('Please enter your User ID');
      return;
    }

    const accounts = getStoredAccounts();
    const found = accounts.find(
      (acc) => acc.username.toLowerCase() === cleanId || acc.name.toLowerCase() === cleanId
    );

    if (!found) {
      setError(`No account found with User ID "@${cleanId}". Please check again.`);
      return;
    }

    setForgotFoundAccount(found);

    // If answer is empty, prompt user to answer
    if (!forgotAnswer.trim()) {
      setError(`Please answer the security question for @${found.username}`);
      return;
    }

    // Check if security answer matches
    if (found.securityAnswer.trim().toLowerCase() !== forgotAnswer.trim().toLowerCase()) {
      setError('Incorrect answer to the security question. Please try again.');
      return;
    }

    setError('');
    sound.playPop();
    setForgotStep('reset');
  };

  const handleResetPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playClick();

    if (!forgotFoundAccount) {
      setError('Account session expired. Please start over.');
      setForgotStep('verify');
      return;
    }

    if (newPin.length !== 6) {
      setError('New MPIN must be 6 digits');
      return;
    }
    if (confirmNewPin.length !== 6) {
      setError('Please confirm your new 6-digit MPIN');
      return;
    }
    if (newPin !== confirmNewPin) {
      setError('New MPIN and Confirm MPIN do not match');
      return;
    }

    const accounts = getStoredAccounts();
    const idx = accounts.findIndex((a) => a.id === forgotFoundAccount.id);
    if (idx !== -1) {
      accounts[idx].pin = newPin;
      saveAccounts(accounts);
    }

    sound.playPop();
    setSuccessMessage('MPIN successfully updated! Logging you in...');
    setIsLoading(true);

    const profile: UserProfile = {
      ...forgotFoundAccount,
      pin: newPin,
      email: `${forgotFoundAccount.username}@minddigit.local`,
      isGuest: false,
    };
    localStorage.setItem('minddigit_user_profile', JSON.stringify(profile));

    setTimeout(() => {
      onSuccess(profile);
    }, 700);
  };

  // --- 4. GUEST / SKIP ---
  const handleGuestLogin = () => {
    sound.playPop();
    setIsLoading(true);
    const guestNum = Math.floor(Math.random() * 899 + 100);
    const guestProfile: UserProfile = {
      id: `guest-${Date.now()}`,
      name: `Guest #${guestNum}`,
      username: `guest_${guestNum}`,
      email: 'guest@minddigit.local',
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=guest-${Date.now()}`,
      isGuest: true,
      coins: 50,
      score: 0,
      gamesPlayed: 0,
      gamesWon: 0,
      bestStreak: 0,
      currentStreak: 0,
    };
    localStorage.setItem('minddigit_user_profile', JSON.stringify(guestProfile));
    setTimeout(() => {
      onSuccess(guestProfile);
    }, 150);
  };

  return (
    <main className="min-h-screen w-full flex flex-col items-center justify-center bg-[#F1F5F9] p-4 sm:p-6 select-none relative overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Geometric background ambient elements */}
      <div className="absolute top-12 left-12 w-72 h-72 bg-blue-200/40 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute bottom-12 right-12 w-80 h-80 bg-indigo-200/30 rounded-full blur-3xl pointer-events-none -z-10"></div>

      <div className="w-full max-w-[430px] mx-auto flex flex-col items-center">
        
        {/* Main Geometric Balance Auth Card Frame */}
        <div className="w-full bg-white rounded-[44px] sm:rounded-[48px] shadow-2xl border-[6px] sm:border-[8px] border-slate-900 flex flex-col p-6 sm:p-8 items-center relative overflow-hidden">
          
          {/* Top 3D Minddigit Logo */}
          <div className="w-full flex flex-col items-center justify-center mb-3 mt-1">
            <div className="w-full max-w-[250px] flex items-center justify-center py-1.5 px-3">
              <MinddigitLogo size="md" className="w-full" />
            </div>
          </div>

          {/* Tab Navigation Header (Login / Sign Up) */}
          <div className="w-full flex items-center justify-center gap-2 p-1 bg-slate-100 rounded-2xl mb-5">
            <button
              id="tab-login-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                setAuthTab('login');
                setError('');
                setSuccessMessage('');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                authTab === 'login'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Login (PIN)
            </button>
            <button
              id="tab-register-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                setAuthTab('register');
                setError('');
                setSuccessMessage('');
                if (regName && !regUsername) {
                  setRegUsername(generateUsernameFromName(regName));
                }
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                authTab === 'register'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Sign Up / Register
            </button>
          </div>

          {/* ========================================================= */}
          {/* 1. LOGIN TAB VIEW */}
          {/* ========================================================= */}
          {authTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="w-full space-y-4">
              
              {/* User ID Field */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1">
                  User ID
                </label>
                <div className="relative flex items-center">
                  <span className="absolute left-4 text-blue-600 font-bold text-sm pointer-events-none">
                    @
                  </span>
                  <input
                    id="login-userid-input"
                    type="text"
                    value={loginUserId}
                    onChange={(e) => {
                      const newId = e.target.value;
                      setLoginUserId(newId);
                      if (error) setError('');
                      tryAutoLogin(loginPin, newId);
                    }}
                    placeholder="Enter User ID (e.g. mds_101)"
                    className="w-full pl-9 pr-4 py-3.5 bg-slate-50 rounded-2xl border border-slate-200 outline-none focus:bg-white focus:ring-2 ring-blue-500 text-slate-900 text-sm font-mono font-medium transition-all"
                    autoFocus
                  />
                </div>
              </div>

              {/* 6-Digit MPIN Field */}
              <div className="space-y-1">
                <PinInput
                  id="login-mpin"
                  label="Enter 6-Digit MPIN"
                  value={loginPin}
                  onChange={(val) => {
                    setLoginPin(val);
                    if (error) setError('');
                    tryAutoLogin(val, loginUserId);
                  }}
                  length={6}
                />
              </div>

              {/* Error Message */}
              {error && (
                <p className="text-xs text-rose-500 font-semibold text-center bg-rose-50 border border-rose-100 py-2 px-3 rounded-xl">
                  {error}
                </p>
              )}

              {/* Success Message */}
              {successMessage && (
                <p className="text-xs text-emerald-600 font-semibold text-center bg-emerald-50 border border-emerald-100 py-2 px-3 rounded-xl">
                  {successMessage}
                </p>
              )}

              {/* Login Button */}
              <button
                id="login-submit-button"
                type="submit"
                disabled={isLoading}
                className="w-full py-4 bg-blue-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 mt-2 text-base"
              >
                <span>Login with MPIN</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Links: Forgot PIN & Sign-up */}
              <div className="flex items-center justify-between pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setAuthTab('forgot');
                    setForgotStep('verify');
                    setForgotUserId(loginUserId);
                    setError('');
                  }}
                  className="text-blue-600 hover:text-blue-700 font-bold cursor-pointer transition-colors"
                >
                  Forgot MPIN?
                </button>
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setAuthTab('register');
                    setError('');
                  }}
                  className="text-slate-500 hover:text-slate-800 font-semibold cursor-pointer transition-colors"
                >
                  Create Account →
                </button>
              </div>
            </form>
          )}

          {/* ========================================================= */}
          {/* 2. REGISTRATION / SIGN UP VIEW */}
          {/* ========================================================= */}
          {authTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="w-full space-y-3.5 max-h-[68vh] overflow-y-auto pr-1">
              
              {/* 1. Name Input */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1">
                  Full Name
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-4 text-slate-400 pointer-events-none">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="register-name-input"
                    type="text"
                    value={regName}
                    onChange={handleRegNameChange}
                    placeholder="Enter your name (e.g. Md Shahid)"
                    className="w-full pl-11 pr-4 py-3 bg-slate-50 rounded-2xl border border-slate-200 outline-none focus:bg-white focus:ring-2 ring-blue-500 text-slate-900 text-sm font-medium transition-all"
                    required
                    autoFocus
                  />
                </div>
              </div>

              {/* 2. Auto-generated Random User ID */}
              <div className="space-y-1">
                <div className="flex items-center justify-between px-1">
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <span>User ID</span>
                    <span className="text-[9px] text-blue-600 bg-blue-50 px-1.5 py-0.2 rounded-full font-semibold">
                      Auto 3-Letter
                    </span>
                  </label>
                  <button
                    type="button"
                    onClick={handleRegenerateUsername}
                    className="text-[11px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer transition-colors"
                    title="Generate new random username"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Randomize</span>
                  </button>
                </div>

                <div className="relative flex items-center">
                  <span className="absolute left-4 text-blue-600 font-bold text-sm pointer-events-none">
                    @
                  </span>
                  <input
                    id="register-username-input"
                    type="text"
                    value={regUsername}
                    onChange={(e) => {
                      setRegUsername(e.target.value.replace(/\s+/g, '_').toLowerCase());
                      setIsUsernameCustomized(true);
                    }}
                    placeholder="username"
                    className="w-full pl-9 pr-10 py-3 bg-blue-50/50 rounded-2xl border border-blue-100 outline-none focus:ring-2 ring-blue-500 text-blue-900 text-sm font-mono font-semibold transition-all"
                    required
                  />
                  <button
                    type="button"
                    onClick={handleRegenerateUsername}
                    className="absolute right-3 text-blue-500 hover:text-blue-700 p-1 rounded-lg hover:bg-blue-100/50 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* 3. Security Question */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1 flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
                  <span>Security Question (For Recovery)</span>
                </label>
                <select
                  id="register-security-question"
                  value={regQuestion}
                  onChange={(e) => setRegQuestion(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs font-semibold text-slate-800 outline-none focus:ring-2 ring-blue-500 transition-all cursor-pointer"
                >
                  {DEFAULT_SECURITY_QUESTIONS.map((q, idx) => (
                    <option key={idx} value={q}>
                      {q}
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Security Answer */}
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1">
                  Security Answer
                </label>
                <input
                  id="register-security-answer"
                  type="text"
                  value={regAnswer}
                  onChange={(e) => {
                    setRegAnswer(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="Enter answer (e.g. Blue)"
                  className="w-full px-4 py-3 bg-slate-50 rounded-2xl border border-slate-200 outline-none focus:bg-white focus:ring-2 ring-blue-500 text-slate-900 text-sm font-medium transition-all"
                  required
                />
              </div>

              {/* 5. Create 6-Digit MPIN (Box 1) */}
              <div className="space-y-1 pt-1">
                <PinInput
                  id="reg-mpin-create"
                  label="Create 6-Digit MPIN"
                  value={regPin}
                  onChange={(val) => {
                    setRegPin(val);
                    if (error) setError('');
                  }}
                  length={6}
                />
              </div>

              {/* 6. Confirm 6-Digit MPIN (Box 2) */}
              <div className="space-y-1">
                <PinInput
                  id="reg-mpin-confirm"
                  label="Confirm 6-Digit MPIN (Entered Twice)"
                  value={regConfirmPin}
                  onChange={(val) => {
                    setRegConfirmPin(val);
                    if (error) setError('');
                  }}
                  length={6}
                />
              </div>

              {/* Error Message */}
              {error && (
                <p className="text-xs text-rose-500 font-semibold text-center bg-rose-50 border border-rose-100 py-2 px-3 rounded-xl">
                  {error}
                </p>
              )}

              {/* Register Button */}
              <button
                id="register-submit-button"
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 bg-blue-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 text-sm mt-2"
              >
                <span>Register & Log In</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setAuthTab('login');
                    setError('');
                  }}
                  className="text-xs text-slate-500 hover:text-blue-600 font-bold cursor-pointer"
                >
                  Already have an account? Log In
                </button>
              </div>
            </form>
          )}

          {/* ========================================================= */}
          {/* 3. FORGOT PIN / RECOVERY VIEW */}
          {/* ========================================================= */}
          {authTab === 'forgot' && (
            <div className="w-full space-y-4">
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setAuthTab('login');
                    setError('');
                    setSuccessMessage('');
                  }}
                  className="inline-flex items-center gap-1 text-xs text-blue-600 font-bold hover:underline cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back to Login
                </button>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  PIN Recovery
                </span>
              </div>

              {forgotStep === 'verify' ? (
                /* Step 1: Enter User ID & Answer Security Question */
                <form onSubmit={handleForgotLookupAndVerify} className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1">
                      Enter User ID
                    </label>
                    <div className="relative flex items-center">
                      <span className="absolute left-4 text-blue-600 font-bold text-sm pointer-events-none">
                        @
                      </span>
                      <input
                        id="forgot-userid-input"
                        type="text"
                        value={forgotUserId}
                        onChange={(e) => {
                          setForgotUserId(e.target.value);
                          if (error) setError('');
                          const accounts = getStoredAccounts();
                          const found = accounts.find((a) => a.username.toLowerCase() === e.target.value.trim().replace(/^@/, '').toLowerCase());
                          setForgotFoundAccount(found || null);
                        }}
                        placeholder="User ID (e.g. mds_101)"
                        className="w-full pl-9 pr-4 py-3 bg-slate-50 rounded-2xl border border-slate-200 outline-none focus:bg-white focus:ring-2 ring-blue-500 text-slate-900 text-sm font-mono font-medium transition-all"
                        required
                        autoFocus
                      />
                    </div>
                  </div>

                  {/* Display Security Question if account identified */}
                  <div className="p-3 bg-blue-50 rounded-2xl border border-blue-100 space-y-1 text-left">
                    <div className="text-[10px] font-bold text-blue-600 uppercase tracking-wider flex items-center gap-1">
                      <HelpCircle className="w-3 h-3" />
                      <span>Security Question</span>
                    </div>
                    <div className="text-xs font-bold text-slate-800">
                      {forgotFoundAccount?.securityQuestion || "What is your favorite color?"}
                    </div>
                  </div>

                  {/* Answer Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider pl-1">
                      Security Answer
                    </label>
                    <input
                      id="forgot-answer-input"
                      type="text"
                      value={forgotAnswer}
                      onChange={(e) => {
                        setForgotAnswer(e.target.value);
                        if (error) setError('');
                      }}
                      placeholder="Enter the answer you registered with"
                      className="w-full px-4 py-3 bg-slate-50 rounded-2xl border border-slate-200 outline-none focus:bg-white focus:ring-2 ring-blue-500 text-slate-900 text-sm font-medium transition-all"
                      required
                    />
                  </div>

                  {error && (
                    <p className="text-xs text-rose-500 font-semibold text-center bg-rose-50 border border-rose-100 py-2 px-3 rounded-xl">
                      {error}
                    </p>
                  )}

                  <button
                    id="forgot-verify-button"
                    type="submit"
                    className="w-full py-3.5 bg-blue-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer text-sm"
                  >
                    <span>Verify & Change PIN</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                /* Step 2: Set New 6-Digit MPIN */
                <form onSubmit={handleResetPinSubmit} className="space-y-3.5">
                  <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-2 text-xs font-semibold text-emerald-800">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Identity verified for @{forgotFoundAccount?.username}! Create your new 6-digit MPIN.</span>
                  </div>

                  {/* New 6-Digit PIN */}
                  <div className="space-y-1">
                    <PinInput
                      id="reset-new-pin"
                      label="Enter New 6-Digit MPIN"
                      value={newPin}
                      onChange={(val) => {
                        setNewPin(val);
                        if (error) setError('');
                      }}
                      length={6}
                      autoFocus
                    />
                  </div>

                  {/* Confirm New 6-Digit PIN */}
                  <div className="space-y-1">
                    <PinInput
                      id="reset-confirm-pin"
                      label="Confirm New 6-Digit MPIN"
                      value={confirmNewPin}
                      onChange={(val) => {
                        setConfirmNewPin(val);
                        if (error) setError('');
                      }}
                      length={6}
                    />
                  </div>

                  {error && (
                    <p className="text-xs text-rose-500 font-semibold text-center bg-rose-50 border border-rose-100 py-2 px-3 rounded-xl">
                      {error}
                    </p>
                  )}

                  {successMessage && (
                    <p className="text-xs text-emerald-600 font-semibold text-center bg-emerald-50 border border-emerald-100 py-2 px-3 rounded-xl">
                      {successMessage}
                    </p>
                  )}

                  <button
                    id="save-new-pin-button"
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3.5 bg-blue-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-200 hover:bg-blue-700 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 text-sm"
                  >
                    <span>Save New MPIN & Log In</span>
                    <KeyRound className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Guest / Skip Option */}
          <div className="w-full mt-3 pt-1 border-t border-slate-100">
            <button
              id="login-later-button"
              type="button"
              onClick={handleGuestLogin}
              disabled={isLoading}
              className="w-full py-2 text-slate-400 text-xs font-semibold uppercase tracking-widest hover:text-blue-600 transition-all cursor-pointer text-center"
            >
              Play as Guest (Skip)
            </button>
          </div>

          {/* Geometric bottom bar accent */}
          <div className="mt-2 w-24 h-1 bg-slate-200 rounded-full"></div>

        </div>

        {/* Footer info */}
        <p className="text-xs text-slate-400 text-center mt-5 font-medium tracking-wide">
          Minddigit • 6-Digit MPIN Authentication & Recovery
        </p>

      </div>
    </main>
  );
};
