import React from 'react';

interface GuessNumberBadgeProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  mysteryText?: string;
  hintText?: string;
  guesses?: Array<{ num: number; dir: 'high' | 'low' | 'equal' }>;
  lives?: number;
}

export const GuessNumberBadge: React.FC<GuessNumberBadgeProps> = ({
  className = '',
  size = 'md',
  mysteryText = '??',
  hintText = 'HINT: HIGHER OR LOWER',
  guesses = [
    { num: 42, dir: 'low' },
    { num: 55, dir: 'low' },
    { num: 61, dir: 'low' },
    { num: 65, dir: 'high' },
  ],
  lives = 5,
}) => {
  const isSm = size === 'sm';
  const isLg = size === 'lg';

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      
      {/* 3D Arc Rainbow Title: GUESS NUMBER */}
      <div className="flex flex-col items-center -mb-3 z-20">
        {/* GUESS */}
        <div className="flex items-center gap-0.5 tracking-wide drop-shadow-[0_4px_6px_rgba(0,0,0,0.6)]">
          <span className="font-black text-rose-500 text-2xl sm:text-3xl transform -rotate-3 text-stroke-black drop-shadow-[0_2px_0_#991b1b]">G</span>
          <span className="font-black text-orange-500 text-2xl sm:text-3xl transform -rotate-1 drop-shadow-[0_2px_0_#9a3412]">U</span>
          <span className="font-black text-amber-400 text-2xl sm:text-3xl drop-shadow-[0_2px_0_#b45309]">E</span>
          <span className="font-black text-emerald-400 text-2xl sm:text-3xl transform rotate-1 drop-shadow-[0_2px_0_#065f46]">S</span>
          <span className="font-black text-cyan-400 text-2xl sm:text-3xl transform rotate-3 drop-shadow-[0_2px_0_#0e7490]">S</span>
        </div>
        {/* NUMBER */}
        <div className="flex items-center gap-0.5 tracking-wider -mt-1.5 drop-shadow-[0_4px_6px_rgba(0,0,0,0.6)]">
          <span className="font-black text-emerald-400 text-xl sm:text-2xl transform -rotate-3 drop-shadow-[0_2px_0_#065f46]">N</span>
          <span className="font-black text-teal-300 text-xl sm:text-2xl transform -rotate-1 drop-shadow-[0_2px_0_#0f766e]">U</span>
          <span className="font-black text-cyan-400 text-xl sm:text-2xl drop-shadow-[0_2px_0_#0e7490]">M</span>
          <span className="font-black text-blue-500 text-xl sm:text-2xl transform rotate-1 drop-shadow-[0_2px_0_#1e3a8a]">B</span>
          <span className="font-black text-purple-500 text-xl sm:text-2xl transform rotate-2 drop-shadow-[0_2px_0_#581c87]">E</span>
          <span className="font-black text-pink-500 text-xl sm:text-2xl transform rotate-4 drop-shadow-[0_2px_0_#831843]">R</span>
        </div>
      </div>

      {/* Main Wooden Shield Badge with Neon Blue Glowing Border */}
      <div className={`relative bg-gradient-to-b from-[#8B5A2B] via-[#6B4226] to-[#4A2E1B] rounded-[28px] border-[5px] border-[#D2B48C] shadow-[0_12px_30px_rgba(0,0,0,0.5),inset_0_2px_4px_rgba(255,255,255,0.4)] ${
        isSm ? 'p-3 w-48' : isLg ? 'p-6 w-80' : 'p-4 w-64 sm:w-72'
      } flex flex-col items-center gap-2.5 z-10`}>
        
        {/* Wooden Side Scrolls / Ears */}
        <div className="absolute -left-3 top-8 w-4 h-16 bg-[#6B4226] border-2 border-[#3d2414] rounded-l-lg shadow-md -z-10" />
        <div className="absolute -right-3 top-8 w-4 h-16 bg-[#6B4226] border-2 border-[#3d2414] rounded-r-lg shadow-md -z-10" />

        {/* Outer Neon Cyan Halo Frame */}
        <div className="w-full bg-[#0B192C] border-2 border-cyan-400 rounded-2xl p-2.5 shadow-[0_0_15px_rgba(6,182,212,0.4),inset_0_0_12px_rgba(6,182,212,0.3)] flex flex-col items-center text-center">
          
          {/* Mystery Box Question Mark */}
          <div className="text-3xl sm:text-4xl font-black text-white tracking-widest drop-shadow-[0_0_12px_rgba(255,255,255,0.8)] my-1">
            {mysteryText}
          </div>

          {/* Hint Bar */}
          <div className="text-[10px] sm:text-[11px] font-black tracking-wider text-cyan-300 uppercase">
            {hintText}
          </div>
        </div>

        {/* Previous Guesses Wooden Shelf */}
        <div className="w-full bg-[#5C381E] border border-[#3e2413] rounded-xl p-2 flex flex-col items-center gap-1.5 shadow-inner">
          <span className="text-[9px] font-black uppercase text-amber-200 tracking-wider">
            PREVIOUS GUESSES
          </span>

          <div className="grid grid-cols-4 gap-1.5 w-full">
            {guesses.slice(-4).map((g, idx) => (
              <div 
                key={idx}
                className="bg-white rounded-lg py-1 px-1 flex items-center justify-center gap-0.5 shadow-md border border-slate-200"
              >
                <span className="font-black font-mono text-slate-900 text-xs sm:text-sm">
                  {g.num}
                </span>
                {g.dir === 'low' ? (
                  <span className="text-emerald-500 font-black text-[10px]">▲</span>
                ) : g.dir === 'high' ? (
                  <span className="text-rose-500 font-black text-[10px]">▼</span>
                ) : (
                  <span className="text-amber-500 font-black text-[10px]">★</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Lives Counter Ribbon at Bottom */}
        <div className="bg-[#1e293b] border-2 border-amber-400 rounded-xl px-4 py-1 flex items-center gap-1.5 shadow-md -mb-6 z-20">
          <span className="text-[10px] font-black text-amber-300 uppercase tracking-wider">LIVES:</span>
          <span className="text-sm">🖐️</span>
          <span className="font-black text-white text-xs">{lives}</span>
        </div>

      </div>

    </div>
  );
};
