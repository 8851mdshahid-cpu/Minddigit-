import React, { useState, useEffect } from 'react';
import { X, Play, Sparkles, Coins, Gift, Film, CheckCircle2 } from 'lucide-react';
import { sound } from '../utils/audio';
import confetti from 'canvas-confetti';

interface AdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardClaimed: (tokensGained: number) => void;
}

export const AdModal: React.FC<AdModalProps> = ({
  isOpen,
  onClose,
  onRewardClaimed,
}) => {
  const [adState, setAdState] = useState<'preview' | 'playing' | 'reward'>('preview');
  const [timeLeft, setTimeLeft] = useState<number>(5);
  const [progress, setProgress] = useState<number>(0);

  useEffect(() => {
    if (!isOpen) {
      setAdState('preview');
      setTimeLeft(5);
      setProgress(0);
      return;
    }
  }, [isOpen]);

  useEffect(() => {
    let timer: any;
    if (adState === 'playing') {
      const interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setAdState('reward');
            sound.playWin();
            confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            return 100;
          }
          return prev + 2;
        });
      }, 100);

      return () => {
        clearInterval(interval);
        clearInterval(progressInterval);
      };
    }
  }, [adState]);

  if (!isOpen) return null;

  const handleStartWatchAd = () => {
    sound.playPop();
    setAdState('playing');
    setTimeLeft(5);
    setProgress(0);
  };

  const handleClaimTokens = () => {
    sound.playWin();
    onRewardClaimed(20);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs select-none">
      <div className="relative w-full max-w-sm bg-white rounded-[32px] p-6 shadow-2xl border border-white text-center overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button (disabled while ad is playing) */}
        {adState !== 'playing' && (
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* State 1: Preview */}
        {adState === 'preview' && (
          <div className="flex flex-col items-center py-2">
            <div className="w-16 h-16 rounded-3xl bg-amber-50 border-2 border-amber-200 flex items-center justify-center text-amber-500 mb-4 shadow-sm">
              <Gift className="w-8 h-8" />
            </div>

            <h3 className="text-xl font-black text-slate-900 mb-1">
              Watch Ad for Free Tokens
            </h3>
            <p className="text-xs text-slate-500 max-w-[260px] mb-6">
              Watch a quick 5-second video sponsorship to instantly earn +20 Tokens for rooms & games!
            </p>

            <div className="w-full bg-amber-50/80 border border-amber-200/70 rounded-2xl p-3.5 mb-6 flex items-center justify-center gap-2.5">
              <Coins className="w-5 h-5 text-amber-500 fill-amber-400" />
              <span className="text-base font-black text-amber-900">
                Reward: +20 Tokens
              </span>
            </div>

            <button
              type="button"
              onClick={handleStartWatchAd}
              className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-extrabold rounded-2xl shadow-lg shadow-orange-500/25 hover:from-amber-600 hover:to-orange-600 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Watch Short Ad (5s)</span>
            </button>
          </div>
        )}

        {/* State 2: Playing */}
        {adState === 'playing' && (
          <div className="flex flex-col items-center py-4">
            <div className="w-full h-44 rounded-2xl bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-900 relative flex flex-col items-center justify-center text-white overflow-hidden mb-4 shadow-inner">
              <Film className="w-10 h-10 text-amber-400 animate-pulse mb-2" />
              <p className="text-xs font-bold text-slate-300">MindDigit Arcade Special</p>
              <p className="text-base font-black text-amber-300 mt-0.5">Mystery Number Challenge</p>
              
              {/* Ad Countdown timer badge */}
              <div className="absolute top-2 right-2 px-2.5 py-1 bg-black/60 backdrop-blur-xs rounded-full border border-white/20 text-[11px] font-black text-white">
                Reward in {timeLeft}s
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden mb-3">
              <div 
                className="bg-amber-500 h-full rounded-full transition-all duration-100"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs font-bold text-slate-400">Playing ad video stream...</p>
          </div>
        )}

        {/* State 3: Reward Claim */}
        {adState === 'reward' && (
          <div className="flex flex-col items-center py-2 animate-in zoom-in duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-300 text-emerald-500 flex items-center justify-center mb-3">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-xl font-black text-slate-900 mb-1">
              Reward Ready!
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Thank you for watching! +20 Tokens have been unlocked.
            </p>

            <div className="w-full bg-emerald-50 border border-emerald-200 rounded-2xl p-4 mb-5 flex items-center justify-center gap-2 text-emerald-800 font-black text-lg">
              <Coins className="w-6 h-6 text-amber-500 fill-amber-400" />
              <span>+20 TOKENS ADDED</span>
            </div>

            <button
              type="button"
              onClick={handleClaimTokens}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-2xl shadow-lg shadow-emerald-600/25 active:scale-98 transition-all cursor-pointer"
            >
              Collect & Continue
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
