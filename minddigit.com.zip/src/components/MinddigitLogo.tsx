import React, { useState } from 'react';

interface MinddigitLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const MinddigitLogo: React.FC<MinddigitLogoProps> = ({ className = '', size = 'lg' }) => {
  const [imgErrorIndex, setImgErrorIndex] = useState(0);

  // Candidate image paths for the uploaded 3D photo
  const imageSources = [
    'IMG_20260825_202113.png',
    '/IMG_20260825_202113.png',
    './IMG_20260825_202113.png',
    '/assets/IMG_20260825_202113.png',
    '/1787665198729.png',
  ];

  const sizeStyles = {
    sm: 'h-14 max-w-[180px]',
    md: 'h-20 max-w-[240px]',
    lg: 'h-28 max-w-[320px]',
    xl: 'h-36 max-w-[420px]',
  };

  // If there is still an image candidate to try, load it
  if (imgErrorIndex < imageSources.length) {
    return (
      <div className={`relative flex items-center justify-center select-none ${className}`}>
        <img
          src={imageSources[imgErrorIndex]}
          alt="Minddigit 3D Logo"
          onError={() => setImgErrorIndex((prev) => prev + 1)}
          className={`${sizeStyles[size]} object-contain drop-shadow-md transition-transform duration-300 hover:scale-105`}
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Fallback high-fidelity 3D bubble inflated lettering matching IMG_20260825_202113.png
  return (
    <div className={`relative flex flex-col items-center justify-center select-none ${className}`}>
      <div className="relative group cursor-pointer py-1">
        {/* Soft background ambient glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-300/30 via-pink-300/30 to-amber-300/30 blur-xl rounded-full scale-110"></div>
        
        {/* 3D Extruded Multi-colored Bubble Wordmark matching IMG_20260825_202113.png */}
        <div className="relative flex items-center tracking-tight font-black text-3xl sm:text-4xl md:text-5xl drop-shadow-[0_8px_16px_rgba(30,41,59,0.18)] font-sans">
          
          {/* M - Sky Blue with Dark Outline & 3D bevel */}
          <span className="relative inline-block text-sky-400 transform -rotate-3 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#0369a1]">
            M
          </span>

          {/* i - Sunny Yellow */}
          <span className="relative inline-block text-amber-300 transform rotate-2 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#b45309]">
            i
          </span>

          {/* n - Fresh Lime Green */}
          <span className="relative inline-block text-emerald-400 transform -rotate-2 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#047857]">
            n
          </span>

          {/* d - Sunset Orange */}
          <span className="relative inline-block text-orange-400 transform rotate-4 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#c2410c]">
            d
          </span>

          {/* d - Hot Coral Pink */}
          <span className="relative inline-block text-rose-400 transform -rotate-4 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#be123c]">
            d
          </span>

          {/* i - Magenta / Pink */}
          <span className="relative inline-block text-fuchsia-400 transform rotate-2 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#a21caf]">
            i
          </span>

          {/* g - Cyan / Blue */}
          <span className="relative inline-block text-blue-500 transform -rotate-3 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#1d4ed8]">
            g
          </span>

          {/* i - Yellow */}
          <span className="relative inline-block text-amber-300 transform rotate-3 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#b45309]">
            i
          </span>

          {/* t - Purple */}
          <span className="relative inline-block text-purple-500 transform -rotate-4 transition-transform hover:scale-110 px-0.5 filter drop-shadow-[0_4px_0_#6d28d9]">
            t
          </span>

        </div>

      </div>
    </div>
  );
};
