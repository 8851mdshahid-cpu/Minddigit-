import React, { useState, useEffect } from 'react';
import { Shield, Eye, EyeOff, Copy, Check, Search, RefreshCw, KeyRound, UserCheck, Sparkles, HelpCircle, Lock, Users } from 'lucide-react';
import { StoredUserAccount, getStoredAccounts, saveAccounts } from './LoginPage';
import { sound } from '../utils/audio';

interface AdminUsersVaultProps {
  currentUsername: string;
}

export const AdminUsersVault: React.FC<AdminUsersVaultProps> = ({ currentUsername }) => {
  const [accounts, setAccounts] = useState<StoredUserAccount[]>([]);
  const [revealedPins, setRevealedPins] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isExpanded, setIsExpanded] = useState(true);

  // Load registered accounts
  const loadAccounts = () => {
    const data = getStoredAccounts();
    setAccounts(data);
  };

  useEffect(() => {
    loadAccounts();
    const interval = setInterval(loadAccounts, 2000);
    return () => clearInterval(interval);
  }, []);

  const togglePinVisibility = (id: string) => {
    sound.playClick();
    setRevealedPins((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyCredentials = (account: StoredUserAccount) => {
    sound.playPop();
    const text = `User: @${account.username}\nName: ${account.name}\nPIN: ${account.pin}\nSecurity Question: ${account.securityQuestion}\nAnswer: ${account.securityAnswer}`;
    navigator.clipboard.writeText(text);
    setCopiedId(account.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddCoins = (id: string, amount: number) => {
    sound.playPop();
    const updated = accounts.map((acc) => {
      if (acc.id === id) {
        return { ...acc, coins: (acc.coins || 0) + amount };
      }
      return acc;
    });
    saveAccounts(updated);
    setAccounts(updated);
  };

  const filteredAccounts = accounts.filter(
    (acc) =>
      acc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      acc.pin.includes(searchQuery)
  );

  return (
    <div 
      id="admin-security-vault-box"
      className="w-full mb-8 bg-slate-900 text-white rounded-3xl p-5 sm:p-6 shadow-2xl border-2 border-amber-500/40 relative overflow-hidden animate-in fade-in slide-in-from-top-4 duration-300"
    >
      {/* Decorative luxury gradient glow */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Banner / Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
                👑 Admin Security Vault
              </h2>
              <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40">
                Master ID: @{currentUsername}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live database of all registered users, PINs & security answers
            </p>
          </div>
        </div>

        {/* Right Action tools */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold font-mono bg-slate-800 text-amber-400 px-3 py-1.5 rounded-xl border border-slate-700">
            {accounts.length} Registered {accounts.length === 1 ? 'User' : 'Users'}
          </span>
          <button
            id="admin-refresh-vault-btn"
            type="button"
            onClick={() => {
              sound.playClick();
              loadAccounts();
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer"
            title="Refresh Users List"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            id="admin-toggle-collapse-btn"
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-xs font-bold text-slate-300 hover:text-white px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 transition-all cursor-pointer"
          >
            {isExpanded ? 'Collapse' : 'Expand'}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="mt-4 space-y-4">
          
          {/* Search bar inside vault */}
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
            <input
              id="admin-vault-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user by name, @username or PIN..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-950/70 rounded-2xl border border-slate-800 text-xs text-white placeholder:text-slate-500 outline-none focus:border-amber-500/60 focus:ring-1 focus:ring-amber-500/40 font-medium"
            />
          </div>

          {/* User Vault Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
            {filteredAccounts.map((acc) => {
              const isPinRevealed = Boolean(revealedPins[acc.id]);
              const isCurrentAdmin = acc.username.toLowerCase() === 'shahid8851';

              return (
                <div
                  key={acc.id}
                  id={`user-vault-card-${acc.username}`}
                  className={`p-4 rounded-2xl border transition-all ${
                    isCurrentAdmin
                      ? 'bg-slate-800/90 border-amber-500/40 ring-1 ring-amber-500/20'
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {/* Top: Name & Username & Role */}
                  <div className="flex items-center justify-between gap-2 mb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center font-bold text-xs text-white border border-slate-700">
                        {acc.name ? acc.name.charAt(0).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>{acc.name}</span>
                          {isCurrentAdmin && (
                            <span className="text-[9px] font-black bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded-md uppercase">
                              ADMIN
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] font-mono font-bold text-amber-400">
                          @{acc.username}
                        </div>
                      </div>
                    </div>

                    {/* Copy All Info Button */}
                    <button
                      type="button"
                      onClick={() => handleCopyCredentials(acc)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all cursor-pointer"
                      title="Copy User Credentials"
                    >
                      {copiedId === acc.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* Information Box: Security Question, Answer, and PIN */}
                  <div className="space-y-2 bg-slate-900/80 rounded-xl p-3 border border-slate-800/80 text-xs">
                    
                    {/* 1. PIN CODE */}
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                        <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                        <span>PIN Code:</span>
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-sm text-emerald-400 tracking-wider bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                          {isPinRevealed ? acc.pin : '••••••'}
                        </span>
                        <button
                          type="button"
                          onClick={() => togglePinVisibility(acc.id)}
                          className="text-slate-400 hover:text-white p-1 cursor-pointer"
                          title={isPinRevealed ? 'Hide PIN' : 'Reveal PIN'}
                        >
                          {isPinRevealed ? (
                            <EyeOff className="w-3.5 h-3.5 text-amber-400" />
                          ) : (
                            <Eye className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {/* 2. Security Question */}
                    <div className="pt-1 border-t border-slate-800">
                      <div className="text-[10px] font-semibold text-slate-400 flex items-center gap-1">
                        <HelpCircle className="w-3 h-3 text-blue-400" />
                        <span>Security Question:</span>
                      </div>
                      <div className="text-[11px] text-slate-300 font-medium pl-4">
                        {acc.securityQuestion || 'What is your favorite color?'}
                      </div>
                    </div>

                    {/* 3. Security Answer */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                      <span className="text-[10px] font-semibold text-slate-400">
                        Security Answer:
                      </span>
                      <span className="font-bold text-amber-300 bg-amber-950/40 border border-amber-500/30 px-2 py-0.5 rounded text-[11px]">
                        {acc.securityAnswer || 'Not Set'}
                      </span>
                    </div>

                  </div>

                  {/* Bottom Stats & Quick Tools */}
                  <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
                    <div className="flex items-center gap-2">
                      <span>💰 {acc.coins || 0} Coins</span>
                      <span>•</span>
                      <span>🏆 {acc.score || 0} Pts</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleAddCoins(acc.id, 500)}
                      className="text-[10px] font-bold text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-1 rounded-lg border border-amber-500/30 transition-all cursor-pointer"
                    >
                      +500 Coins
                    </button>
                  </div>

                </div>
              );
            })}
          </div>

        </div>
      )}
    </div>
  );
};
