import React, { useState } from 'react';
import { X, Bot, Globe, Coins, ShieldAlert, Sparkles, Users, KeyRound, ArrowRight, ArrowLeft, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { GameMode, DifficultyLevel, UserProfile } from '../types';
import { sound } from '../utils/audio';
import { findRoomByCode, findRoomAsync, registerNewRoom, getActiveRooms, GameRoom } from '../utils/rooms';

interface ModeSelectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMode: (mode: GameMode, difficulty: DifficultyLevel, roomCodeToJoin?: string, opponentInfo?: { name: string; username: string }) => void;
  user: UserProfile;
  onOpenAdModal: () => void;
}

export const ModeSelectModal: React.FC<ModeSelectModalProps> = ({
  isOpen,
  onClose,
  onSelectMode,
  user,
  onOpenAdModal,
}) => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel>('normal');
  const [errorMessage, setErrorMessage] = useState<string>('');
  
  // Room Setup State
  const [showRoomPopup, setShowRoomPopup] = useState<boolean>(false);
  const [roomAction, setRoomAction] = useState<'choose' | 'join'>('choose');
  const [enteredRoomId, setEnteredRoomId] = useState<string>('');
  const [roomInputError, setRoomInputError] = useState<string>('');
  const [isJoiningRoom, setIsJoiningRoom] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleModeChoice = (mode: GameMode) => {
    setErrorMessage('');
    setRoomInputError('');
    
    if (mode === 'online') {
      sound.playPop();
      setShowRoomPopup(true);
      setRoomAction('choose');
      return;
    }

    if (mode === 'computer') {
      if (user.coins < 1) {
        sound.playLose();
        setErrorMessage('Playing with Computer costs 1 Token. Watch an ad to get 20 free tokens!');
        return;
      }
      sound.playPop();
      onSelectMode('computer', selectedDifficulty);
    }
  };

  const handleConfirmCreateRoom = () => {
    if (user.coins < 10) {
      sound.playLose();
      setErrorMessage('You need at least 10 Tokens to create a new room. Or join a friend\'s room for free!');
      return;
    }
    sound.playWin();
    // Register the created room in active registry and Firestore so friends can match it
    const newRoom = registerNewRoom(user.name, user.username, selectedDifficulty, undefined, 'guess-number');
    setShowRoomPopup(false);
    onSelectMode('online', selectedDifficulty, newRoom.code);
  };

  const handleConfirmJoinRoom = async (codeToJoin?: string) => {
    const rawInput = (codeToJoin || enteredRoomId).trim();
    setRoomInputError('');

    if (!rawInput) {
      sound.playLose();
      setRoomInputError('Please enter your friend\'s Room ID.');
      return;
    }

    setIsJoiningRoom(true);
    sound.playPop();

    try {
      const result = await findRoomAsync(rawInput, 'guess-number');
      setIsJoiningRoom(false);

      if (!result.success || !result.room) {
        sound.playLose();
        setRoomInputError(result.message || `❌ Invalid Room ID! No active room found for "${rawInput}". Please check with your friend.`);
        return;
      }

      // Success: Room found! No coins deducted when entering a friend's code!
      sound.playWin();
      setShowRoomPopup(false);
      onSelectMode('online', result.room.difficulty || 'normal', result.room.code, {
        name: result.room.hostName || 'Friend Host',
        username: result.room.hostUsername || 'friend_host',
      });
    } catch {
      setIsJoiningRoom(false);
      sound.playLose();
      setRoomInputError('Connection error while finding room. Please try again.');
    }
  };


  const getDifficultyReward = (diff: DifficultyLevel) => {
    if (diff === 'easy') return { reward: 10, range: '1-50' };
    if (diff === 'normal') return { reward: 20, range: '1-100' };
    return { reward: 50, range: '1-500' };
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs select-none animate-in fade-in duration-200">
      <div 
        id="mode-select-modal"
        className="w-full max-w-[430px] bg-white rounded-[36px] shadow-2xl p-6 sm:p-7 flex flex-col gap-4 border border-white relative overflow-hidden"
      >
        {/* Close Button Top Right */}
        <button
          id="close-mode-modal"
          type="button"
          onClick={() => {
            sound.playClick();
            setShowRoomPopup(false);
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* ============================================================
            1. ONLINE ROOM 10 TOKENS CONFIRMATION & ID ENTRY POPUP
            ============================================================ */}
        {showRoomPopup ? (
          <div className="flex flex-col gap-4 animate-in zoom-in-95 duration-200">
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setShowRoomPopup(false);
                }}
                className="p-1.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-900 rounded-full font-black text-xs">
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                <span>ONLINE 2-PLAYER ROOM</span>
              </div>
            </div>

            {/* Room Notice Card */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-indigo-200 rounded-2xl p-4 text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-600 text-white font-black text-xs rounded-full shadow-xs mb-2">
                <Users className="w-3.5 h-3.5 fill-white" />
                <span>2-Player Match</span>
              </div>
              <h4 className="text-base font-black text-slate-900">
                Play With Friends
              </h4>
              <p className="text-xs text-slate-600 mt-1">
                Entering a friend's room ID is <strong className="text-emerald-600 font-bold">100% Free (0 Coins)</strong>.
              </p>
            </div>

            {/* Room Action Choice: Create Room OR Enter Friend's Room ID */}
            {roomAction === 'choose' ? (
              <div className="flex flex-col gap-2.5">
                
                {/* 1. Enter Friend's Room ID (Free) */}
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setRoomAction('join');
                  }}
                  className="w-full p-4 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm flex items-center justify-between shadow-md shadow-indigo-500/25 transition-all cursor-pointer active:scale-98"
                >
                  <div className="flex items-center gap-2.5">
                    <KeyRound className="w-5 h-5 text-white" />
                    <div className="text-left">
                      <div className="font-extrabold text-sm">Enter Friend's Room ID</div>
                      <div className="text-[11px] text-indigo-100 font-normal">Free • Connect with friend's code</div>
                    </div>
                  </div>
                  <span className="text-xs bg-emerald-500 text-white px-2.5 py-1 rounded-xl font-bold">FREE</span>
                </button>

                {/* 2. Create New Room */}
                <button
                  type="button"
                  onClick={handleConfirmCreateRoom}
                  className="w-full p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 text-slate-800 font-black text-sm flex items-center justify-between border border-slate-200 shadow-xs transition-all cursor-pointer active:scale-98"
                >
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-5 h-5 text-blue-600" />
                    <div className="text-left">
                      <div className="font-extrabold text-sm text-slate-900">Create New Room</div>
                      <div className="text-[11px] text-slate-500 font-normal">Generate ID & invite a friend</div>
                    </div>
                  </div>
                  <span className="text-xs bg-amber-100 text-amber-900 border border-amber-300 px-2 py-0.5 rounded-lg font-mono font-bold">-10 🪙</span>
                </button>

              </div>
            ) : (
              /* Enter Room ID Input Form */
              <div className="flex flex-col gap-3">
                <div className="flex flex-col text-left">
                  <label className="text-xs font-black text-slate-700 uppercase tracking-wider mb-1 flex items-center justify-between">
                    <span>Enter Friend's Room ID</span>
                    <button
                      type="button"
                      onClick={() => {
                        setRoomAction('choose');
                        setRoomInputError('');
                      }}
                      className="text-[11px] text-blue-600 font-bold lowercase underline cursor-pointer"
                    >
                      back
                    </button>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. MIND-4821"
                    value={enteredRoomId}
                    onChange={(e) => {
                      setEnteredRoomId(e.target.value.toUpperCase());
                      if (roomInputError) setRoomInputError('');
                    }}
                    className={`w-full px-4 py-3 bg-slate-50 border-2 rounded-2xl font-mono font-black text-base text-center tracking-wider focus:bg-white focus:outline-none transition-colors ${
                      roomInputError
                        ? 'border-rose-400 text-rose-900 bg-rose-50/50 focus:border-rose-600'
                        : 'border-indigo-300 text-indigo-900 focus:border-indigo-600'
                    }`}
                    autoFocus
                  />
                  
                  {/* Validation Error Message */}
                  {roomInputError ? (
                    <div className="mt-2 p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-bold flex items-start gap-1.5 animate-in fade-in duration-150">
                      <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <span>{roomInputError}</span>
                    </div>
                  ) : (
                    <span className="text-[10px] text-slate-400 mt-1">
                      Enter the exact Room ID created by your friend. No coins are deducted.
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  disabled={isJoiningRoom}
                  onClick={() => handleConfirmJoinRoom()}
                  className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-black text-sm flex items-center justify-center gap-2 shadow-md shadow-indigo-500/25 transition-all cursor-pointer active:scale-98"
                >
                  {isJoiningRoom ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Connecting to Room...</span>
                    </>
                  ) : (
                    <>
                      <Users className="w-4 h-4" />
                      <span>Connect & Join Friend (Free)</span>
                    </>
                  )}
                </button>

              </div>
            )}

          </div>
        ) : (
          /* ============================================================
              2. STANDARD MODE SELECTION (Computer vs Online Room)
             ============================================================ */
          <>
            {/* Modal Header */}
            <div className="text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 rounded-full mb-2">
                <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                <span className="text-xs font-black text-amber-900">Your Balance: {user.coins} Tokens</span>
              </div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                Select Game Mode
              </h3>
              <p className="text-slate-500 text-xs mt-0.5 font-medium">
                Choose difficulty & opponent to start guessing
              </p>
            </div>

            {/* Token error message banner */}
            {errorMessage && (
              <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex flex-col gap-2">
                <div className="flex items-start gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAdModal();
                  }}
                  className="w-full py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl text-center cursor-pointer transition-colors shadow-2xs"
                >
                  📺 Watch 5s Ad to Get +20 Tokens
                </button>
              </div>
            )}

            {/* Difficulty Selector with clear Token Rewards */}
            <div className="flex flex-col gap-1.5">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 px-1">
                Choose Range & Token Rewards
              </div>
              <div className="grid grid-cols-3 gap-2 bg-slate-50 p-1.5 rounded-2xl border border-slate-100">
                {(['easy', 'normal', 'hard'] as DifficultyLevel[]).map((diff) => {
                  const info = getDifficultyReward(diff);
                  const isSelected = selectedDifficulty === diff;
                  return (
                    <button
                      key={diff}
                      type="button"
                      onClick={() => {
                        sound.playClick();
                        setSelectedDifficulty(diff);
                      }}
                      className={`py-2 px-1 rounded-xl text-center flex flex-col items-center justify-center transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'text-slate-600 hover:bg-white'
                      }`}
                    >
                      <span className="text-xs font-extrabold capitalize">{diff}</span>
                      <span className={`text-[10px] font-mono ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                        {info.range}
                      </span>
                      <span className={`text-[10px] font-bold mt-0.5 ${isSelected ? 'text-amber-300' : 'text-amber-600'}`}>
                        +{info.reward} 🪙
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2 Game Mode Options */}
            <div className="flex flex-col gap-2.5 mt-1">
              
              {/* 1. Play with Computer */}
              <button
                id="play-computer-btn"
                type="button"
                onClick={() => handleModeChoice('computer')}
                className="group flex items-center justify-between p-3.5 sm:p-4 bg-slate-50 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all cursor-pointer border border-slate-100 hover:shadow-md active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-xs text-indigo-600 group-hover:scale-95 transition-transform">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <p className="font-extrabold text-slate-900 group-hover:text-white text-sm">
                        Play with Computer
                      </p>
                      <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-indigo-100 group-hover:bg-white/20 text-indigo-700 group-hover:text-white">
                        Fee: 1 🪙
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 group-hover:text-indigo-100">
                      Win up to +{getDifficultyReward(selectedDifficulty).reward} Tokens upon victory!
                    </p>
                  </div>
                </div>
                <span className="text-slate-300 group-hover:text-white font-bold text-base">→</span>
              </button>

              {/* 2. Play Online / Room */}
              <button
                id="play-online-btn"
                type="button"
                onClick={() => handleModeChoice('online')}
                className="group flex items-center justify-between p-3.5 sm:p-4 bg-slate-50 rounded-2xl hover:bg-blue-600 hover:text-white transition-all cursor-pointer border border-slate-100 hover:shadow-md active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-xs text-blue-600 group-hover:scale-95 transition-transform">
                    <Globe className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-1.5">
                      <p className="font-extrabold text-slate-900 group-hover:text-white text-sm">
                        Play Online (Room)
                      </p>
                      <span className="text-[10px] font-black px-1.5 py-0.5 rounded-full bg-blue-100 group-hover:bg-white/20 text-blue-700 group-hover:text-white">
                        Cost: 10 🪙
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 group-hover:text-blue-100">
                      Create room or enter friend's ID to play
                    </p>
                  </div>
                </div>
                <span className="text-slate-300 group-hover:text-white font-bold text-base">→</span>
              </button>
            </div>

            {/* Free Tokens Ad shortcut at bottom */}
            <div className="mt-1 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                <span>Need more tokens?</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAdModal();
                }}
                className="text-xs font-extrabold text-amber-600 hover:text-amber-700 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-xl border border-amber-200 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>📺 Watch Ad (+20 🪙)</span>
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
