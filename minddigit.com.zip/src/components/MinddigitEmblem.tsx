import React, { useState } from 'react';

interface MinddigitEmblemProps {
  className?: string;
  size?: number;
}

export const MinddigitEmblem: React.FC<MinddigitEmblemProps> = ({ className = '', size = 42 }) => {
  const [imgErrorIndex, setImgErrorIndex] = useState(0);

  const imageSources = [
    '5923-modified.png',
    '/5923-modified.png',
    './5923-modified.png',
    '/assets/5923-modified.png',
  ];

  if (imgErrorIndex < imageSources.length) {
    return (
      <div 
        className={`relative inline-flex items-center justify-center rounded-full overflow-hidden shadow-md ring-2 ring-amber-300/70 bg-amber-50 shrink-0 transition-transform duration-200 hover:scale-105 ${className}`}
        style={{ width: size, height: size }}
      >
        <img
          src={imageSources[imgErrorIndex]}
          alt="MindDigit Quilted Star & 9 Emblem"
          onError={() => setImgErrorIndex((prev) => prev + 1)}
          className="w-full h-full object-cover rounded-full"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  // Fallback high-fidelity SVG representation of the circular quilted star & number 9 embroidery artwork
  return (
    <div 
      className={`relative inline-flex items-center justify-center rounded-full shadow-md bg-[#FAF5EE] ring-2 ring-amber-300/80 p-0.5 shrink-0 transition-transform duration-200 hover:scale-105 ${className}`}
      style={{ width: size, height: size }}
    >
      <svg 
        viewBox="0 0 100 100" 
        className="w-full h-full rounded-full"
      >
        <defs>
          <radialGradient id="quiltBg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="70%" stopColor="#F9F5EB" />
            <stop offset="100%" stopColor="#EFE5D3" />
          </radialGradient>
          <linearGradient id="starGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="50%" stopColor="#FCA5A5" />
            <stop offset="100%" stopColor="#F472B6" />
          </linearGradient>
          <linearGradient id="numNineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#BAE6FD" />
            <stop offset="50%" stopColor="#93C5FD" />
            <stop offset="100%" stopColor="#C084FC" />
          </linearGradient>
        </defs>

        {/* Outer Stitched Quilted Rings */}
        <circle cx="50" cy="50" r="48" fill="url(#quiltBg)" stroke="#D4A373" strokeWidth="2" />
        <circle cx="50" cy="50" r="44" fill="none" stroke="#E29578" strokeWidth="1.2" strokeDasharray="2,2" />
        <circle cx="50" cy="50" r="39" fill="none" stroke="#DDBEA9" strokeWidth="1" />
        <circle cx="50" cy="50" r="34" fill="#E8F4F8" opacity="0.85" />

        {/* Lightbulb at top */}
        <path d="M47 18 C47 14 53 14 53 18 C53 20 51 21 51 23 L49 23 C49 21 47 20 47 18 Z" fill="#FEF08A" stroke="#CA8A04" strokeWidth="0.8" />
        <rect x="48.5" y="23" width="3" height="1.5" rx="0.5" fill="#94A3B8" />

        {/* Big Bubbly Number 9 Swirl */}
        <path 
          d="M62 26 C69 26 73 31 71 39 C70 47 62 50 56 55 C52 59 50 67 52 74" 
          fill="none" 
          stroke="url(#numNineGrad)" 
          strokeWidth="7" 
          strokeLinecap="round"
        />
        <circle cx="52" cy="74" r="3.2" fill="#A855F7" />

        {/* Puffy Smiling Star on Left */}
        <path 
          d="M38 34 L41 26 L45 34 L54 36 L47 43 L50 52 L41 46 L32 52 L35 43 L28 36 Z" 
          fill="url(#starGrad)" 
          stroke="#E11D48" 
          strokeWidth="0.8"
        />
        {/* Star cute face */}
        <circle cx="38" cy="40" r="1.2" fill="#881337" />
        <circle cx="44" cy="40" r="1.2" fill="#881337" />
        <circle cx="36" cy="42" r="1.2" fill="#FB7185" opacity="0.8" />
        <circle cx="46" cy="42" r="1.2" fill="#FB7185" opacity="0.8" />
        <path d="M39.5 43 Q41 45 42.5 43" stroke="#881337" strokeWidth="0.8" fill="none" strokeLinecap="round" />

        {/* Small Baby Stars & Playful Blocks */}
        <rect x="22" y="47" width="9" height="9" rx="1.5" fill="#FED7AA" stroke="#EA580C" strokeWidth="0.6" />
        <rect x="58" y="52" width="11" height="11" rx="2" fill="#FEF08A" stroke="#CA8A04" strokeWidth="0.8" />
        <text x="63.5" y="60.5" fontSize="7" fontWeight="bold" fill="#B45309" textAnchor="middle">?</text>
      </svg>
    </div>
  );
};
