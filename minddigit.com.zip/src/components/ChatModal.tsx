import React, { useState } from 'react';
import { X, Send, Bot, Sparkles, HelpCircle, Flame, Lightbulb } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export const ChatModal: React.FC<ChatModalProps> = ({
  isOpen,
  onClose,
  user,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'ai',
      text: `Hello ${user.name}! 👋 I am your MindDigit Strategy Companion. Ask me for guessing strategies, math tricks, or game clues!`,
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const quickPrompts = [
    '🎯 Best strategy for 1-100?',
    '💡 What is Binary Search method?',
    '🔥 How to earn more coins?',
  ];

  const handleSend = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    sound.playPop();
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');

    // Generate intelligent companion response
    setTimeout(() => {
      let reply = "Always start around the halfway mark (like 50 in 1-100) to eliminate 50% of the range in one guess! 🧠";
      const lower = text.toLowerCase();

      if (lower.includes('strategy') || lower.includes('best') || lower.includes('1-100')) {
        reply = "Strategy Tip: Start at 50. If it says HIGHER, guess 75. If LOWER, guess 25. By dividing the remaining numbers in half each time (Binary Search), you can always find the number in under 7 guesses! 🚀";
      } else if (lower.includes('binary') || lower.includes('search')) {
        reply = "Binary Search divides the remaining search space by 2 each turn. For 1-100, maximum guesses needed is only log₂(100) ≈ 7 guesses! 💡";
      } else if (lower.includes('coin') || lower.includes('score') || lower.includes('earn')) {
        reply = "Earn bonus coins by winning with 3 or more lives remaining, and by keeping a winning streak going! 🪙✨";
      } else if (lower.includes('clue') || lower.includes('hint')) {
        reply = "Use the 'Free Clue' button during any game round to find out if the target is Even, Odd, Prime, or a multiple of 5! 🔍";
      } else {
        reply = `Great thinking, ${user.name}! Keep testing numbers, track your previous Higher/Lower indicators, and trust your intuition. You've got this! 🏆`;
      }

      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      sound.playPop();
      setMessages((prev) => [...prev, aiMsg]);
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
      <div className="bg-white rounded-[28px] max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden flex flex-col h-[520px]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">MindDigit Companion</h3>
              <p className="text-[11px] text-emerald-100">Live Strategy & Clues</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message history */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-emerald-600 text-white rounded-br-xs shadow-xs'
                    : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs shadow-xs'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[10px] text-slate-400 mt-1 px-1">{m.timestamp}</span>
            </div>
          ))}
        </div>

        {/* Quick prompt suggestions */}
        <div className="px-3 py-2 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSend(q)}
              className="flex-shrink-0 text-[11px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/60 rounded-full px-2.5 py-1 transition-all cursor-pointer whitespace-nowrap"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-white border-t border-slate-100 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask a question or strategy..."
            className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-xl transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
};
