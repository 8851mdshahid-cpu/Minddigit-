import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  Users,
  Eye,
  EyeOff,
  HelpCircle,
  Timer,
  Check,
  AlertTriangle,
  Coins,
  Radio,
  Vote,
  ShieldCheck,
  Flame,
  MessageSquareQuote,
  Send,
} from 'lucide-react';
import { UserProfile, ImposterPlayer, ImposterItemPair, ImposterGamePhase } from '../types';
import { IMPOSTER_ITEM_PAIRS } from '../data/imposterItems';
import { sound } from '../utils/audio';
import { voiceRecorder } from '../utils/voiceRecorder';

interface GameImposterProps {
  user: UserProfile;
  roomCode?: string;
  initialPlayersCount?: number;
  customPlayers?: Array<{ name: string; username: string; avatar: string }>;
  onBack: () => void;
  onGameEnd: (won: boolean, score: number, coins: number) => void;
}

export const GameImposter: React.FC<GameImposterProps> = ({
  user,
  roomCode,
  initialPlayersCount = 3,
  customPlayers,
  onBack,
  onGameEnd,
}) => {
  const [phase, setPhase] = useState<ImposterGamePhase>('lobby');
  const [itemPair, setItemPair] = useState<ImposterItemPair>(IMPOSTER_ITEM_PAIRS[0]);
  const [showMyItem, setShowMyItem] = useState<boolean>(true);
  
  // 3 to 5 Players in the round
  const [players, setPlayers] = useState<ImposterPlayer[]>([]);
  
  // Speaking & Turn Management
  const [currentTurnIndex, setCurrentTurnIndex] = useState<number>(0);
  const [turnTimer, setTurnTimer] = useState<number>(15);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [audioStreamLevel, setAudioStreamLevel] = useState<number>(0);
  const [customClueInput, setCustomClueInput] = useState<string>('');
  const [hasNotSpokenAlert, setHasNotSpokenAlert] = useState<boolean>(false);
  
  // Active Audio Playback
  const [currentlyPlayingAudioIndex, setCurrentlyPlayingAudioIndex] = useState<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Voting
  const [userVotedId, setUserVotedId] = useState<string | null>(null);
  const [votingTimer, setVotingTimer] = useState<number>(10);
  const [verdictResult, setVerdictResult] = useState<{
    imposterPlayer: ImposterPlayer | null;
    votedOutPlayer: ImposterPlayer | null;
    isTie: boolean;
    userWon: boolean;
    rewardTokens: number;
    rewardScore: number;
  } | null>(null);

  // Initialize a fresh 3-5 player match
  const startNewGame = () => {
    sound.playPop();
    // 1. Pick a random item pair
    const randomPair = IMPOSTER_ITEM_PAIRS[Math.floor(Math.random() * IMPOSTER_ITEM_PAIRS.length)];
    setItemPair(randomPair);

    // AI Names pool
    const defaultAINames = [
      { name: 'Zara Star', username: 'zara_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara' },
      { name: 'Rohan Pro', username: 'rohan_pro', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan' },
      { name: 'Maya Detective', username: 'maya_star', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=maya' },
      { name: 'Lucas Mind', username: 'lucas_d', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=lucas' },
    ];

    const finalOtherPlayers = (customPlayers && customPlayers.length >= 2)
      ? customPlayers
      : defaultAINames.slice(0, Math.max(2, Math.min(4, initialPlayersCount - 1)));

    const totalCount = 1 + finalOtherPlayers.length; // Host + other players (3 to 5)

    // 2. Decide randomly which player is the imposter (0 to totalCount - 1)
    const imposterIdx = Math.floor(Math.random() * totalCount);

    const initPlayers: ImposterPlayer[] = [
      {
        id: 'p-user',
        name: user.name || 'You',
        username: user.username,
        avatar: user.avatar,
        isUser: true,
        item: imposterIdx === 0 ? randomPair.imposterItem : randomPair.majorityItem,
        emoji: imposterIdx === 0 ? randomPair.imposterEmoji : randomPair.majorityEmoji,
        isImposter: imposterIdx === 0,
        hasSpoken: false,
        votesReceived: 0,
        isReady: true,
      },
      ...finalOtherPlayers.map((p, idx) => {
        const playerIndex = idx + 1;
        const isThisImposter = imposterIdx === playerIndex;
        return {
          id: `p-ai-${idx + 1}`,
          name: p.name,
          username: p.username,
          avatar: p.avatar,
          isUser: false,
          item: isThisImposter ? randomPair.imposterItem : randomPair.majorityItem,
          emoji: isThisImposter ? randomPair.imposterEmoji : randomPair.majorityEmoji,
          isImposter: isThisImposter,
          hasSpoken: false,
          votesReceived: 0,
          isReady: true,
        };
      }),
    ];

    setPlayers(initPlayers);
    setShowMyItem(true);
    setCurrentTurnIndex(0);
    setTurnTimer(15);
    setIsRecording(false);
    setCustomClueInput('');
    setHasNotSpokenAlert(false);
    setUserVotedId(null);
    setVotingTimer(10);
    setVerdictResult(null);
    setPhase('reveal_item');
  };

  useEffect(() => {
    startNewGame();
  }, []);

  // 1. Timer for Active Speaking Turn
  useEffect(() => {
    if (phase !== 'turn_speaking') return;
    if (turnTimer <= 0) {
      handleTurnTimerExpiry();
      return;
    }

    const timer = setTimeout(() => {
      setTurnTimer((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [phase, turnTimer, currentTurnIndex, isRecording, players]);

  // Turn Timer Expiry handler
  const handleTurnTimerExpiry = () => {
    const activePlayer = players[currentTurnIndex];
    if (!activePlayer) return;

    if (activePlayer.isUser) {
      if (isRecording) {
        // User was in middle of speaking, finish automatically
        handleStopUserRecording();
      } else if (!activePlayer.hasSpoken) {
        // User did not say anything
        setHasNotSpokenAlert(true);
        sound.playLose();
      }
    } else {
      // AI automatic speaking completion
      handleTriggerAISpeaking(currentTurnIndex);
    }
  };

  // 2. Handle AI Player turn execution
  useEffect(() => {
    if (phase !== 'turn_speaking') return;
    const activePlayer = players[currentTurnIndex];
    if (!activePlayer || activePlayer.isUser || activePlayer.hasSpoken) return;

    // AI takes 2.5s to generate & record its clue
    const aiTimeout = setTimeout(() => {
      handleTriggerAISpeaking(currentTurnIndex);
    }, 2800);

    return () => clearTimeout(aiTimeout);
  }, [phase, currentTurnIndex, players]);

  const handleTriggerAISpeaking = (playerIdx: number) => {
    const p = players[playerIdx];
    if (!p) return;

    // Pick appropriate sample clue based on role
    const pool = p.isImposter ? itemPair.sampleClues.imposter : itemPair.sampleClues.majority;
    const clue = pool[Math.floor(Math.random() * pool.length)];

    // Play text-to-speech voice
    voiceRecorder.speakText(clue, playerIdx === 1 ? 1.05 : 0.95);

    setPlayers((prev) => {
      const next = [...prev];
      next[playerIdx] = {
        ...next[playerIdx],
        hasSpoken: true,
        clueText: clue,
        audioDuration: 3,
      };
      return next;
    });

    advanceToNextPlayer(playerIdx);
  };

  // 3. User Start Voice Recording
  const handleStartUserRecording = async () => {
    sound.playPop();
    setHasNotSpokenAlert(false);
    setIsRecording(true);
    await voiceRecorder.startRecording();
  };

  // 4. User Stop Voice Recording
  const handleStopUserRecording = async () => {
    sound.playClick();
    setIsRecording(false);
    const rec = await voiceRecorder.stopRecording();

    // Default clue text if user spoke or typed
    const clueText = customClueInput.trim() || (itemPair.majorityItem === players[0].item ? 'This is very sour and refreshing.' : 'This is very sweet with a soft peel.');

    setPlayers((prev) => {
      const next = [...prev];
      next[0] = {
        ...next[0],
        hasSpoken: true,
        audioUrl: rec.audioUrl,
        audioDuration: rec.durationSeconds,
        clueText: clueText,
      };
      return next;
    });

    setCustomClueInput('');
    setHasNotSpokenAlert(false);

    // Playback user audio or speak fallback
    if (rec.audioUrl) {
      playAudioClip(rec.audioUrl, 0);
    } else {
      voiceRecorder.speakText(clueText);
    }

    advanceToNextPlayer(0);
  };

  // Fallback / Preset voice submit for User (e.g., "Test, test, test" or custom clue)
  const handleUserSubmitPresetClue = (presetText: string) => {
    sound.playPop();
    setHasNotSpokenAlert(false);
    voiceRecorder.speakText(presetText);

    setPlayers((prev) => {
      const next = [...prev];
      next[0] = {
        ...next[0],
        hasSpoken: true,
        clueText: presetText,
        audioDuration: 2,
      };
      return next;
    });

    advanceToNextPlayer(0);
  };

  // Advance to next player or finish speaking phase
  const advanceToNextPlayer = (completedIdx: number) => {
    if (completedIdx < players.length - 1) {
      setTimeout(() => {
        setCurrentTurnIndex(completedIdx + 1);
        setTurnTimer(15);
        setHasNotSpokenAlert(false);
      }, 1500);
    } else {
      // All players have given clues! Move to Playback Review & Voting
      setTimeout(() => {
        sound.playWin();
        setPhase('playback_review');
      }, 1800);
    }
  };

  // Audio Playback handler
  const playAudioClip = (audioUrl?: string, playerIdx?: number) => {
    sound.playClick();
    if (currentlyPlayingAudioIndex !== null) {
      voiceRecorder.stopSpeaking();
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      setCurrentlyPlayingAudioIndex(null);
      return;
    }

    if (playerIdx !== undefined) {
      setCurrentlyPlayingAudioIndex(playerIdx);
      const targetPlayer = players[playerIdx];

      if (audioUrl) {
        if (!audioPlayerRef.current) {
          audioPlayerRef.current = new Audio(audioUrl);
        } else {
          audioPlayerRef.current.src = audioUrl;
        }
        audioPlayerRef.current.onended = () => {
          setCurrentlyPlayingAudioIndex(null);
        };
        audioPlayerRef.current.play().catch(() => {
          if (targetPlayer?.clueText) {
            voiceRecorder.speakText(targetPlayer.clueText, 1, () => setCurrentlyPlayingAudioIndex(null));
          }
        });
      } else if (targetPlayer?.clueText) {
        voiceRecorder.speakText(targetPlayer.clueText, playerIdx === 1 ? 1.05 : 0.95, () => {
          setCurrentlyPlayingAudioIndex(null);
        });
      }
    }
  };

  // 5. Voting Phase Timer
  useEffect(() => {
    if (phase !== 'voting') return;
    if (votingTimer <= 0) {
      handleExecuteFinalTally();
      return;
    }

    const timer = setTimeout(() => {
      setVotingTimer((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [phase, votingTimer, userVotedId, players]);

  // User Casts Vote
  const handleUserVote = (targetPlayerId: string) => {
    if (userVotedId !== null) return;
    sound.playPop();
    setUserVotedId(targetPlayerId);

    // Other players cast votes
    const imposterP = players.find((p) => p.isImposter);
    
    // Map of votes cast by each player
    const playerVotesMap: Record<string, string> = {
      'p-user': targetPlayerId,
    };

    players.forEach((p) => {
      if (p.isUser) return;
      const validVoteOptions = players.filter((other) => other.id !== p.id);
      const isImposterTarget = imposterP && imposterP.id !== p.id && Math.random() > 0.35;
      const chosenVote = isImposterTarget && imposterP
        ? imposterP.id
        : validVoteOptions[Math.floor(Math.random() * validVoteOptions.length)].id;
      playerVotesMap[p.id] = chosenVote;
    });

    setPlayers((prev) =>
      prev.map((p) => {
        let votes = 0;
        Object.values(playerVotesMap).forEach((targetId) => {
          if (targetId === p.id) votes += 1;
        });
        return {
          ...p,
          votesReceived: votes,
          votedForId: playerVotesMap[p.id],
        };
      })
    );
  };

  // 6. Calculate Final Verdict & Rewards
  const handleExecuteFinalTally = () => {
    const imposter = players.find((p) => p.isImposter) || players[0];
    
    // Find player with highest votes
    const sorted = [...players].sort((a, b) => b.votesReceived - a.votesReceived);
    const maxVotes = sorted[0].votesReceived;
    const topVoted = sorted.filter((p) => p.votesReceived === maxVotes);

    const isTie = topVoted.length > 1;
    const votedOut = isTie ? null : topVoted[0];

    // Did user win?
    let userWon = false;
    let tokensEarned = 10;
    let scoreEarned = 100;

    if (players[0].isImposter) {
      // User was Imposter! Won if not voted out
      if (votedOut?.id !== 'p-user') {
        userWon = true;
        tokensEarned = 50;
        scoreEarned = 400;
        sound.playWin();
        confetti({ particleCount: 160, spread: 80, origin: { y: 0.6 } });
      } else {
        sound.playLose();
      }
    } else {
      // User was Innocent! Won if Imposter was voted out
      if (votedOut?.id === imposter.id) {
        userWon = true;
        tokensEarned = 35;
        scoreEarned = 250;
        sound.playWin();
        confetti({ particleCount: 160, spread: 80, origin: { y: 0.6 } });
      } else {
        sound.playLose();
      }
    }

    setVerdictResult({
      imposterPlayer: imposter,
      votedOutPlayer: votedOut,
      isTie,
      userWon,
      rewardTokens: tokensEarned,
      rewardScore: scoreEarned,
    });

    setPhase('verdict');
    onGameEnd(userWon, scoreEarned, tokensEarned);
  };

  return (
    <div className="w-full max-w-xl mx-auto p-3 sm:p-5 select-none font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* TOP HEADER STRIP */}
      <div className="flex items-center justify-between bg-white/80 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white shadow-xs mb-2.5">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            onBack();
          }}
          className="p-1.5 rounded-xl text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-1.5 px-3 py-1 bg-purple-50 border border-purple-200 rounded-full">
          <Radio className="w-3.5 h-3.5 text-purple-600 animate-pulse" />
          <span className="text-xs font-black text-purple-900">
            Against The Imposter {roomCode ? `• #${roomCode}` : ''}
          </span>
        </div>

        <div className="flex items-center gap-1 text-xs font-extrabold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
          <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
          <span>{user.coins} 🪙</span>
        </div>
      </div>

      {/* PERSISTENT FLOATING / PINNED SECRET ITEM & WORD BADGE */}
      {players[0] && phase !== 'reveal_item' && (
        <div className="w-full bg-gradient-to-r from-purple-950 via-[#200e42] to-slate-900 text-white rounded-2xl p-3 border-2 border-purple-400/50 shadow-md mb-3 flex items-center justify-between animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-purple-800/70 border border-purple-300/40 flex items-center justify-center text-2xl shadow-inner shrink-0">
              {showMyItem ? players[0].emoji : '🔒'}
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black uppercase tracking-wider text-purple-300">
                  YOUR SECRET WORD / ITEM:
                </span>
                <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                  players[0].isImposter ? 'bg-rose-500 text-white' : 'bg-emerald-500 text-white'
                }`}>
                  {players[0].isImposter ? '🕵️ IMPOSTER' : '🛡️ INNOCENT'}
                </span>
              </div>
              
              {showMyItem ? (
                <div className="text-sm sm:text-base font-black text-amber-300 font-mono tracking-tight flex items-center gap-2">
                  <span>{players[0].item}</span>
                  <span className="text-[10px] font-normal text-purple-200/80">({itemPair.category})</span>
                </div>
              ) : (
                <div className="text-xs font-mono font-bold text-slate-400">
                  •••••• (Hidden)
                </div>
              )}
            </div>
          </div>

          {/* Toggle Privacy Button */}
          <button
            type="button"
            onClick={() => {
              sound.playClick();
              setShowMyItem(!showMyItem);
            }}
            className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 cursor-pointer transition-colors flex items-center gap-1 text-xs font-bold shrink-0 border border-white/10"
            title={showMyItem ? "Hide secret word" : "Show secret word"}
          >
            {showMyItem ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span className="text-[11px]">{showMyItem ? 'Hide' : 'Peek'}</span>
          </button>
        </div>
      )}

      {/* STAGE 1: REVEAL SECRET ITEM CARD */}
      {phase === 'reveal_item' && (
        <div className="bg-white/85 backdrop-blur-md rounded-[36px] p-6 sm:p-8 border border-white shadow-xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 rounded-full text-xs font-black text-amber-800 mb-3">
            <span>🎭 {players.length} Players • {players.length - 1} Same Items • 1 Imposter</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mb-1">
            Your Secret Item Assigned
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mb-5 font-medium">
            Keep your card private! When it is your turn, use your mic to say a short clue without revealing the exact name.
          </p>

          {/* Secret Item Card with Privacy Toggle */}
          <div className="relative w-full max-w-xs bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 rounded-3xl p-6 text-white shadow-2xl border border-purple-500/30 flex flex-col items-center gap-3 mb-6">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setShowMyItem(!showMyItem);
              }}
              className="absolute top-3 right-3 p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-200 cursor-pointer transition-colors"
              title="Hide or show your item"
            >
              {showMyItem ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>

            <span className="text-[11px] font-black uppercase tracking-widest text-purple-300">
              Category: {itemPair.category}
            </span>

            {showMyItem ? (
              <div className="flex flex-col items-center py-2 animate-in zoom-in duration-150">
                <span className="text-6xl mb-2 drop-shadow-md">{players[0]?.emoji}</span>
                <span className="text-2xl font-black tracking-tight text-amber-300 font-mono">
                  {players[0]?.item}
                </span>
                <span className="text-[11px] text-slate-300 mt-1 font-medium">
                  {players[0]?.isImposter ? '🕵️ You are the IMPOSTER! Blend in!' : '🛡️ You are INNOCENT! Find the odd clue!'}
                </span>
              </div>
            ) : (
              <div className="flex flex-col items-center py-6">
                <span className="text-3xl font-black text-slate-400">🔒 HIDDEN</span>
                <span className="text-xs text-slate-400 mt-1">Tap the eye icon to view</span>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playPop();
              setPhase('turn_speaking');
              setCurrentTurnIndex(0);
              setTurnTimer(15);
            }}
            className="w-full max-w-xs py-4 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-2xl shadow-lg shadow-purple-600/25 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer text-base"
          >
            <Radio className="w-5 h-5" />
            <span>Ready! Start Voice Turns</span>
          </button>
        </div>
      )}

      {/* STAGE 2: TURN-BY-TURN VOICE SPEAKING */}
      {phase === 'turn_speaking' && (
        <div className="flex flex-col gap-3">
          
          {/* Players HUD with Speaking Indicator */}
          <div className={`grid gap-2 ${players.length === 3 ? 'grid-cols-3' : players.length === 4 ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-3 sm:grid-cols-5'}`}>
            {players.map((p, idx) => {
              const isCurrentTurn = currentTurnIndex === idx;
              return (
                <div
                  key={p.id}
                  className={`p-2.5 sm:p-3 rounded-2xl border transition-all duration-300 flex flex-col items-center text-center relative ${
                    isCurrentTurn
                      ? 'bg-purple-50/95 border-purple-500 shadow-md ring-2 ring-purple-400/40'
                      : p.hasSpoken
                      ? 'bg-white/90 border-emerald-300 shadow-xs'
                      : 'bg-white/70 border-white opacity-85'
                  }`}
                >
                  {isCurrentTurn && (
                    <span className="absolute -top-2 bg-purple-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-2xs animate-pulse">
                      SPEAKING
                    </span>
                  )}

                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-slate-900 text-amber-300 font-serif font-black text-xs sm:text-sm flex items-center justify-center mb-1 border border-white">
                    {p.name.charAt(0).toUpperCase()}
                  </div>

                  <span className="text-[11px] sm:text-xs font-black text-slate-900 truncate w-full">{p.name}</span>
                  <span className="text-[9px] font-mono text-slate-500 truncate w-full">@{p.username}</span>

                  <div className="mt-1.5 w-full">
                    {p.hasSpoken ? (
                      <span className="inline-flex items-center gap-0.5 text-[9px] sm:text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-200">
                        <Check className="w-3 h-3 stroke-[3]" /> Done
                      </span>
                    ) : isCurrentTurn ? (
                      <span className="text-[9px] sm:text-[10px] font-black text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded-full">
                        {turnTimer}s left
                      </span>
                    ) : (
                      <span className="text-[9px] sm:text-[10px] font-bold text-slate-400">Waiting...</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* ACTIVE TURN MAIN PROMPT BOX */}
          <div className="bg-white/85 backdrop-blur-md rounded-3xl p-5 border border-white shadow-md flex flex-col items-center text-center">
            
            <div className="flex items-center justify-between w-full mb-3">
              <span className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                Turn {currentTurnIndex + 1} of {players.length}
              </span>
              <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full font-black text-xs ${
                turnTimer <= 4 ? 'bg-rose-500 text-white animate-pulse' : 'bg-amber-100 text-amber-900'
              }`}>
                <Timer className="w-3.5 h-3.5" />
                <span>{turnTimer}s</span>
              </div>
            </div>

            {/* IF IT IS USER'S TURN (Player 0) */}
            {currentTurnIndex === 0 && (
              <div className="w-full flex flex-col items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shadow-xs">
                  <Mic className="w-6 h-6 animate-pulse" />
                </div>

                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    It&apos;s Your Turn to Speak!
                  </h3>
                  <p className="text-xs text-slate-500 max-w-sm mt-0.5">
                    Describe your item ({showMyItem ? players[0]?.item : '***'}) with a clever clue.
                    <br />
                    <em>Example: &ldquo;This is very sour and great in drinks.&rdquo;</em>
                  </p>
                </div>

                {/* Did not speak alert banner */}
                {hasNotSpokenAlert && (
                  <div className="w-full p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex flex-col gap-2 animate-in shake duration-200">
                    <div className="flex items-center justify-center gap-1.5">
                      <AlertTriangle className="w-4 h-4" />
                      <span>You haven&apos;t spoken yet! Please speak or tap a clue below:</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 justify-center">
                      <button
                        type="button"
                        onClick={() => handleUserSubmitPresetClue("Test, test, test, test. My item is ready!")}
                        className="px-3 py-1 bg-white hover:bg-rose-100 border border-rose-300 rounded-xl text-xs font-black text-rose-800 cursor-pointer shadow-2xs"
                      >
                        🔊 &ldquo;Test, test, test...&rdquo;
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUserSubmitPresetClue("This is very sour and juicy.")}
                        className="px-3 py-1 bg-rose-600 text-white rounded-xl text-xs font-black hover:bg-rose-700 cursor-pointer shadow-2xs"
                      >
                        🍋 &ldquo;This is very sour.&rdquo;
                      </button>
                    </div>
                  </div>
                )}

                {/* Microphone Recording Action Button */}
                <div className="flex flex-col items-center gap-2 my-2">
                  {!isRecording ? (
                    <button
                      type="button"
                      onClick={handleStartUserRecording}
                      className="py-4 px-8 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-purple-500/25 active:scale-95 transition-all flex items-center gap-3 cursor-pointer text-base"
                    >
                      <Mic className="w-5 h-5" />
                      <span>CLICK TO RECORD CLUE</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleStopUserRecording}
                      className="py-4 px-8 bg-rose-600 hover:bg-rose-700 text-white font-black rounded-2xl shadow-xl shadow-rose-600/30 active:scale-95 transition-all flex items-center gap-3 cursor-pointer text-base animate-pulse"
                    >
                      <span className="w-3.5 h-3.5 rounded-full bg-white animate-ping" />
                      <span>STOP & BROADCAST CLUE (⏹️)</span>
                    </button>
                  )}
                  <span className="text-[11px] font-bold text-slate-400">
                    {isRecording ? '🎙️ Recording your voice... Click Stop when finished' : 'Tap above to record your live voice'}
                  </span>
                </div>

                {/* Quick text / preset speech clue option */}
                <div className="w-full flex items-center gap-2 mt-1">
                  <input
                    type="text"
                    placeholder="Or type clue (e.g. This is very sour...)"
                    value={customClueInput}
                    onChange={(e) => setCustomClueInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && customClueInput.trim()) {
                        handleUserSubmitPresetClue(customClueInput.trim());
                      }
                    }}
                    className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <button
                    type="button"
                    disabled={!customClueInput.trim()}
                    onClick={() => handleUserSubmitPresetClue(customClueInput.trim())}
                    className="p-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white rounded-2xl transition-all cursor-pointer"
                    title="Speak Typed Clue"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>

              </div>
            )}

            {/* IF IT IS AI PLAYER'S TURN */}
            {currentTurnIndex > 0 && (
              <div className="flex flex-col items-center gap-3 py-4">
                <div className="w-12 h-12 rounded-full border-4 border-purple-500 border-t-transparent animate-spin flex items-center justify-center">
                  <Volume2 className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {players[currentTurnIndex]?.name} is recording their voice clue...
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Audio will stream for everyone once they finish speaking.
                  </p>
                </div>
              </div>
            )}

          </div>

          {/* Spoken Clues Feed Log */}
          {players.some((p) => p.hasSpoken) && (
            <div className="bg-white/70 backdrop-blur-xs rounded-2xl p-3.5 border border-white shadow-2xs flex flex-col gap-2">
              <span className="text-[10px] font-extrabold uppercase text-slate-400 text-left">
                Recorded Voice Clues Stream
              </span>
              <div className="flex flex-col gap-1.5">
                {players
                  .filter((p) => p.hasSpoken)
                  .map((p, idx) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between p-2.5 bg-slate-50/90 rounded-xl border border-slate-200/80 text-xs"
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        <span className="font-extrabold text-slate-900">{p.name}:</span>
                        <span className="text-slate-600 font-medium italic truncate max-w-[220px]">
                          &ldquo;{p.clueText}&rdquo;
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => playAudioClip(p.audioUrl, players.indexOf(p))}
                        className="flex items-center gap-1 px-2.5 py-1 bg-purple-100 hover:bg-purple-200 text-purple-800 font-bold rounded-lg text-[11px] cursor-pointer transition-colors shadow-2xs"
                      >
                        {currentlyPlayingAudioIndex === players.indexOf(p) ? (
                          <>
                            <Pause className="w-3 h-3" />
                            <span>Playing</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3 h-3 fill-current" />
                            <span>Listen</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* STAGE 3: PLAYBACK & LISTEN TO ALL RECORDINGS */}
      {phase === 'playback_review' && (
        <div className="bg-white/85 backdrop-blur-md rounded-[36px] p-6 sm:p-8 border border-white shadow-xl flex flex-col items-center text-center animate-in zoom-in-95 duration-200">
          
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-2 shadow-xs">
            <Volume2 className="w-6 h-6" />
          </div>

          <h2 className="text-2xl font-black text-slate-900 mb-1">
            All {players.length} Audio Clues Recorded!
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mb-5">
            Listen to each player&apos;s audio clip. {players.length - 1} players have the same secret item, but ONE player is the Imposter!
          </p>

          {/* 3 Voice Clue Cards with Audio Playback */}
          <div className="w-full flex flex-col gap-2.5 mb-6">
            {players.map((p, idx) => (
              <div
                key={p.id}
                className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-left shadow-2xs hover:border-purple-300 transition-all"
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-9 h-9 rounded-full bg-slate-900 text-amber-300 font-black text-xs flex items-center justify-center shrink-0">
                    {p.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-xs font-black text-slate-900">{p.name} {p.isUser && '(You)'}</div>
                    <div className="text-xs text-slate-600 font-medium italic truncate max-w-[200px] sm:max-w-xs">
                      &ldquo;{p.clueText}&rdquo;
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => playAudioClip(p.audioUrl, idx)}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs ${
                    currentlyPlayingAudioIndex === idx
                      ? 'bg-purple-600 text-white'
                      : 'bg-white text-purple-700 border border-purple-200 hover:bg-purple-50'
                  }`}
                >
                  {currentlyPlayingAudioIndex === idx ? (
                    <>
                      <Pause className="w-3.5 h-3.5" />
                      <span>Playing</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Play Audio</span>
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playPop();
              setPhase('voting');
              setVotingTimer(10);
            }}
            className="w-full max-w-xs py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black rounded-2xl shadow-xl shadow-purple-600/25 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer text-base"
          >
            <Vote className="w-5 h-5" />
            <span>Proceed to Vote Imposter</span>
          </button>
        </div>
      )}

      {/* STAGE 4: VOTING PHASE */}
      {phase === 'voting' && (
        <div className="bg-white/85 backdrop-blur-md rounded-[36px] p-6 sm:p-8 border border-white shadow-xl flex flex-col items-center text-center animate-in zoom-in-95 duration-200">
          
          <div className="flex items-center justify-between w-full mb-3">
            <span className="text-xs font-black uppercase tracking-wider text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200">
              Voting Room
            </span>
            <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-amber-100 text-amber-900 font-black text-xs">
              <Timer className="w-3.5 h-3.5" />
              <span>{votingTimer}s</span>
            </div>
          </div>

          <h2 className="text-2xl font-black text-slate-900 mb-1">
            Who is the Imposter?
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mb-5">
            Vote for the player whose clue seemed suspicious or did not match the majority item!
          </p>

          {/* Vote Options */}
          <div className="w-full flex flex-col gap-2.5 mb-6">
            {players.map((p) => {
              const isSelected = userVotedId === p.id;
              const isSelf = p.isUser;
              return (
                <button
                  key={p.id}
                  type="button"
                  disabled={isSelf || userVotedId !== null}
                  onClick={() => handleUserVote(p.id)}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-purple-600 text-white border-purple-600 shadow-md ring-2 ring-purple-400'
                      : isSelf
                      ? 'bg-slate-100 border-slate-200 opacity-60 cursor-not-allowed text-slate-500'
                      : 'bg-slate-50 border-slate-200 hover:bg-purple-50 hover:border-purple-300 text-slate-800 shadow-2xs'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-900 text-amber-300 font-black text-sm flex items-center justify-center">
                      {p.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-black">{p.name} {isSelf && '(You)'}</div>
                      <div className="text-xs opacity-75 italic">&ldquo;{p.clueText}&rdquo;</div>
                    </div>
                  </div>

                  {isSelected && (
                    <span className="text-xs font-black bg-white/20 px-3 py-1 rounded-full">
                      ✓ VOTED
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {userVotedId !== null ? (
            <div className="flex flex-col items-center gap-2">
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                ✓ Your vote has been recorded! Tallying final results in {votingTimer}s...
              </span>
            </div>
          ) : (
            <span className="text-xs font-bold text-slate-400">
              Tap any suspect player above to cast your vote!
            </span>
          )}

        </div>
      )}

      {/* STAGE 5: FINAL VERDICT & REVEAL */}
      {phase === 'verdict' && verdictResult && (
        <div className="bg-white rounded-[36px] p-6 sm:p-8 border border-white shadow-2xl flex flex-col items-center text-center animate-in zoom-in-95 duration-200">
          
          <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center text-3xl shadow-sm bg-slate-50">
            {verdictResult.userWon ? '🏆' : '💔'}
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mb-1">
            {verdictResult.userWon ? 'VICTORY! YOU WON!' : 'ROUND OVER'}
          </h2>
          <p className="text-xs text-slate-500 mb-5">
            {verdictResult.imposterPlayer?.isUser
              ? 'You were the Imposter!'
              : `The Imposter was ${verdictResult.imposterPlayer?.name}!`}
          </p>

          {/* Full Item & Role Reveal Grid */}
          <div className="w-full bg-slate-50 rounded-2xl p-4 border border-slate-200 mb-5 flex flex-col gap-2.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 text-left">
              Item Reveal & Voting Summary
            </span>

            {players.map((p) => (
              <div
                key={p.id}
                className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                  p.isImposter
                    ? 'bg-rose-50 border-rose-200 text-rose-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{p.emoji}</span>
                  <div className="text-left">
                    <div className="font-black">{p.name} {p.isUser && '(You)'}</div>
                    <div className="text-[10px] opacity-75 font-mono">Item: {p.item}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-right">
                  <span className="font-bold text-[10px] bg-white/70 px-2 py-0.5 rounded-full">
                    {p.votesReceived} Votes
                  </span>
                  <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                    p.isImposter ? 'bg-rose-600 text-white' : 'bg-emerald-600 text-white'
                  }`}>
                    {p.isImposter ? 'IMPOSTER' : 'INNOCENT'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Reward pill */}
          <div className="w-full bg-amber-50 border border-amber-200 rounded-2xl p-3 mb-5 flex items-center justify-center gap-2 text-amber-900 font-black text-sm">
            <Coins className="w-5 h-5 text-amber-500 fill-amber-400" />
            <span>Reward: +{verdictResult.rewardTokens} Tokens Added!</span>
          </div>

          {/* Actions */}
          <div className="flex gap-2.5 w-full max-w-xs">
            <button
              type="button"
              onClick={startNewGame}
              className="flex-1 py-3.5 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-2xl shadow-lg shadow-purple-600/25 cursor-pointer text-sm"
            >
              Play Again
            </button>
            <button
              type="button"
              onClick={onBack}
              className="flex-1 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-2xl cursor-pointer text-sm"
            >
              Home
            </button>
          </div>

        </div>
      )}

    </div>
  );
};
