import React, { useState, useEffect, useRef } from 'react';
import { Scissors, Copy, ClipboardPaste, XCircle, Palette, Check, Sparkles, X } from 'lucide-react';
import { sound } from '../utils/audio';

interface SelectionToolbarProps {
  onOpenFrameCustomizer: () => void;
}

export const SelectionToolbar: React.FC<SelectionToolbarProps> = ({ onOpenFrameCustomizer }) => {
  const [selectedText, setSelectedText] = useState<string>('');
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [copiedToast, setCopiedToast] = useState<string | null>(null);
  const toolbarRef = useRef<HTMLDivElement>(null);

  // Monitor text selections across the screen
  useEffect(() => {
    const handleSelectionChange = () => {
      const selection = window.getSelection();
      const activeEl = document.activeElement as HTMLInputElement | HTMLTextAreaElement | null;

      let text = '';
      let rect: DOMRect | null = null;

      // 1. Check standard window text selection
      if (selection && selection.toString().trim().length > 0) {
        text = selection.toString().trim();
        if (selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          rect = range.getBoundingClientRect();
        }
      } 
      // 2. Check input/textarea selection
      else if (
        activeEl &&
        (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') &&
        typeof activeEl.selectionStart === 'number' &&
        typeof activeEl.selectionEnd === 'number' &&
        activeEl.selectionStart !== activeEl.selectionEnd
      ) {
        text = activeEl.value.substring(activeEl.selectionStart, activeEl.selectionEnd).trim();
        rect = activeEl.getBoundingClientRect();
      }

      if (text) {
        setSelectedText(text);
        if (rect) {
          const x = Math.max(16, Math.min(window.innerWidth - 320, rect.left + rect.width / 2 - 140));
          const y = Math.max(16, rect.top - 54);
          setPosition({ x, y });
        } else {
          setPosition({ x: window.innerWidth / 2 - 140, y: window.innerHeight - 100 });
        }
        setIsVisible(true);
      } else {
        // Only hide if we don't have an active toast
        if (!copiedToast) {
          setIsVisible(false);
        }
      }
    };

    document.addEventListener('selectionchange', handleSelectionChange);
    document.addEventListener('mouseup', handleSelectionChange);
    document.addEventListener('touchend', handleSelectionChange);

    return () => {
      document.removeEventListener('selectionchange', handleSelectionChange);
      document.removeEventListener('mouseup', handleSelectionChange);
      document.removeEventListener('touchend', handleSelectionChange);
    };
  }, [copiedToast]);

  // Action: Cut (कट)
  const handleCut = async () => {
    try {
      sound.playPop();
      if (selectedText) {
        await navigator.clipboard.writeText(selectedText);
      }
      
      // Delete text from input if focused
      const activeEl = document.activeElement as HTMLInputElement | HTMLTextAreaElement | null;
      if (
        activeEl &&
        (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') &&
        typeof activeEl.selectionStart === 'number' &&
        typeof activeEl.selectionEnd === 'number'
      ) {
        const start = activeEl.selectionStart;
        const end = activeEl.selectionEnd;
        const val = activeEl.value;
        activeEl.value = val.substring(0, start) + val.substring(end);
        activeEl.setSelectionRange(start, start);
        activeEl.dispatchEvent(new Event('input', { bubbles: true }));
      }

      // Clear selection
      window.getSelection()?.removeAllRanges();
      showToast('✂️ Cut to clipboard (कट किया गया)');
    } catch (e) {
      showToast('✂️ Cut attempted');
    }
  };

  // Action: Copy (कॉपी)
  const handleCopy = async () => {
    try {
      sound.playPop();
      if (selectedText) {
        await navigator.clipboard.writeText(selectedText);
      }
      showToast('📋 Copied (कॉपी हो गया)');
    } catch (e) {
      showToast('📋 Copied');
    }
  };

  // Action: Paste (पेस्ट)
  const handlePaste = async () => {
    try {
      sound.playPop();
      const clipText = await navigator.clipboard.readText();
      const activeEl = document.activeElement as HTMLInputElement | HTMLTextAreaElement | null;

      if (
        activeEl &&
        (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA') &&
        typeof activeEl.selectionStart === 'number'
      ) {
        const start = activeEl.selectionStart;
        const end = activeEl.selectionEnd || start;
        const val = activeEl.value;
        activeEl.value = val.substring(0, start) + clipText + val.substring(end);
        activeEl.setSelectionRange(start + clipText.length, start + clipText.length);
        activeEl.dispatchEvent(new Event('input', { bubbles: true }));
        showToast('📥 Pasted text (पेस्ट किया गया)');
      } else {
        showToast('📥 Clipboard: ' + clipText.substring(0, 15) + '...');
      }
    } catch (e) {
      showToast('📥 Paste permission required');
    }
  };

  // Action: Deselect / Remove Selection (हटाएं / क्लियर)
  const handleDeselect = () => {
    sound.playClick();
    window.getSelection()?.removeAllRanges();
    const activeEl = document.activeElement as HTMLElement | null;
    if (activeEl && typeof activeEl.blur === 'function') {
      activeEl.blur();
    }
    setSelectedText('');
    setIsVisible(false);
    showToast('❌ Selection Cleared (सेलेक्शन हटाया गया)');
  };

  // Action: Open Frame Customizer (चेंज फ्रेम)
  const handleChangeFrame = () => {
    sound.playPop();
    handleDeselect();
    onOpenFrameCustomizer();
  };

  const showToast = (msg: string) => {
    setCopiedToast(msg);
    setTimeout(() => {
      setCopiedToast(null);
      setIsVisible(false);
    }, 1800);
  };

  if (!isVisible && !copiedToast) return null;

  return (
    <div
      ref={toolbarRef}
      style={{
        position: 'fixed',
        left: position ? `${position.x}px` : '50%',
        top: position ? `${position.y}px` : 'auto',
        bottom: !position ? '80px' : 'auto',
        transform: !position ? 'translateX(-50%)' : undefined,
        zIndex: 9999,
      }}
      className="animate-in fade-in zoom-in-95 duration-150 select-none shadow-2xl"
    >
      {/* Toast Notification */}
      {copiedToast ? (
        <div className="px-3.5 py-2 bg-slate-900 text-amber-300 font-bold text-xs rounded-xl shadow-lg border border-slate-700 flex items-center gap-1.5 backdrop-blur-md animate-in fade-in">
          <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" />
          <span>{copiedToast}</span>
        </div>
      ) : (
        /* Floating Action Toolbar */
        <div className="bg-slate-900/95 backdrop-blur-md text-white px-2 py-1.5 rounded-2xl border border-slate-700 shadow-2xl flex items-center gap-1">
          
          {/* 1. Cut (कट) */}
          <button
            type="button"
            onClick={handleCut}
            className="px-2.5 py-1.5 rounded-xl hover:bg-slate-800 active:bg-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer text-slate-200 hover:text-white"
            title="Cut (कट)"
          >
            <Scissors className="w-3.5 h-3.5 text-rose-400" />
            <span>कट</span>
          </button>

          <div className="w-px h-4 bg-slate-700 mx-0.5" />

          {/* 2. Copy (कॉपी) */}
          <button
            type="button"
            onClick={handleCopy}
            className="px-2.5 py-1.5 rounded-xl hover:bg-slate-800 active:bg-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer text-slate-200 hover:text-white"
            title="Copy (कॉपी)"
          >
            <Copy className="w-3.5 h-3.5 text-cyan-400" />
            <span>कॉपी</span>
          </button>

          <div className="w-px h-4 bg-slate-700 mx-0.5" />

          {/* 3. Paste (पेस्ट) */}
          <button
            type="button"
            onClick={handlePaste}
            className="px-2.5 py-1.5 rounded-xl hover:bg-slate-800 active:bg-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer text-slate-200 hover:text-white"
            title="Paste (पेस्ट)"
          >
            <ClipboardPaste className="w-3.5 h-3.5 text-emerald-400" />
            <span>पेस्ट</span>
          </button>

          <div className="w-px h-4 bg-slate-700 mx-0.5" />

          {/* 4. Remove / Deselect (हटाएं) */}
          <button
            type="button"
            onClick={handleDeselect}
            className="px-2.5 py-1.5 rounded-xl hover:bg-slate-800 active:bg-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer text-amber-300 hover:text-amber-200"
            title="Deselect / Remove (हटाएं)"
          >
            <XCircle className="w-3.5 h-3.5 text-amber-400" />
            <span>हटाएं</span>
          </button>

          <div className="w-px h-4 bg-slate-700 mx-0.5" />

          {/* 5. Change Frame (चेंज फ्रेम) */}
          <button
            type="button"
            onClick={handleChangeFrame}
            className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 to-orange-500/20 border border-amber-500/30 hover:bg-amber-500/30 active:scale-95 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer text-amber-300"
            title="Change Avatar Frame (चेंज फ्रेम)"
          >
            <Palette className="w-3.5 h-3.5 text-amber-400" />
            <span>चेंज फ्रेम</span>
          </button>

          {/* Close toolbar button */}
          <button
            type="button"
            onClick={() => setIsVisible(false)}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 ml-0.5"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>

        </div>
      )}
    </div>
  );
};
