import React, { useEffect, useState } from 'react';
import { MinddigitLogo } from './MinddigitLogo';
import { MinddigitEmblem } from './MinddigitEmblem';

interface LoadingScreenProps {
  onComplete: () => void;
  durationMs?: number;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete, durationMs = 450 }) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const stepTime = 40;
    const increment = 100 / (durationMs / stepTime);

    const interval = setInterval(() => {
      setProgress((prev) => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 60);
          return 100;
        }
        return next;
      });
    }, stepTime);

    return () => clearInterval(interval);
  }, [durationMs, onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#F1F5F9] select-none font-['Plus_Jakarta_Sans',sans-serif]">
      <div className="flex flex-col items-center max-w-xs w-full px-6 text-center">
        
        {/* Geometric Emblem Anchor */}
        <div className="relative mb-6">
          <div className="w-20 h-20 bg-blue-100 rounded-3xl flex items-center justify-center shadow-lg shadow-blue-500/10">
            <div className="w-10 h-10 bg-blue-600 rounded-xl transform rotate-45 flex items-center justify-center shadow-md animate-pulse">
              <span className="text-white font-bold -rotate-45 text-sm">MD</span>
            </div>
          </div>
        </div>

        {/* Title */}
        <h2 className="text-xl font-bold text-slate-900 mb-4 tracking-tight">
          Mind<span className="text-blue-600">Digit</span>
        </h2>

        {/* Geometric Progress Bar */}
        <div className="w-full bg-slate-200/80 rounded-full h-2.5 p-0.5 overflow-hidden shadow-inner mb-3">
          <div
            className="bg-blue-600 h-full rounded-full transition-all duration-75 ease-out shadow-sm"
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        {/* Status text */}
        <div className="flex items-center justify-between w-full text-xs font-semibold text-slate-400">
          <span className="animate-pulse">Loading arena...</span>
          <span className="font-mono text-blue-600 font-bold">{Math.round(progress)}%</span>
        </div>

      </div>
    </div>
  );
};
