import React, { useState, useEffect } from 'react';
import {
  X,
  Bot,
  KeyRound,
  Sparkles,
  AlertCircle,
  Coins,
  ShieldAlert,
  UserPlus,
  Play,
  Check,
  Copy,
  Clipboard,
  ArrowLeft,
  Tv,
  HelpCircle,
  UserX,
} from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../utils/audio';
import { registerNewRoom, findRoomByCode, findRoomAsync, getActiveRooms } from '../utils/rooms';
import { getFriends, Friend, sendFriendRequest, getRemovedFriends } from '../utils/friends';

interface ImposterRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onStartImposterGame: (
    roomCode?: string,
    initialPlayersCount?: number,
    customPlayers?: Array<{ name: string; username: string; avatar: string }>,
    isHostCreated?: boolean
  ) => void;
  onOpenAdModal: () => void;
}

export const ImposterRoomModal: React.FC<ImposterRoomModalProps> = ({
  isOpen,
  onClose,
  user,
  onStartImposterGame,
  onOpenAdModal,
}) => {
  const [view, setView] = useState<'select' | 'enter_code' | 'lobby'>('select');
  const [roomCodeInput, setRoomCodeInput] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [isHost, setIsHost] = useState(false);
  const [isSearchingRoom, setIsSearchingRoom] = useState(false);
  const [bannedUsernames, setBannedUsernames] = useState<string[]>([]);

  // Active imposter rooms on platform for quick discovery
  const [activeImposterRooms, setActiveImposterRooms] = useState<Array<{ code: string; hostName: string }>>([]);
  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [inviteFriendStatus, setInviteFriendStatus] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      const all = getActiveRooms();
      const imp = all.filter((r) => r.gameType === 'imposter' || r.code.startsWith('IMP-'));
      setActiveImposterRooms(imp);
      setFriendsList(getFriends(user.id));
      setBannedUsernames([]);
      setErrorMessage('');
      setRoomCodeInput('');
      setInviteFriendStatus('');
      setView('select');
    }
  }, [isOpen, user.id]);

  // Players in lobby
  const [lobbyPlayers, setLobbyPlayers] = useState<Array<{
    id: string;
    name: string;
    username: string;
    avatar: string;
    isHost: boolean;
  }>>([]);

  if (!isOpen) return null;

  // 1. Handle Play with 2 Computers (You + Computer 1 + Computer 2)
  const handlePlayWithComputers = () => {
    sound.playWin();
    const computerPlayers = [
      {
        name: 'Computer 1',
        username: 'computer_1',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=computer1',
      },
      {
        name: 'Computer 2',
        username: 'computer_2',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=computer2',
      },
    ];
    onStartImposterGame(undefined, 3, computerPlayers, false);
    onClose();
  };

  // 2. Handle Create Imposter Room (Deducts 20 tokens)
  const handleCreateRoom = () => {
    if (user.coins < 20) {
      sound.playLose();
      setErrorMessage('You need at least 20 Tokens (🪙 20) to create a custom Imposter room.');
      return;
    }

    sound.playWin();
    const created = registerNewRoom(user.name, user.username, 'normal', undefined, 'imposter');
    setRoomCode(created.code);
    setIsHost(true);
    setLobbyPlayers([
      {
        id: 'host',
        name: user.name || 'You',
        username: user.username,
        avatar: user.avatar,
        isHost: true,
      },
    ]);
    setView('lobby');
    setErrorMessage('');
  };

  // 3. Handle Enter Friend's Room Code (100% Free - 0 tokens, queries Firestore + Local)
  const handleJoinByCode = async (targetCode?: string) => {
    setErrorMessage('');
    const raw = (targetCode || roomCodeInput).trim();
    if (!raw) {
      sound.playLose();
      setErrorMessage('Please enter a valid Imposter Room Code or friend\'s User ID.');
      return;
    }

    setIsSearchingRoom(true);
    sound.playPop();

    try {
      const result = await findRoomAsync(raw, 'imposter');
      setIsSearchingRoom(false);

      if (!result.success || !result.room) {
        sound.playLose();
        setErrorMessage(result.message || `❌ Room Not Found! No active Imposter room matches "${raw}".`);
        return;
      }

      // Success: Join Friend's room free
      sound.playWin();
      const found = result.room;
      setRoomCode(found.code);
      setIsHost(false);
      
      // Setup lobby with host, user, and candidate
      setLobbyPlayers([
        {
          id: 'host_friend',
          name: found.hostName || 'Host Friend',
          username: found.hostUsername || 'friend_host',
          avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${found.hostUsername || 'friend_host'}`,
          isHost: true,
        },
        {
          id: 'user_player',
          name: user.name || 'You',
          username: user.username,
          avatar: user.avatar,
          isHost: false,
        },
        {
          id: 'player_3',
          name: 'Rohan Pro',
          username: 'rohan_duel',
          avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan_pro',
          isHost: false,
        },
      ]);

      setView('lobby');
    } catch {
      setIsSearchingRoom(false);
      sound.playLose();
      setErrorMessage('Failed to connect to room. Please check connection and try again.');
    }
  };

  // Paste from clipboard helper
  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setRoomCodeInput(text.trim().toUpperCase());
        sound.playPop();
      }
    } catch {
      // ignore clipboard error in sandbox
    }
  };

  // Add / Invite friend to lobby (Min 3, Max 5 players) - strictly excluding removed/banned players
  const handleInvitePlayer = () => {
    if (lobbyPlayers.length >= 5) {
      sound.playLose();
      return;
    }

    const removedList = getRemovedFriends(user.id);
    const availablePool = [
      { name: 'Zara Star', username: 'zara_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara' },
      { name: 'Kabir Mind', username: 'kabir_pro', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=kabir' },
      { name: 'Meera Detective', username: 'meera_x', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=meera' },
      { name: 'Lucas Spark', username: 'lucas_d', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=lucas' },
    ].filter(
      (c) => !removedList.includes(c.username.toLowerCase()) && !bannedUsernames.includes(c.username.toLowerCase())
    );

    const currentNames = new Set(lobbyPlayers.map((p) => p.name));
    const nextCandidate = availablePool.find((c) => !currentNames.has(c.name)) || {
      name: `Player ${lobbyPlayers.length + 1}`,
      username: `player_${lobbyPlayers.length + 1}`,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=p${lobbyPlayers.length + 1}`,
    };

    sound.playPop();
    setLobbyPlayers((prev) => [
      ...prev,
      {
        id: `p_${Date.now()}`,
        name: nextCandidate.name,
        username: nextCandidate.username,
        avatar: nextCandidate.avatar,
        isHost: false,
      },
    ]);
  };

  // Remove player from lobby (हटाएं) - records to banned list so they NEVER re-enter
  const handleRemovePlayer = (playerId: string, playerName: string, playerUsername?: string) => {
    sound.playPop();
    if (playerUsername) {
      setBannedUsernames((prev) => [...prev, playerUsername.toLowerCase()]);
    }
    setLobbyPlayers((prev) => prev.filter((p) => p.id !== playerId));
    setInviteFriendStatus(`Removed ${playerName} (दोबारा नहीं जोड़ा जाएगा)`);
    setTimeout(() => setInviteFriendStatus(''), 2500);
  };


  const handleCopyCode = () => {
    navigator.clipboard.writeText(roomCode);
    sound.playPop();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleStartMatch = () => {
    if (lobbyPlayers.length < 3) {
      sound.playLose();
      setErrorMessage('Minimum 2 other players must be added before starting (3 players minimum).');
      return;
    }

    sound.playWin();
    const otherPlayers = lobbyPlayers.filter((p) => p.id !== 'user_player' && p.id !== 'host');
    onStartImposterGame(roomCode, lobbyPlayers.length, otherPlayers, isHost);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl p-5 sm:p-6 w-full max-w-md shadow-2xl border border-slate-100 relative max-h-[92vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors cursor-pointer z-10"
          title="Close Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* ======================================================== */}
        {/* VIEW 1: MODE SELECT (Computer vs Friends vs Create Room) */}
        {/* ======================================================== */}
        {view === 'select' && (
          <div className="flex flex-col gap-4">
            
            {/* Header */}
            <div className="text-center pt-2">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-purple-600 via-indigo-700 to-slate-950 text-white flex items-center justify-center text-3xl shadow-lg shadow-purple-500/25 mb-2">
                🎭
              </div>
              <h3 className="text-xl font-black text-slate-900 tracking-tight">
                Against the Imposter
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Choose how you want to play
              </p>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs font-bold flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{errorMessage}</span>
                </div>
                {user.coins < 20 && (
                  <button
                    type="button"
                    onClick={onOpenAdModal}
                    className="py-1.5 px-3 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Tv className="w-3.5 h-3.5" />
                    <span>Watch Video (+5 Free Coins)</span>
                  </button>
                )}
              </div>
            )}

            {/* Rule Explainer */}
            <div className="bg-purple-50/80 border border-purple-200 rounded-2xl p-3 text-left flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
              <div className="text-xs text-purple-900 leading-relaxed">
                <strong className="block font-black text-purple-950 mb-0.5">3 Players Total (1 Imposter)</strong>
                Everyone gets a secret item word. 2 players get matching items, 1 gets a different item (the Imposter). Speak your clue and vote!
              </div>
            </div>

            {/* 3 Action Buttons */}
            <div className="flex flex-col gap-2.5">
              
              {/* Option 1: Play with 2 Computers (Solo / Practice) */}
              <button
                type="button"
                onClick={handlePlayWithComputers}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm flex items-center justify-between shadow-md shadow-emerald-500/20 transition-all cursor-pointer active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg">
                    🤖
                  </div>
                  <div className="text-left">
                    <div className="font-extrabold text-sm flex items-center gap-1.5">
                      <span>Play with 2 Computers</span>
                    </div>
                    <div className="text-[11px] text-emerald-100 font-normal">
                      You + Computer 1 + Computer 2 (Anyone can be imposter)
                    </div>
                  </div>
                </div>
                <span className="text-xs bg-white text-emerald-800 font-black px-2.5 py-1 rounded-xl">
                  SOLO
                </span>
              </button>

              {/* Option 2: Enter Friend's Room Code (100% Free - 0 tokens) */}
              <button
                type="button"
                onClick={() => {
                  sound.playPop();
                  setView('enter_code');
                  setErrorMessage('');
                }}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-black text-sm flex items-center justify-between shadow-md shadow-purple-500/25 transition-all cursor-pointer active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg">
                    🔑
                  </div>
                  <div className="text-left">
                    <div className="font-extrabold text-sm">Enter Friend&apos;s Room Code</div>
                    <div className="text-[11px] text-purple-100 font-normal">
                      Input room ID from your friend
                    </div>
                  </div>
                </div>
                <span className="text-xs bg-emerald-400 text-emerald-950 font-black px-2.5 py-1 rounded-xl">
                  FREE
                </span>
              </button>

              {/* Option 3: Create Imposter Room (20 Tokens) */}
              <button
                type="button"
                onClick={handleCreateRoom}
                className="w-full p-4 rounded-2xl bg-slate-50 hover:bg-slate-100 text-slate-800 font-black text-sm flex items-center justify-between border border-slate-200 shadow-xs transition-all cursor-pointer active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center text-lg">
                    ✨
                  </div>
                  <div className="text-left">
                    <div className="font-extrabold text-sm text-slate-900">Create New Room</div>
                    <div className="text-[11px] text-slate-500 font-normal">
                      Host lobby & invite 2 to 4 friends
                    </div>
                  </div>
                </div>
                <span className="text-xs bg-amber-100 text-amber-900 border border-amber-300 font-mono font-bold px-2.5 py-1 rounded-lg">
                  -20 🪙
                </span>
              </button>

            </div>

            {/* Back to games footer button */}
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 text-center text-xs font-bold text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
            >
              ← Back to Main Menu
            </button>

          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 2: ENTER ROOM CODE (WHERE TO PUT INPUT) */}
        {/* ======================================================== */}
        {view === 'enter_code' && (
          <div className="flex flex-col gap-4 animate-in fade-in duration-200">
            
            {/* Header with Back button */}
            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setView('select');
                  setErrorMessage('');
                }}
                className="flex items-center gap-1 text-xs font-black text-slate-600 hover:text-slate-900 p-1 rounded-lg cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              <h3 className="text-base font-black text-slate-900 text-center flex-1 pr-6">
                Enter Room Code
              </h3>
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-2xl p-3 text-center">
              <span className="text-xs font-bold text-purple-900">
                📩 Ask your friend for their <strong>Room Code</strong> (e.g. <code>IMP-4821</code>) and paste it below.
              </span>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Prominent Input Box */}
            <div className="flex flex-col gap-2">
              <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 px-1">
                Room Code Input:
              </label>
              
              <div className="relative flex items-center">
                <input
                  type="text"
                  placeholder="IMP-XXXX"
                  value={roomCodeInput}
                  onChange={(e) => {
                    setRoomCodeInput(e.target.value.toUpperCase());
                    if (errorMessage) setErrorMessage('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && roomCodeInput.trim()) {
                      handleJoinByCode();
                    }
                  }}
                  className="w-full pl-4 pr-24 py-3.5 bg-slate-50 border-2 border-purple-400 rounded-2xl font-mono text-center text-base font-black uppercase tracking-widest text-slate-900 focus:outline-none focus:ring-4 focus:ring-purple-200 focus:bg-white transition-all shadow-inner"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={handlePasteClipboard}
                  className="absolute right-2 px-2.5 py-1.5 bg-purple-100 hover:bg-purple-200 text-purple-800 text-xs font-bold rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                  title="Paste from clipboard"
                >
                  <Clipboard className="w-3.5 h-3.5" />
                  <span>Paste</span>
                </button>
              </div>

              <span className="text-[11px] text-slate-400 text-center font-medium">
                Joining a friend&apos;s room is completely free (0 Tokens deducted).
              </span>
            </div>

            {/* Quick-Join Active Rooms if Available */}
            {activeImposterRooms.length > 0 && (
              <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 flex flex-col gap-2">
                <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider text-left">
                  Or Tap an Active Room:
                </span>
                <div className="flex flex-col gap-1.5">
                  {activeImposterRooms.map((room) => (
                    <button
                      key={room.code}
                      type="button"
                      onClick={() => handleJoinByCode(room.code)}
                      className="p-2.5 bg-white hover:bg-purple-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-bold text-slate-800 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-purple-700 font-black">{room.code}</span>
                        <span className="text-slate-500 font-normal">({room.hostName}&apos;s Room)</span>
                      </div>
                      <span className="text-purple-600 font-black">Join →</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setView('select');
                  setErrorMessage('');
                }}
                className="flex-1 py-3.5 rounded-2xl bg-slate-100 text-slate-700 hover:bg-slate-200 font-bold text-xs cursor-pointer transition-colors"
              >
                ← Back
              </button>
              <button
                type="button"
                onClick={() => handleJoinByCode()}
                className="flex-2 py-3.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs shadow-md shadow-purple-500/25 cursor-pointer transition-all active:scale-98"
              >
                Join Room Free (0 🪙)
              </button>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* VIEW 3: IMPOSTER ROOM LOBBY (Min 3 / Max 5 Players) */}
        {/* ======================================================== */}
        {view === 'lobby' && (
          <div className="flex flex-col gap-4 animate-in fade-in duration-200">
            
            {/* Header with Back button and Room Code */}
            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={() => {
                  sound.playClick();
                  setView('select');
                  setErrorMessage('');
                }}
                className="flex items-center gap-1 text-xs font-black text-slate-600 hover:text-slate-900 p-1 rounded-lg cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
              
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-purple-100 text-purple-800 font-mono font-black text-xs rounded-full">
                <span>Code:</span>
                <span className="font-extrabold text-purple-950">{roomCode}</span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="p-1 hover:bg-purple-200 rounded-md transition-colors cursor-pointer"
                  title="Copy code"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-purple-700" />}
                </button>
              </div>
            </div>

            <div className="text-center">
              <h3 className="text-lg font-black text-slate-900">
                Imposter Room Lobby
              </h3>
              <p className="text-xs text-slate-500">
                Players connected: <strong className="text-purple-700">{lobbyPlayers.length} / 5</strong> (Min: 3)
              </p>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Player Slots Grid */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex flex-col gap-2">
              <div className="text-[11px] font-black text-slate-500 uppercase tracking-wider flex items-center justify-between px-1">
                <span>Room Players</span>
                <span className={lobbyPlayers.length >= 3 ? 'text-emerald-600 font-bold' : 'text-amber-600 font-bold'}>
                  {lobbyPlayers.length >= 3 
                    ? `✅ Ready to Start (${lobbyPlayers.length}/5)` 
                    : lobbyPlayers.length === 2 
                      ? '⚠️ Need 1 More Player (2/3)' 
                      : '⚠️ Need 2 More Players (1/3)'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {lobbyPlayers.map((player) => (
                  <div
                    key={player.id}
                    className="flex items-center justify-between gap-1.5 p-2 bg-white rounded-xl border border-slate-200 shadow-xs group"
                  >
                    <div className="flex items-center gap-2 min-w-0 overflow-hidden">
                      <img
                        src={player.avatar}
                        alt={player.name}
                        referrerPolicy="no-referrer"
                        className="w-8 h-8 rounded-full border border-purple-200 bg-purple-50 shrink-0"
                      />
                      <div className="min-w-0 text-left">
                        <div className="text-xs font-black text-slate-900 truncate flex items-center gap-1">
                          <span className="truncate">{player.name}</span>
                          {player.isHost && (
                            <span className="text-[9px] bg-amber-100 text-amber-800 font-bold px-1 rounded-sm shrink-0">HOST</span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono truncate">
                          @{player.username}
                        </div>
                      </div>
                    </div>

                    {/* Remove/Kick Button for non-host players */}
                    {!player.isHost && (
                      <button
                        type="button"
                        onClick={() => handleRemovePlayer(player.id, player.name)}
                        className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 text-[10px] font-bold rounded-lg border border-rose-200 transition-colors flex items-center gap-0.5 shrink-0 cursor-pointer shadow-2xs active:scale-95"
                        title={`Remove ${player.name} from room`}
                      >
                        <UserX className="w-3 h-3" />
                        <span>हटाएं</span>
                      </button>
                    )}
                  </div>
                ))}

                {/* Empty Slots */}
                {Array.from({ length: 5 - lobbyPlayers.length }).map((_, idx) => (
                  <div
                    key={`empty-${idx}`}
                    className="flex items-center justify-center p-2 rounded-xl border-2 border-dashed border-slate-200 text-[11px] font-bold text-slate-400"
                  >
                    + Empty Slot
                  </div>
                ))}
              </div>
            </div>

            {/* 👥 Add Friend to Room (Below Account & Player Slots) */}
            <div className="p-3 bg-gradient-to-r from-blue-50/70 to-indigo-50/70 border border-blue-200 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase text-blue-800 tracking-wider flex items-center gap-1">
                  <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                  <span>Add Friends to Room</span>
                </span>
                <span className="text-[10px] text-blue-600 font-bold">
                  {friendsList.length} Friend(s) Available
                </span>
              </div>

              {friendsList.length > 0 ? (
                <div className="flex flex-col gap-1.5 max-h-36 overflow-y-auto pr-0.5">
                  {friendsList.map((friend) => {
                    const matchedLobbyPlayer = lobbyPlayers.find(
                      (p) => p.username.toLowerCase() === friend.username.toLowerCase()
                    );
                    const isInLobby = Boolean(matchedLobbyPlayer);

                    return (
                      <div
                        key={friend.username}
                        className="p-2 bg-white rounded-xl border border-slate-200 flex items-center justify-between shadow-2xs hover:bg-slate-50 transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <div className="relative">
                            <img
                              src={friend.avatar}
                              alt={friend.name}
                              referrerPolicy="no-referrer"
                              className={`w-7 h-7 rounded-full border bg-purple-50 ${
                                friend.isOnline ? 'border-purple-200' : 'border-rose-200 opacity-85'
                              }`}
                            />
                            {friend.isOnline ? (
                              <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full" title="Online" />
                            ) : (
                              <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-600 rounded-full flex items-center justify-center border border-white shadow-2xs" title="Offline">
                                <Check className="w-2 h-2 text-white stroke-[3.5]" />
                              </div>
                            )}
                          </div>
                          <div className="text-left">
                            <div className="text-xs font-black text-slate-900 leading-tight flex items-center gap-1">
                              <span>{friend.name}</span>
                              {!friend.isOnline && (
                                <span className="inline-flex items-center text-rose-600 shrink-0" title="Offline">
                                  <Check className="w-2.5 h-2.5 text-rose-600 stroke-[3.5]" />
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] font-mono text-slate-400">
                              @{friend.username}
                            </div>
                          </div>
                        </div>

                        {isInLobby && matchedLobbyPlayer ? (
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200 flex items-center gap-0.5">
                              <Check className="w-2.5 h-2.5" /> Added
                            </span>
                            {!matchedLobbyPlayer.isHost && (
                              <button
                                type="button"
                                onClick={() => handleRemovePlayer(matchedLobbyPlayer.id, matchedLobbyPlayer.name)}
                                className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 text-[10px] font-bold rounded-md border border-rose-200 transition-colors cursor-pointer flex items-center gap-0.5 shadow-2xs active:scale-95"
                                title={`Remove ${friend.name} from room`}
                              >
                                <UserX className="w-2.5 h-2.5" />
                                <span>हटाएं</span>
                              </button>
                            )}
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              if (lobbyPlayers.length >= 5) {
                                sound.playLose();
                                setErrorMessage('Room is full (Maximum 5 players).');
                                return;
                              }
                              sound.playWin();
                              // Dispatch 15-second room invite notification to friend
                              sendFriendRequest(user, friend.username, roomCode, 'guess-imposter', true);

                              setLobbyPlayers((prev) => [
                                ...prev,
                                {
                                  id: `friend_${Date.now()}`,
                                  name: friend.name,
                                  username: friend.username,
                                  avatar: friend.avatar,
                                  isHost: false,
                                },
                              ]);
                              setInviteFriendStatus(`Invited ${friend.name} to room (15s)!`);
                              setTimeout(() => setInviteFriendStatus(''), 2500);
                            }}
                            disabled={lobbyPlayers.length >= 5}
                            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-black rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs active:scale-95 disabled:opacity-50"
                          >
                            <UserPlus className="w-3 h-3" />
                            <span>+ Add</span>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-2 text-center text-xs text-slate-500 bg-white/70 rounded-xl border border-dashed border-blue-200">
                  <span>No friends added yet. Share room code or invite quick players below.</span>
                </div>
              )}

              {inviteFriendStatus && (
                <div className="text-[11px] text-emerald-700 font-bold bg-emerald-50 p-1.5 rounded-lg border border-emerald-200 text-center animate-in fade-in">
                  ✓ {inviteFriendStatus}
                </div>
              )}
            </div>

            {/* Quick Auto-Fill Invite Button (Up to 5 players) */}
            {lobbyPlayers.length < 5 && (
              <button
                type="button"
                onClick={handleInvitePlayer}
                className="w-full py-2.5 px-3 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <UserPlus className="w-4 h-4 text-purple-600" />
                <span>+ Invite Random Challenger ({lobbyPlayers.length}/5)</span>
              </button>
            )}

            {/* Status Guidance */}
            {lobbyPlayers.length < 3 ? (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-xs text-left font-bold flex items-start gap-2 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-amber-950 font-black mb-0.5">
                    ⚠️ खेल शुरू नहीं होगा (3 Players Required)
                  </strong>
                  {lobbyPlayers.length === 1 && (
                    <span>अभी सिर्फ 1 प्लेयर (Host) रूम में है। गेम शुरू करने के लिए 2 और प्लेयर्स को जोड़ना जरूरी है (1/3 Players)।</span>
                  )}
                  {lobbyPlayers.length === 2 && (
                    <span>1 नया प्लेयर जुड़ा है लेकिन 1 और प्लेयर का जुड़ना अभी बाकी है। जब तक 3 प्लेयर्स नहीं होते, गेम स्टार्ट नहीं होगा (2/3 Players)।</span>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs text-center font-bold flex items-center justify-center gap-1.5 animate-in fade-in">
                <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                <span>शानदार! {lobbyPlayers.length} प्लेयर्स रूम में जुड़ चुके हैं। अब आप गेम स्टार्ट कर सकते हैं!</span>
              </div>
            )}

            {/* PLAY BUTTON: Appears & Enables when at least 2 other people are added (3 to 5 players) */}
            <button
              type="button"
              onClick={handleStartMatch}
              disabled={lobbyPlayers.length < 3}
              className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
                lobbyPlayers.length >= 3
                  ? 'bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-500/25 cursor-pointer active:scale-98 animate-pulse'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
              }`}
            >
              <Play className="w-5 h-5 fill-current" />
              <span>
                {lobbyPlayers.length === 1
                  ? 'Add 2 More Players to Start (1/3)'
                  : lobbyPlayers.length === 2
                  ? 'Add 1 More Player to Start (2/3)'
                  : `PLAY GAME (${lobbyPlayers.length} Players Ready)`}
              </span>
            </button>

            {/* Leave Room / Cancel */}
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setView('select');
              }}
              className="text-xs text-slate-500 hover:text-slate-800 font-bold py-1 transition-colors cursor-pointer"
            >
              ← Leave Room & Return to Menu
            </button>

          </div>
        )}

      </div>
    </div>
  );
};
