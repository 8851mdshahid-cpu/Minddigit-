import React from 'react';
import { ActiveGameType } from '../types';

interface GameCardCoverProps {
  gameType: ActiveGameType;
}

export const GameCardCover: React.FC<GameCardCoverProps> = ({ gameType }) => {
  if (gameType === 'guess-number') {
    return (
      <div className="w-full h-full aspect-[16/10] relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#06182e] via-[#0b284e] to-[#030d1b] p-3 border-2 border-cyan-400/40 shadow-lg text-center flex flex-col items-center justify-between">
        {/* Ambient Cyan / Blue Glows */}
        <div className="absolute -top-6 -right-6 w-20 h-20 bg-cyan-500/30 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-blue-500/20 rounded-full blur-xl pointer-events-none" />

        {/* Top Mini Badges */}
        <div className="flex items-center justify-between w-full z-10">
          <span className="px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-[9px] font-mono font-black text-cyan-200 uppercase tracking-wider">
            🔢 1-100 DUEL
          </span>
          <span className="px-1.5 py-0.5 rounded-md bg-cyan-500/20 border border-cyan-400/30 text-[9px] font-bold text-cyan-300">
            HIGH / LOW
          </span>
        </div>

        {/* Central Illustrated 3D Artwork */}
        <div className="relative my-1 flex items-center justify-center">
          {/* Glowing Aura Ring */}
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 blur-[6px] opacity-70 animate-pulse" />
          
          {/* 3D Mystery Box Frame */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#113868] to-[#061e3d] border-2 border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.5)] flex items-center justify-center transform group-hover:scale-110 transition-transform">
              <span className="text-3xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                🎲
              </span>
            </div>
          </div>

          {/* Floating High/Low Arrow Tags */}
          <div className="absolute -bottom-1 -right-2 bg-cyan-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full shadow-md flex items-center gap-0.5 border border-cyan-200 font-mono">
            <span>▲▼</span>
            <span>CLUES</span>
          </div>
        </div>

        {/* Bottom Banner Title */}
        <div className="z-10 w-full">
          <div className="text-[11px] font-black text-white tracking-wide uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
            Guess Number
          </div>
          <div className="text-[9px] font-semibold text-cyan-200/80 tracking-tight mt-0.5">
            Higher or Lower Clues
          </div>
        </div>
      </div>
    );
  }

  if (gameType === 'guess-imposter') {
    return (
      <div className="w-full h-full aspect-[16/10] relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#12072B] via-[#240e4f] to-[#0a0319] p-3 border-2 border-purple-400/40 shadow-lg text-center flex flex-col items-center justify-between">
        {/* Ambient Neon Glows */}
        <div className="absolute -top-6 -right-6 w-20 h-20 bg-purple-500/30 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-pink-500/20 rounded-full blur-xl pointer-events-none" />

        {/* Top Mini Badges */}
        <div className="flex items-center justify-between w-full z-10">
          <span className="px-2 py-0.5 rounded-full bg-purple-900/80 border border-purple-400/40 text-[9px] font-mono font-black text-purple-200 uppercase tracking-wider">
            👥 3-5 Players
          </span>
          <span className="px-1.5 py-0.5 rounded-md bg-rose-500/20 border border-rose-400/30 text-[9px] font-bold text-rose-300">
            DETECTIVE
          </span>
        </div>

        {/* Central Illustrated Theatrical Mask & Magnifier Artwork */}
        <div className="relative my-1 flex items-center justify-center">
          {/* Glowing Aura Ring */}
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-purple-600 to-pink-500 blur-[6px] opacity-70 animate-pulse" />
          
          {/* 3D Mask Art Frame */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#31136b] to-[#170836] border-2 border-purple-300 shadow-[0_0_15px_rgba(168,85,247,0.5)] flex items-center justify-center transform group-hover:scale-110 transition-transform">
              <span className="text-3xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                🎭
              </span>
            </div>
          </div>

          {/* Floating Detective Magnifier & Clue Badge */}
          <div className="absolute -bottom-1 -right-2 bg-amber-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full shadow-md flex items-center gap-0.5 border border-amber-200">
            <span>🔍</span>
            <span>VOICE</span>
          </div>
        </div>

        {/* Bottom Banner Title */}
        <div className="z-10 w-full">
          <div className="text-[11px] font-black text-white tracking-wide uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
            Against Imposter
          </div>
          <div className="text-[9px] font-semibold text-purple-200/80 tracking-tight mt-0.5">
            Voice Clues & Voting
          </div>
        </div>
      </div>
    );
  }

  if (gameType === 'math-blitz') {
    return (
      <div className="w-full h-full aspect-[16/10] relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#062419] via-[#0b3d2b] to-[#04150e] p-3 border-2 border-emerald-400/40 shadow-lg text-center flex flex-col items-center justify-between">
        {/* Ambient Lightning Sparks Glow */}
        <div className="absolute -top-6 -right-6 w-20 h-20 bg-emerald-500/30 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-teal-500/20 rounded-full blur-xl pointer-events-none" />

        {/* Top Mini Badges */}
        <div className="flex items-center justify-between w-full z-10">
          <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-400/40 text-[9px] font-mono font-black text-emerald-200 uppercase tracking-wider">
            ⚡ LEVEL 10/10
          </span>
          <span className="px-1.5 py-0.5 rounded-md bg-amber-400/20 border border-amber-300/30 text-[9px] font-bold text-amber-300">
            5 ROUNDS • 10 PTS
          </span>
        </div>

        {/* Central Illustrated Lightning & Math Symbols Artwork */}
        <div className="relative my-1 flex items-center justify-center">
          {/* Glowing Aura */}
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 blur-[6px] opacity-70 animate-pulse" />
          
          {/* 3D Electric Emblem */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#0e4d36] to-[#062419] border-2 border-emerald-300 shadow-[0_0_15px_rgba(52,211,153,0.5)] flex items-center justify-center transform group-hover:scale-110 transition-transform">
              <span className="text-3xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                ⚡
              </span>
            </div>
          </div>

          {/* Floating Math Symbols */}
          <div className="absolute -top-1 -right-2 bg-emerald-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full shadow-md flex items-center gap-0.5 border border-emerald-200 font-mono">
            <span>+</span>
            <span>×</span>
          </div>
        </div>

        {/* Bottom Banner Title */}
        <div className="z-10 w-full">
          <div className="text-[11px] font-black text-white tracking-wide uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
            Math Blitz (10/10)
          </div>
          <div className="text-[9px] font-semibold text-emerald-200/80 tracking-tight mt-0.5">
            5 Rounds • 10 Pts Each • Tie-Breaker
          </div>
        </div>
      </div>
    );
  }

  if (gameType === 'bridger') {
    return (
      <div className="w-full h-full aspect-[16/10] relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#0c1445] via-[#1a237e] to-[#0a0e27] p-3 border-2 border-indigo-400/40 shadow-lg text-center flex flex-col items-center justify-between">
        {/* Ambient Indigo Glow */}
        <div className="absolute -top-6 -right-6 w-20 h-20 bg-indigo-500/30 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-purple-500/20 rounded-full blur-xl pointer-events-none" />

        {/* Top Badges */}
        <div className="flex items-center justify-between w-full z-10">
          <span className="px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-400/40 text-[9px] font-mono font-black text-indigo-200 uppercase tracking-wider">
            🌉 5 ROUNDS
          </span>
          <span className="px-1.5 py-0.5 rounded-md bg-indigo-500/20 border border-indigo-400/30 text-[9px] font-bold text-indigo-300">
            ≥3 PTS WIN
          </span>
        </div>

        {/* Central Illustrated 3D Bridge */}
        <div className="relative my-1 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 blur-[6px] opacity-70 animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#283593] to-[#1a237e] border-2 border-indigo-300 shadow-[0_0_15px_rgba(79,70,229,0.5)] flex items-center justify-center transform group-hover:scale-110 transition-transform">
              <span className="text-3xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                🌉
              </span>
            </div>
          </div>
          <div className="absolute -bottom-1 -right-2 bg-indigo-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full shadow-md flex items-center gap-0.5 border border-indigo-200 font-mono">
            <span>6s</span>
            <span>BLITZ</span>
          </div>
        </div>

        {/* Bottom Banner Title */}
        <div className="z-10 w-full">
          <div className="text-[11px] font-black text-white tracking-wide uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
            Bridger
          </div>
          <div className="text-[9px] font-semibold text-indigo-200/80 tracking-tight mt-0.5">
            5 Questions • First Answer
          </div>
        </div>
      </div>
    );
  }

  // pattern-matrix
  return (
    <div className="w-full h-full aspect-[16/10] relative rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1138] via-[#2a1752] to-[#0e0821] p-3 border-2 border-indigo-400/40 shadow-lg text-center flex flex-col items-center justify-between">
      {/* Ambient Cyber Glow */}
      <div className="absolute -top-6 -right-6 w-20 h-20 bg-indigo-500/30 rounded-full blur-xl pointer-events-none" />
      <div className="absolute -bottom-6 -left-6 w-20 h-20 bg-amber-500/20 rounded-full blur-xl pointer-events-none" />

      {/* Top Mini Badges */}
      <div className="flex items-center justify-between w-full z-10">
        <span className="px-2 py-0.5 rounded-full bg-indigo-950/80 border border-indigo-400/40 text-[9px] font-mono font-black text-indigo-200 uppercase tracking-wider">
          🧩 MEMORY
        </span>
        <span className="px-1.5 py-0.5 rounded-md bg-indigo-400/20 border border-indigo-300/30 text-[9px] font-bold text-indigo-300">
          CYBER
        </span>
      </div>

      {/* Central Illustrated Cyber Puzzle Matrix Artwork */}
      <div className="relative my-1 flex items-center justify-center">
        {/* Glowing Aura */}
        <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-amber-400 blur-[6px] opacity-70 animate-pulse" />
        
        {/* 3D Holographic Cube Frame */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#331c6b] to-[#150a30] border-2 border-indigo-300 shadow-[0_0_15px_rgba(99,102,241,0.5)] flex items-center justify-center transform group-hover:scale-110 transition-transform">
            <span className="text-3xl filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
              🧩
            </span>
          </div>
        </div>

        {/* Floating Matrix Node */}
        <div className="absolute -bottom-1 -left-2 bg-indigo-400 text-slate-950 font-black text-[10px] px-1.5 py-0.5 rounded-full shadow-md flex items-center gap-0.5 border border-indigo-200 font-mono">
          <span>3x3</span>
        </div>
      </div>

      {/* Bottom Banner Title */}
      <div className="z-10 w-full">
        <div className="text-[11px] font-black text-white tracking-wide uppercase drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
          Pattern Matrix
        </div>
        <div className="text-[9px] font-semibold text-indigo-200/80 tracking-tight mt-0.5">
          Sequence & Grid Recall
        </div>
      </div>
    </div>
  );
};
