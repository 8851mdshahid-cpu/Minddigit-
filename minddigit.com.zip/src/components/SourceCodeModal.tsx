import React, { useState } from 'react';
import { 
  X, Code2, Copy, Check, FileCode, FileText, Globe, Layers, 
  Search, Terminal, Database, Sparkles, CheckCircle2, Download
} from 'lucide-react';
import { sound } from '../utils/audio';

interface SourceCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SourceFile {
  id: string;
  name: string;
  category: 'HTML & CSS' | 'Games' | 'Core & State' | 'Social' | 'Backend';
  language: 'html' | 'css' | 'typescript' | 'javascript' | 'json';
  description: string;
  codeSnippet: string;
}

const SOURCE_FILES: SourceFile[] = [
  {
    id: 'index-html',
    name: 'index.html',
    category: 'HTML & CSS',
    language: 'html',
    description: 'HTML5 Web Entry Point & Responsive Viewport Configuration',
    codeSnippet: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>MindDigit - Next-Gen Digit Duel & Math Games</title>
    <!-- Google Fonts Inter & Outfit -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  </head>
  <body class="bg-slate-900 text-slate-100 antialiased overflow-x-hidden selection:bg-blue-500 selection:text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`,
  },
  {
    id: 'index-css',
    name: 'src/index.css',
    category: 'HTML & CSS',
    language: 'css',
    description: 'Tailwind CSS V4 Directives, Animations, & Custom Scrollbar Styles',
    codeSnippet: `@import "tailwindcss";

@layer base {
  body {
    font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
  }
}

/* Custom Shake Animation for Wrong Answers */
@keyframes shake {
  0%, 100% { transform: translateX(0); }
  20%, 60% { transform: translateX(-6px); }
  40%, 80% { transform: translateX(6px); }
}

.animate-shake {
  animation: shake 0.35s ease-in-out;
}

/* Custom Wiggle for Bell Notification */
@keyframes wiggle {
  0%, 100% { transform: rotate(0deg); }
  25% { transform: rotate(-12deg); }
  75% { transform: rotate(12deg); }
}

.animate-wiggle {
  animation: wiggle 0.6s ease-in-out infinite;
}

/* Smooth Hide Scrollbar */
.no-scrollbar::-webkit-scrollbar {
  display: none;
}
.no-scrollbar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}`,
  },
  {
    id: 'math-blitz',
    name: 'src/components/GameMathBlitz.tsx',
    category: 'Games',
    language: 'typescript',
    description: 'Math Level 10/10 Master: 5 Rounds, 10 Pts Each, 3-2 Victory Rule & Tie-Breakers',
    codeSnippet: `// Math Blitz (Level 10/10 Master Engine)
// - 5 Rounds of challenging arithmetic equations
// - +10 Points awarded per round won
// - 3 Wins (30 pts) vs 2 Wins (20 pts) Victory Rule
// - Sudden Death Tie-Breaker until 3-2 victory achieved
// - Top Winner Name Banner dynamically displayed at the top

export const GameMathBlitz: React.FC<GameMathBlitzProps> = ({ user, initialOpponent, onBack, onGameEnd }) => {
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [isTieBreakerActive, setIsTieBreakerActive] = useState<boolean>(false);
  const [userPoints, setUserPoints] = useState<number>(0);
  const [friendPoints, setFriendPoints] = useState<number>(0);
  const [userRoundsWon, setUserRoundsWon] = useState<number>(0);
  const [friendRoundsWon, setFriendRoundsWon] = useState<number>(0);

  const handleUserAnswer = (selectedNumber: number) => {
    if (selectedNumber === currentQuestion.answer) {
      const newPts = userPoints + 10;
      const newWins = userRoundsWon + 1;
      setUserPoints(newPts);
      setUserRoundsWon(newWins);
      setPointsAwardedBanner({ awardedTo: user.name, points: 10, isCorrect: true, text: '🎉 +10 Points Awarded!' });
      // Proceed to next round or tie-breaker
    }
  };
  ...
};`,
  },
  {
    id: 'bridger',
    name: 'src/components/GameBridger.tsx',
    category: 'Games',
    language: 'typescript',
    description: 'Bridger Duel: 5 Rounds, 5 Questions, 6s Blitz Countdown, >=3 Points Win Rule',
    codeSnippet: `// Bridger Duel Game Engine
// - Exactly 5 rounds & 5 questions
// - 6-second timer per question
// - 1 Point awarded to first correct answer
// - >= 3 Points: WIN, <= 2 Points: LOOSE
// - Live First-to-Answer announcement banner

export const GameBridger: React.FC<GameBridgerProps> = ({ user, initialOpponent, onBack, onGameEnd }) => {
  const [currentRound, setCurrentRound] = useState<number>(1);
  const [userPoints, setUserPoints] = useState<number>(0);
  const [friendPoints, setFriendPoints] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(6);

  const handleUserSelectOption = (index: number) => {
    if (index === currentQuestion.correctIndex) {
      setUserPoints(prev => prev + 1);
      setFirstAnswerBanner({ playerName: user.name, isCorrect: true, text: \`\${user.name} answered first! (+1 Point)\` });
    }
  };
  ...
};`,
  },
  {
    id: 'app-tsx',
    name: 'src/App.tsx',
    category: 'Core & State',
    language: 'typescript',
    description: 'Main React App Component, Navigation Router, State Management, & Token Economy',
    codeSnippet: `// MindDigit Root Component
export default function App() {
  const [screen, setScreen] = useState<ScreenType>('home');
  const [user, setUser] = useState<UserProfile>(() => loadProfileFromStorage());
  const [activeGame, setActiveGame] = useState<ActiveGameType>('guess-number');
  
  // Game routing and token deductions
  const handleStartGame = (gameId: ActiveGameType) => {
    if (user.coins < 1) {
      setIsAdModalOpen(true);
      return;
    }
    setUser(prev => ({ ...prev, coins: prev.coins - 1 }));
    setActiveGame(gameId);
    setScreen('game');
  };
  ...
};`,
  },
  {
    id: 'types-ts',
    name: 'src/types.ts',
    category: 'Core & State',
    language: 'typescript',
    description: 'TypeScript Global Type Definitions, Interfaces, & Enums',
    codeSnippet: `export type ScreenType = 'login' | 'loading' | 'home' | 'game';

export type ActiveGameType = 'guess-number' | 'guess-imposter' | 'math-blitz' | 'pattern-matrix' | 'bridger';

export type GameMode = 'computer' | 'online';

export type DifficultyLevel = 'easy' | 'normal' | 'hard';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email?: string;
  avatar: string;
  isGuest: boolean;
  coins: number;
  score: number;
  gamesPlayed: number;
  gamesWon: number;
  bestStreak: number;
  currentStreak: number;
  isAdmin?: boolean;
}`,
  },
  {
    id: 'friends-util',
    name: 'src/utils/friends.ts',
    category: 'Social',
    language: 'typescript',
    description: 'Friend Requests, Presence Engine, Live Online Indicator, & Notification Store',
    codeSnippet: `// Active Online Status Presence Engine
export const getActiveOnlineUsernames = (): string[] => {
  const online = ['shahid8851', 'rohan_duel', 'zara_99'];
  try {
    const session = localStorage.getItem('minddigit_session_profile');
    if (session) {
      const parsed = JSON.parse(session);
      if (parsed?.username && !online.includes(parsed.username.toLowerCase())) {
        online.push(parsed.username.toLowerCase());
      }
    }
  } catch {}
  return online;
};

export const getFriends = (userId: string): Friend[] => {
  const onlineList = getActiveOnlineUsernames();
  return loadSavedFriends(userId).map(f => ({
    ...f,
    isOnline: onlineList.includes(f.username.toLowerCase())
  }));
};`,
  },
  {
    id: 'server-ts',
    name: 'server.ts',
    category: 'Backend',
    language: 'typescript',
    description: 'Express.js Full-Stack Backend, Health Check, Matchmaking API, & Vite Middleware',
    codeSnippet: `import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health API
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Online Matchmaking API Endpoints
  app.post('/api/rooms/create', (req, res) => {
    const { hostUsername, gameType } = req.body;
    const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    res.json({ roomCode, hostUsername, gameType });
  });

  // Vite development middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(\`MindDigit Server running on http://localhost:\${PORT}\`);
  });
}

startServer();`,
  },
];

export const SourceCodeModal: React.FC<SourceCodeModalProps> = ({ isOpen, onClose }) => {
  const [selectedFileId, setSelectedFileId] = useState<string>('math-blitz');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const categories = ['All', 'HTML & CSS', 'Games', 'Core & State', 'Social', 'Backend'];

  const filteredFiles = SOURCE_FILES.filter((file) => {
    const matchesCategory = activeCategory === 'All' || file.category === activeCategory;
    const matchesSearch = 
      file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      file.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const currentFile = SOURCE_FILES.find((f) => f.id === selectedFileId) || SOURCE_FILES[0];

  const handleCopyCode = () => {
    sound.playPop();
    navigator.clipboard.writeText(currentFile.codeSnippet);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100 animate-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-950/70 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>MindDigit Source Code Explorer</span>
                <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full font-mono">
                  Full Stack
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Inspect HTML, CSS, React, TypeScript, Game Engines, and Server Code
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs & Search Bar */}
        <div className="px-5 py-3 bg-slate-950/40 border-b border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Category Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto no-scrollbar py-0.5">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  sound.playClick();
                  setActiveCategory(cat);
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/25'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search files or code..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>
        </div>

        {/* Main Content Layout: Sidebar + Code Editor Viewer */}
        <div className="flex-1 min-h-0 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
          
          {/* Left Sidebar: File List */}
          <div className="md:col-span-4 bg-slate-950/30 border-r border-slate-800 overflow-y-auto p-3 space-y-1.5 max-h-[220px] md:max-h-full">
            <div className="text-[10px] font-black uppercase tracking-wider text-slate-500 px-2 py-1 flex items-center justify-between">
              <span>PROJECT FILES ({filteredFiles.length})</span>
              <FileCode className="w-3.5 h-3.5" />
            </div>

            {filteredFiles.map((file) => {
              const isSelected = file.id === currentFile.id;
              return (
                <button
                  key={file.id}
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setSelectedFileId(file.id);
                  }}
                  className={`w-full p-2.5 rounded-2xl text-left transition-all cursor-pointer flex items-start gap-2.5 border ${
                    isSelected
                      ? 'bg-blue-600/15 border-blue-500/40 text-white shadow-sm'
                      : 'bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800/80 hover:text-white'
                  }`}
                >
                  <div className={`p-1.5 rounded-xl shrink-0 mt-0.5 ${
                    isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {file.category === 'HTML & CSS' ? (
                      <Globe className="w-3.5 h-3.5" />
                    ) : file.category === 'Backend' ? (
                      <Terminal className="w-3.5 h-3.5" />
                    ) : (
                      <FileCode className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-mono font-bold truncate">
                        {file.name}
                      </span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                        {file.language}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">
                      {file.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Main Panel: Code Snippet Viewer with Line Numbers & Copy Button */}
          <div className="md:col-span-8 flex flex-col bg-slate-950 min-h-0 overflow-hidden">
            
            {/* Active File Header */}
            <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 truncate">
                <span className="text-xs font-mono font-black text-blue-400">
                  {currentFile.name}
                </span>
                <span className="text-[10px] text-slate-400 hidden sm:inline">
                  • {currentFile.description}
                </span>
              </div>

              {/* Copy Code Button */}
              <button
                type="button"
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-300" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Body Area */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 leading-relaxed bg-[#0b101e] select-text">
              <pre className="overflow-x-auto whitespace-pre">
                <code>{currentFile.codeSnippet}</code>
              </pre>
            </div>

            {/* Bottom Status Bar */}
            <div className="px-4 py-2 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span>Format: {currentFile.language.toUpperCase()}</span>
                <span>• Category: {currentFile.category}</span>
              </div>
              <span className="text-slate-500">MindDigit Engine v1.2</span>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
