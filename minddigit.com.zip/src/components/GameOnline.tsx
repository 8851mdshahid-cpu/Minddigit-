import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  ArrowLeft, Globe, Copy, Check, Timer, Coins, KeyRound, Play, AlertCircle, 
  ArrowUp, ArrowDown, Lock, Key, ChevronRight, Dices, RotateCcw, Trophy, 
  HelpCircle, UserX, Swords, UserPlus, Users, Sparkles, ShieldAlert 
} from 'lucide-react';
import { DifficultyLevel, UserProfile } from '../types';
import { sound } from '../utils/audio';
import { findRoomByCode, getActiveRooms } from '../utils/rooms';
import { getFriends, Friend, sendFriendRequest } from '../utils/friends';
import { GuessNumberBadge } from './GuessNumberBadge';

interface GuessItem {
  player: 'user' | 'opponent';
  guess: number;
  hint: 'higher' | 'lower' | 'correct';
  timestamp: number;
}

interface GameOnlineProps {
  difficulty: DifficultyLevel;
  user: UserProfile;
  initialRoomCode?: string;
  initialOpponent?: { name: string; username: string };
  onBack: () => void;
  onGameEnd: (won: boolean, score: number, coins: number) => void;
  onRetry?: () => void;
}

export const GameOnline: React.FC<GameOnlineProps> = ({
  difficulty,
  user,
  initialRoomCode,
  initialOpponent,
  onBack,
  onGameEnd,
  onRetry,
}) => {
  const maxRange = 100; // Guess numbers between 1 and 100
  const maxChances = 10; // 10 chances for each player
  const turnTimerLimit = 25; // 25-second timer per turn

  const [lobbyState, setLobbyState] = useState<'lobby' | 'setup_number' | 'in_game' | 'result'>('lobby');
  const [roomCode, setRoomCode] = useState<string>(() => initialRoomCode || `MIND-${Math.floor(Math.random() * 8999 + 1000)}`);
  const [inputRoomCode, setInputRoomCode] = useState<string>('');
  const [showInputBox, setShowInputBox] = useState<boolean>(false);
  const [inputError, setInputError] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Player 2 / Opponent joined status (Game will NOT start if player 2 is missing)
  const [opponentJoined, setOpponentJoined] = useState<boolean>(() => Boolean(initialOpponent));
  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [inviteStatus, setInviteStatus] = useState<string>('');

  // Setup Secret Number
  const [userSecretNumber, setUserSecretNumber] = useState<number | null>(null);
  const [setupInput, setSetupInput] = useState<string>('');
  const [setupError, setSetupError] = useState<string>('');

  // Opponent Details
  const [opponent, setOpponent] = useState<{
    id: string;
    name: string;
    username: string;
    avatar?: string;
    chancesLeft: number;
    lastGuessedNumber: number | null;
  }>({
    id: 'opp-102',
    name: initialOpponent?.name || 'Friend Challenger',
    username: initialOpponent?.username || 'friend_player',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=friend_player',
    chancesLeft: maxChances,
    lastGuessedNumber: null,
  });

  // Game Logic
  const [secretNumber, setSecretNumber] = useState<number>(0);
  const [currentInput, setCurrentInput] = useState<string>('');
  const [turn, setTurn] = useState<'user' | 'opponent'>('user');
  const [timeLeft, setTimeLeft] = useState<number>(turnTimerLimit);
  
  const [userChancesLeft, setUserChancesLeft] = useState<number>(maxChances);
  const [userLastGuess, setUserLastGuess] = useState<number | null>(null);
  
  const [guessHistory, setGuessHistory] = useState<GuessItem[]>([]);
  const [feedback, setFeedback] = useState<string>('Match ready! Guess a number between 1 and 100.');
  const [winner, setWinner] = useState<'user' | 'opponent' | 'nobody' | null>(null);

  // Sliding Box Ref
  const slidingBoxRef = useRef<HTMLDivElement>(null);

  // Load friends on mount
  useEffect(() => {
    setFriendsList(getFriends(user.id));
  }, [user.id]);

  // Auto-scroll sliding history box to end when new guess is made
  useEffect(() => {
    if (slidingBoxRef.current) {
      slidingBoxRef.current.scrollTo({
        left: slidingBoxRef.current.scrollWidth,
        behavior: 'smooth',
      });
    }
  }, [guessHistory]);

  // When room ID changes or initial code is passed
  useEffect(() => {
    if (initialRoomCode) {
      setRoomCode(initialRoomCode);
    }
    if (initialOpponent) {
      setOpponent({
        id: `opp-${Date.now()}`,
        name: initialOpponent.name,
        username: initialOpponent.username,
        avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${initialOpponent.username}`,
        chancesLeft: maxChances,
        lastGuessedNumber: null,
      });
      setOpponentJoined(true);
    }
  }, [initialRoomCode, initialOpponent, maxChances]);

  // Start the 2-Player Game (ONLY ALLOWED IF OPPONENT HAS JOINED)
  const handleStartMatch = () => {
    if (!opponentJoined) {
      sound.playLose();
      setInputError('⚠️ खेल शुरू नहीं होगा! जब तक दूसरा प्लेयर (Player 2) रूम में नहीं जुड़ता, गेम स्टार्ट नहीं किया जा सकता।');
      return;
    }

    sound.playWin();
    const secret = Math.floor(Math.random() * maxRange) + 1;
    setSecretNumber(secret);
    setGuessHistory([]);
    setUserChancesLeft(maxChances);
    setUserLastGuess(null);
    setUserSecretNumber(null);
    setSetupInput('');
    setSetupError('');
    setTurn('user');
    setTimeLeft(turnTimerLimit);
    setWinner(null);
    setFeedback(`Step 1: Type your number for ${opponent.name} to guess!`);
    setLobbyState('setup_number');
  };

  // Invite a friend to this 1v1 room
  const handleInviteFriendToRoom = (friend: Friend) => {
    if (!friend.isOnline) {
      sound.playLose();
      sendFriendRequest(user, friend.username, roomCode, 'guess-number', true);
      setInviteStatus(`⚠️ ${friend.name} (@${friend.username}) अभी Offline है! नोटिफिकेशन भेज दिया गया है। जब वो ऑनलाइन आएगा तभी जुड़ सकेगा।`);
      setTimeout(() => setInviteStatus(''), 4500);
      return;
    }

    sound.playWin();
    sendFriendRequest(user, friend.username, roomCode, 'guess-number', true);
    
    setOpponent({
      id: `friend_${Date.now()}`,
      name: friend.name,
      username: friend.username,
      avatar: friend.avatar,
      chancesLeft: maxChances,
      lastGuessedNumber: null,
    });
    setOpponentJoined(true);
    setInviteStatus(`✓ ${friend.name} connected to Room ${roomCode}!`);
    setInputError('');
    setTimeout(() => setInviteStatus(''), 3000);
  };

  // Remove opponent / Player 2 from room (हटाएं)
  const handleRemoveOpponent = () => {
    sound.playPop();
    const prevName = opponent.name;
    setOpponentJoined(false);
    setOpponent({
      id: 'opp-102',
      name: 'Friend Challenger',
      username: 'friend_player',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=friend_player',
      chancesLeft: maxChances,
      lastGuessedNumber: null,
    });
    setInviteStatus(`Removed ${prevName} from room (प्लेयर को रूम से हटा दिया गया)`);
    setTimeout(() => setInviteStatus(''), 2500);
  };

  // Add active online challenger to populate Player 2
  const handleAddRandomChallenger = () => {
    const oppNames = [
      { name: 'Rohan Pro', username: 'rohan_duel', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=rohan_pro' },
      { name: 'Zara Star', username: 'zara_99', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=zara' },
      { name: 'Alex Cipher', username: 'alex_cipher', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=alex' },
    ];
    const picked = oppNames[Math.floor(Math.random() * oppNames.length)];
    sound.playPop();
    setOpponent({
      id: `opp-${Date.now()}`,
      name: picked.name,
      username: picked.username,
      avatar: picked.avatar,
      chancesLeft: maxChances,
      lastGuessedNumber: null,
    });
    setOpponentJoined(true);
    setInputError('');
  };

  // Confirm Secret Number and start in_game
  const handleConfirmSecretNumber = (numToSet?: number) => {
    const rawVal = numToSet !== undefined ? numToSet : parseInt(setupInput, 10);
    if (isNaN(rawVal) || rawVal < 1 || rawVal > maxRange) {
      sound.playLose();
      setSetupError(`Please enter a valid number between 1 and ${maxRange}`);
      return;
    }

    sound.playWin();
    setUserSecretNumber(rawVal);
    setSetupError('');
    setLobbyState('in_game');
    setTurn('user');
    setTimeLeft(turnTimerLimit);
    setFeedback(`Your secret is locked (${rawVal})! Both players have 10 chances. Your turn (25s)!`);
  };

  // Connect to another room ID with strict code validation
  const handleConnectWithId = () => {
    setInputError('');
    if (!inputRoomCode.trim()) {
      sound.playLose();
      setInputError('Please enter a Room ID.');
      return;
    }

    const cleanCode = inputRoomCode.trim().toUpperCase();
    const foundRoom = findRoomByCode(cleanCode);

    if (!foundRoom) {
      sound.playLose();
      setInputError(`❌ Invalid Room ID! No active room matches "${cleanCode}".`);
      return;
    }

    // Success: room exists!
    sound.playWin();
    setRoomCode(cleanCode);
    setInputRoomCode('');
    setShowInputBox(false);
    setOpponent({
      id: `host-${Date.now()}`,
      name: foundRoom.hostName || 'Connected Friend',
      username: foundRoom.hostUsername || 'friend_room',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=friend_room',
      chancesLeft: maxChances,
      lastGuessedNumber: null,
    });
    setOpponentJoined(true);
  };

  const copyRoomCode = () => {
    if (roomCode) {
      navigator.clipboard?.writeText(roomCode);
      setCopied(true);
      sound.playClick();
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // 25-Second Turn Timer Loop (passes turn when timer expires without fake guesses)
  useEffect(() => {
    if (lobbyState !== 'in_game' || winner !== null) return;
    if (timeLeft <= 0) {
      // Timer ran out without guess -> switch turn cleanly
      if (turn === 'user') {
        sound.playLose();
        setFeedback(`⏰ Your time ran out! Turn passed to ${opponent.name}.`);
        setTurn('opponent');
        setTimeLeft(turnTimerLimit);
      } else {
        setFeedback(`⏰ @${opponent.username} did not make a move within 25s. Your turn!`);
        setTurn('user');
        setTimeLeft(turnTimerLimit);
      }
      return;
    }

    const timer = setTimeout(() => {
      setTimeLeft((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [lobbyState, winner, turn, timeLeft, turnTimerLimit, opponent.name, opponent.username]);

  // Turn status feedback updater (strictly waits for real opponent move)
  useEffect(() => {
    if (lobbyState !== 'in_game' || winner !== null) return;
    if (turn === 'opponent') {
      setFeedback(`⏳ Waiting for @${opponent.username} to make their move in real-time... (${timeLeft}s)`);
    }
  }, [turn, lobbyState, winner, opponent.username, timeLeft]);

  // User Guess Submission
  const handleUserGuess = () => {
    if (turn !== 'user' || winner !== null || lobbyState !== 'in_game') return;

    const num = parseInt(currentInput, 10);
    if (isNaN(num) || num < 1 || num > maxRange) {
      sound.playLose();
      setFeedback(`Enter a number between 1 and ${maxRange}`);
      return;
    }

    const newChances = userChancesLeft - 1;
    setUserChancesLeft(newChances);
    setUserLastGuess(num);
    setCurrentInput('');

    let hint: 'higher' | 'lower' | 'correct' = 'correct';
    if (num < secretNumber) {
      hint = 'higher';
      sound.playHigher();
      setFeedback(`You guessed ${num} (Target is HIGHER ▲). Opponent's turn!`);
    } else if (num > secretNumber) {
      hint = 'lower';
      sound.playLower();
      setFeedback(`You guessed ${num} (Target is LOWER ▼). Opponent's turn!`);
    } else {
      hint = 'correct';
      sound.playWin();
      confetti({ particleCount: 160, spread: 80, origin: { y: 0.6 } });
      setWinner('user');
      setLobbyState('result');
      setFeedback(`🎉 BINGO! You guessed ${num} and won the room battle!`);
      const updatedHistory: GuessItem[] = [
        ...guessHistory,
        { player: 'user', guess: num, hint, timestamp: Date.now() },
      ];
      setGuessHistory(updatedHistory);
      onGameEnd(true, 500 + newChances * 50, 50);
      return;
    }

    setGuessHistory((prev) => [
      ...prev,
      { player: 'user', guess: num, hint, timestamp: Date.now() },
    ]);

    if (newChances <= 0 && opponent.chancesLeft <= 0) {
      setWinner('nobody');
      setLobbyState('result');
      setFeedback(`Both players used all 10 chances! Secret was ${secretNumber}.`);
      onGameEnd(false, 20, 5);
      return;
    }

    // Pass turn to opponent
    setTurn('opponent');
    setTimeLeft(turnTimerLimit);
  };

  const checkGameOver = (uChances: number, oChances: number) => {
    if (uChances <= 0 && oChances <= 0) {
      setWinner('nobody');
      setLobbyState('result');
      setFeedback(`Match ended! Neither player guessed in 10 chances. Number was ${secretNumber}.`);
      onGameEnd(false, 10, 5);
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto p-3 sm:p-5 select-none font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* 1. ROOM LOBBY / WAITING SCREEN */}
      {lobbyState === 'lobby' && (
        <div className="bg-white/90 backdrop-blur-md rounded-[36px] p-6 sm:p-8 border border-white shadow-xl flex flex-col gap-5 text-center animate-in fade-in duration-200">
          
          {/* Header */}
          <div className="flex items-center justify-between">
            <button
              id="online-back-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                onBack();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-bold transition-all cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Exit</span>
            </button>

            <div className="flex items-center gap-1 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 text-amber-900 text-xs font-black shadow-2xs">
              <Coins className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
              <span>+50 Tokens</span>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2">
            <div className="w-16 h-16 rounded-3xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/25">
              <Globe className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">
              2-Player Online Duel
            </h2>
            <p className="text-xs font-medium text-slate-500 max-w-xs">
              Take turns guessing the mystery number (1-100) with higher/lower clues and a 25s timer!
            </p>
          </div>

          {/* Room Code Card */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex flex-col items-center gap-2">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400">
              Your Room ID
            </span>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black font-mono tracking-wider text-slate-900">
                {roomCode}
              </span>
              <button
                type="button"
                onClick={copyRoomCode}
                className="p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-all shadow-2xs cursor-pointer"
                title="Copy Room ID"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-[11px] font-semibold text-slate-500">
              Share this code with your friend to connect and duel!
            </p>
          </div>

          {/* 2-Player Room Slots Grid */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 flex flex-col gap-2.5 text-left">
            <div className="flex items-center justify-between px-1">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>Room Players</span>
              </span>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                opponentJoined ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800 animate-pulse'
              }`}>
                {opponentJoined ? '✅ 2/2 Connected' : '⚠️ 1/2 (Player 2 Missing)'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Player 1 (Host - You) */}
              <div className="p-2.5 bg-white rounded-xl border border-blue-200 shadow-2xs flex items-center gap-2">
                <div className="relative">
                  <div className="w-8 h-8 rounded-full bg-slate-900 text-amber-300 font-serif font-black text-xs flex items-center justify-center border border-white">
                    {user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full" />
                </div>
                <div className="overflow-hidden">
                  <div className="text-xs font-black text-slate-900 truncate flex items-center gap-1">
                    <span>{user.name}</span>
                    <span className="text-[8px] bg-amber-100 text-amber-800 font-bold px-1 rounded-xs">HOST</span>
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 truncate">@{user.username}</div>
                </div>
              </div>

              {/* Player 2 (Opponent / Challenger) */}
              {opponentJoined ? (
                <div className="p-2.5 bg-white rounded-xl border border-emerald-300 shadow-2xs flex items-center justify-between gap-1.5 animate-in zoom-in-95">
                  <div className="flex items-center gap-2 overflow-hidden min-w-0">
                    <div className="relative shrink-0">
                      <img
                        src={opponent.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${opponent.username}`}
                        alt={opponent.name}
                        referrerPolicy="no-referrer"
                        className="w-8 h-8 rounded-full bg-purple-50 border border-purple-200"
                      />
                      <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full" />
                    </div>
                    <div className="overflow-hidden min-w-0 text-left">
                      <div className="text-xs font-black text-slate-900 truncate">{opponent.name}</div>
                      <div className="text-[10px] font-mono text-slate-400 truncate">@{opponent.username}</div>
                    </div>
                  </div>

                  {/* Remove Player 2 button */}
                  <button
                    type="button"
                    onClick={handleRemoveOpponent}
                    className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 text-[10px] font-bold rounded-lg border border-rose-200 transition-colors flex items-center gap-0.5 shrink-0 cursor-pointer shadow-2xs active:scale-95"
                    title="Remove Player 2 from room"
                  >
                    <UserX className="w-3 h-3" />
                    <span>हटाएं</span>
                  </button>
                </div>
              ) : (
                <div className="p-2.5 rounded-xl border-2 border-dashed border-amber-300 bg-amber-50/50 flex flex-col items-center justify-center text-center">
                  <span className="text-[11px] font-black text-amber-800">Waiting for Player 2...</span>
                  <span className="text-[9px] text-amber-600">Share code or invite friend</span>
                </div>
              )}
            </div>
          </div>

          {/* Validation Notice Banner */}
          {!opponentJoined ? (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-left flex items-start gap-2 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-900 leading-snug">
                <strong className="block font-black text-amber-950 mb-0.5">
                  ⚠️ खेल शुरू नहीं होगा (Player 2 Required)
                </strong>
                जब तक दूसरा प्लेयर (Player 2) इस रूम में नहीं जुड़ता, गेम स्टार्ट नहीं किया जा सकता। नीचे दोस्तों को इनवाइट करें या रैंडम चैलेंजर जोड़ें।
              </div>
            </div>
          ) : (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
              <span>2/2 प्लेयर्स जुड़ चुके हैं! अब आप गेम स्टार्ट कर सकते हैं।</span>
            </div>
          )}

          {/* Friend Invitation Section in 1v1 Room */}
          {friendsList.length > 0 && (
            <div className="bg-blue-50/70 border border-blue-200 rounded-2xl p-3 flex flex-col gap-2 text-left">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase text-blue-900 tracking-wider flex items-center gap-1">
                  <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                  <span>Invite Online Friends to Room</span>
                </span>
                <span className="text-[10px] font-bold text-blue-600">
                  {friendsList.length} Friend(s)
                </span>
              </div>

              <div className="flex flex-col gap-1.5 max-h-32 overflow-y-auto pr-0.5">
                {friendsList.map((friend) => {
                  const isCurrentOpponent = opponentJoined && opponent.username.toLowerCase() === friend.username.toLowerCase();

                  return (
                    <div
                      key={friend.username}
                      className="p-2 bg-white rounded-xl border border-slate-200 flex items-center justify-between shadow-2xs hover:bg-slate-50 transition-colors"
                    >
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <img
                            src={friend.avatar}
                            alt={friend.name}
                            referrerPolicy="no-referrer"
                            className={`w-7 h-7 rounded-full border bg-purple-50 ${
                              friend.isOnline ? 'border-purple-200' : 'border-rose-300 grayscale-[25%]'
                            }`}
                          />
                          {friend.isOnline ? (
                            <span className="absolute bottom-0 right-0 w-2 h-2 bg-emerald-500 border border-white rounded-full shadow-2xs" title="Online" />
                          ) : (
                            <div
                              className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-rose-600 rounded-full border border-white flex items-center justify-center shadow-xs"
                              title="Offline (लाल गोल स्टिकर)"
                            >
                              <span className="w-1 h-1 bg-white rounded-full" />
                            </div>
                          )}
                        </div>
                        <div>
                          <div className="text-xs font-black text-slate-900 leading-tight flex items-center gap-1">
                            <span>{friend.name}</span>
                            {!friend.isOnline && (
                              <span className="text-[9px] text-rose-700 bg-rose-50 border border-rose-200 font-bold px-1 rounded">
                                Offline
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] font-mono text-slate-400">@{friend.username}</div>
                        </div>
                      </div>

                      {isCurrentOpponent ? (
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200 flex items-center gap-0.5">
                            <Check className="w-2.5 h-2.5" /> Added
                          </span>
                          <button
                            type="button"
                            onClick={handleRemoveOpponent}
                            className="px-2 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 text-[10px] font-bold rounded-md border border-rose-200 transition-colors cursor-pointer flex items-center gap-0.5 shadow-2xs active:scale-95"
                            title="Remove from room"
                          >
                            <UserX className="w-2.5 h-2.5" />
                            <span>हटाएं</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleInviteFriendToRoom(friend)}
                          disabled={opponentJoined}
                          className={`px-2.5 py-1 text-[11px] font-black rounded-lg transition-colors cursor-pointer flex items-center gap-1 shadow-2xs active:scale-95 disabled:opacity-40 ${
                            friend.isOnline
                              ? 'bg-blue-600 hover:bg-blue-700 text-white'
                              : 'bg-rose-100 hover:bg-rose-200 text-rose-800 border border-rose-200'
                          }`}
                        >
                          <UserPlus className="w-3 h-3" />
                          <span>{friend.isOnline ? '+ Invite' : 'Invite (Offline)'}</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {inviteStatus && (
            <div className="text-xs text-emerald-700 font-bold bg-emerald-50 p-2 rounded-xl border border-emerald-200 text-center animate-in fade-in">
              {inviteStatus}
            </div>
          )}

          {/* Quick Connect Random Challenger button if no player 2 */}
          {!opponentJoined && (
            <button
              type="button"
              onClick={handleAddRandomChallenger}
              className="w-full py-2.5 px-3 bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <UserPlus className="w-3.5 h-3.5 text-purple-600" />
              <span>+ Add Instant Challenger (Player 2)</span>
            </button>
          )}

          {/* Action Buttons: START MATCH (DISABLED IF PLAYER 2 IS NOT JOINED) */}
          <div className="flex flex-col gap-2.5">
            <button
              id="online-start-match-btn"
              type="button"
              onClick={handleStartMatch}
              disabled={!opponentJoined}
              className={`w-full py-4 font-extrabold text-sm rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 uppercase tracking-wider ${
                opponentJoined
                  ? 'bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-700 text-white shadow-emerald-500/25 active:scale-98 cursor-pointer animate-pulse'
                  : 'bg-slate-200 text-slate-400 shadow-none cursor-not-allowed'
              }`}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>
                {opponentJoined ? 'Start Match (2 Players Ready)' : 'Waiting for Player 2 (Cannot Start)'}
              </span>
            </button>

            <button
              id="online-join-room-toggle-btn"
              type="button"
              onClick={() => {
                sound.playClick();
                setShowInputBox(!showInputBox);
                setInputError('');
              }}
              className="w-full py-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-extrabold text-xs rounded-2xl transition-all shadow-2xs cursor-pointer flex items-center justify-center gap-2"
            >
              <KeyRound className="w-3.5 h-3.5 text-blue-600" />
              <span>{showInputBox ? 'Close Room ID Input' : 'Connect with Friend Room ID'}</span>
            </button>
          </div>

          {/* Connect to Another Room ID */}
          {showInputBox && (
            <div className="bg-blue-50/80 border border-blue-200 rounded-2xl p-4 flex flex-col gap-2 text-left animate-in slide-in-from-top-2">
              <label className="text-xs font-extrabold text-blue-950 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                <span>Enter Friend's Room ID:</span>
              </label>
              
              <div className="flex gap-2">
                <input
                  id="connect-room-input"
                  type="text"
                  placeholder="e.g. MIND-4892"
                  value={inputRoomCode}
                  onChange={(e) => {
                    setInputRoomCode(e.target.value);
                    setInputError('');
                  }}
                  className="flex-1 px-3 py-2 bg-white border border-blue-200 rounded-xl font-mono text-sm font-bold text-slate-800 uppercase focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={handleConnectWithId}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-xs cursor-pointer"
                >
                  Join
                </button>
              </div>

              {inputError && (
                <div className="flex items-center gap-1 text-xs font-bold text-rose-600 mt-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{inputError}</span>
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* 2. STEP 1: TYPE YOUR NUMBER SETUP SCREEN */}
      {lobbyState === 'setup_number' && (
        <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 border border-white shadow-xl flex flex-col gap-4 text-center mb-3 animate-in zoom-in-95 duration-200">
          <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 mx-auto flex items-center justify-center shadow-inner">
            <Key className="w-7 h-7" />
          </div>

          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-blue-600 bg-blue-50 px-3 py-0.5 rounded-full border border-blue-200">
              Step 1: Set Secret Number
            </span>
            <h2 className="text-xl font-black text-slate-900 mt-2">
              Type Your Number
            </h2>
            <p className="text-xs font-medium text-slate-500 mt-1 max-w-xs mx-auto">
              Enter your secret number (1-100). {opponent.name} will try to guess your number, while you guess theirs!
            </p>
          </div>

          {/* Number Display Box */}
          <div className="bg-slate-50 border-2 border-blue-400 rounded-2xl py-4 px-4 flex items-center justify-center">
            <input
              id="online-setup-secret-input"
              type="number"
              min="1"
              max="100"
              value={setupInput}
              onChange={(e) => {
                setSetupInput(e.target.value);
                if (setupError) setSetupError('');
              }}
              placeholder="e.g. 55"
              className="w-full text-center text-3xl font-black font-mono text-blue-700 bg-transparent outline-none placeholder:text-slate-300"
            />
          </div>

          {setupError && (
            <p className="text-xs font-bold text-rose-600 bg-rose-50 py-1.5 px-3 rounded-xl border border-rose-200">
              {setupError}
            </p>
          )}

          {/* Quick Choice / Randomizer */}
          <div className="flex items-center justify-center gap-1.5 flex-wrap">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Quick pick:</span>
            {[25, 42, 55, 77, 88].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => {
                  sound.playPop();
                  setSetupInput(num.toString());
                  if (setupError) setSetupError('');
                }}
                className="px-3 py-1 bg-white hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-bold font-mono text-slate-700 cursor-pointer shadow-2xs active:scale-95"
              >
                {num}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                sound.playPop();
                const rand = Math.floor(Math.random() * maxRange) + 1;
                setSetupInput(rand.toString());
                if (setupError) setSetupError('');
              }}
              className="px-3 py-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl text-xs font-bold text-amber-800 cursor-pointer shadow-2xs flex items-center gap-1 active:scale-95"
            >
              <Dices className="w-3.5 h-3.5 text-amber-600" />
              <span>Random</span>
            </button>
          </div>

          {/* Confirm Button */}
          <button
            id="online-confirm-secret-number-btn"
            type="button"
            onClick={() => handleConfirmSecretNumber()}
            className="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-blue-500/25 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Lock Number & Start Duel</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 3. ACTIVE IN-GAME SCREEN */}
      {(lobbyState === 'in_game' || lobbyState === 'result') && (
        <div className="flex flex-col gap-3">
          
          {/* Top Status Strip: Room Code & Timer */}
          <div className="flex items-center justify-between bg-white/80 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white shadow-sm">
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setLobbyState('lobby');
              }}
              className="p-1.5 rounded-xl text-slate-500 hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-slate-500">{roomCode}</span>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                1-100
              </span>
            </div>

            {/* 25s Countdown Timer */}
            <div className={`flex items-center gap-1 px-3 py-1 rounded-full font-black text-xs ${
              timeLeft <= 5 ? 'bg-rose-500 text-white animate-pulse' : 'bg-amber-100 text-amber-800'
            }`}>
              <Timer className="w-3.5 h-3.5" />
              <span>{timeLeft}s</span>
            </div>
          </div>

          {/* Prominent Header Banner Showing "Your number is: XX" */}
          {userSecretNumber !== null && (
            <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-2.5 rounded-2xl shadow-md border border-white/40 flex items-center justify-between animate-in fade-in duration-300">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
                  <Lock className="w-4 h-4 text-amber-300" />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-blue-100 block">
                    Your Secret Number
                  </span>
                  <span className="text-sm font-black tracking-tight text-white">
                    Your number is: <span className="font-mono text-amber-300 text-base">{userSecretNumber}</span>
                  </span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[9px] font-bold text-blue-200 uppercase block">{opponent.name}'s Secret</span>
                <span className="text-xs font-black font-mono text-white/90 bg-white/10 px-2 py-0.5 rounded-md">
                  {winner !== null ? secretNumber : '?? (Hidden)'}
                </span>
              </div>
            </div>
          )}

          {/* 2 PLAYERS DUAL HUD (Your ID with Tick below & Opponent ID with Question Mark) */}
          <div className="grid grid-cols-2 gap-3">
            
            {/* Left Player: YOU */}
            <div className={`p-3.5 rounded-3xl border transition-all duration-300 relative ${
              turn === 'user'
                ? 'bg-blue-50/90 border-blue-400 shadow-md ring-2 ring-blue-400/30'
                : 'bg-white/80 border-white shadow-sm opacity-90'
            }`}>
              {/* Small box on the corner of our ID displaying our number selection */}
              <div 
                id="user-number-selection-corner-box"
                className="absolute -top-2.5 -right-2 bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-xl px-2.5 py-0.5 shadow-md border-2 border-white flex items-center gap-1.5 z-20 animate-in zoom-in-90"
                title="Your selected number"
              >
                <span className="text-[8px] font-black uppercase tracking-wider text-blue-200">Selected:</span>
                <span className="text-xs font-black font-mono tracking-tight bg-white/20 px-1.5 py-0.2 rounded-md">
                  {currentInput ? currentInput : userLastGuess !== null ? userLastGuess : userSecretNumber ? userSecretNumber : '--'}
                </span>
              </div>

              {turn === 'user' && (
                <span className="absolute -top-2 left-4 bg-blue-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                  YOUR TURN
                </span>
              )}
              
              <div className="flex items-center gap-2 mb-2">
                <div className="relative">
                  <div className="w-8 h-8 rounded-full bg-slate-900 text-amber-300 font-serif font-black text-sm flex items-center justify-center border border-white">
                    {user.name ? user.name.charAt(0).toUpperCase() : 'M'}
                  </div>
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border border-white rounded-full" title="Online" />
                </div>
                <div className="text-left overflow-hidden">
                  <div className="text-xs font-black text-slate-900 truncate">{user.name}</div>
                  <div className="text-[10px] font-mono text-blue-600 truncate">@{user.username}</div>
                </div>
              </div>

              {/* Chances left */}
              <div className="text-[11px] font-bold text-slate-500 mb-2 flex items-center justify-between">
                <span>Chances:</span>
                <span className="font-mono font-black text-blue-700">{userChancesLeft} / 10</span>
              </div>

              {/* Guessed Number with Tick mark indicator below ID */}
              <div className="bg-white rounded-2xl p-2.5 border border-slate-100 flex items-center justify-between shadow-2xs">
                <div className="text-left">
                  <div className="text-[9px] font-bold uppercase text-slate-400">Your Guess</div>
                  <div className="text-base font-black font-mono text-slate-900">
                    {userLastGuess !== null ? userLastGuess : '--'}
                  </div>
                </div>
                <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${
                  userLastGuess !== null ? 'bg-emerald-500 text-white' : 'bg-slate-100 text-slate-300'
                }`}>
                  <Check className="w-4 h-4 stroke-[3]" />
                </div>
              </div>
            </div>

            {/* Right Player: OPPONENT */}
            <div className={`p-3.5 rounded-3xl border transition-all duration-300 relative ${
              turn === 'opponent'
                ? 'bg-purple-50/90 border-purple-400 shadow-md ring-2 ring-purple-400/30'
                : 'bg-white/80 border-white shadow-sm opacity-90'
            }`}>
              {turn === 'opponent' && (
                <span className="absolute -top-2 right-4 bg-purple-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                  THINKING...
                </span>
              )}

              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-purple-600 text-white font-black text-sm flex items-center justify-center border border-white">
                  ?
                </div>
                <div className="text-left overflow-hidden">
                  <div className="text-xs font-black text-slate-900 truncate">{opponent.name}</div>
                  <div className="text-[10px] font-mono text-purple-600 truncate">@{opponent.username}</div>
                </div>
              </div>

              {/* Opponent chances left */}
              <div className="text-[11px] font-bold text-slate-500 mb-2 flex items-center justify-between">
                <span>Chances:</span>
                <span className="font-mono font-black text-purple-700">{opponent.chancesLeft} / 10</span>
              </div>

              {/* Opponent Guessed Number with Question Mark */}
              <div className="bg-white rounded-2xl p-2.5 border border-slate-100 flex items-center justify-between shadow-2xs">
                <div className="text-left">
                  <div className="text-[9px] font-bold uppercase text-slate-400">Opponent Guess</div>
                  <div className="text-base font-black font-mono text-purple-900">
                    {opponent.lastGuessedNumber !== null ? opponent.lastGuessedNumber : '?'}
                  </div>
                </div>
                <div className="w-7 h-7 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-black text-sm">
                  ?
                </div>
              </div>
            </div>

          </div>

          {/* Visual Wooden Shield Game Emblem */}
          <div className="flex justify-center my-1">
            <GuessNumberBadge
              size="md"
              mysteryText={winner !== null ? `${secretNumber}` : '??'}
              hintText={winner !== null ? (winner === 'user' ? 'YOU WON!' : 'MATCH OVER') : '. HIGHER OR LOWER .'}
              guesses={
                guessHistory.length > 0
                  ? guessHistory.slice(0, 4).map((g) => ({
                      num: g.guess,
                      dir: g.hint === 'lower' ? 'high' : g.hint === 'higher' ? 'low' : 'equal',
                    }))
                  : [
                      { num: 42, dir: 'low' },
                      { num: 55, dir: 'low' },
                      { num: 61, dir: 'low' },
                      { num: 65, dir: 'high' },
                    ]
              }
              lives={userChancesLeft}
            />
          </div>

          {/* Dialogue / Speech Feedback Banner */}
          <div className="bg-white/90 backdrop-blur-md rounded-2xl p-2.5 border border-white shadow-xs text-center">
            <p className="text-xs font-bold text-slate-700">
              {feedback}
            </p>
          </div>

          {/* LONG HORIZONTAL SLIDING BOX ABOVE THE TYPING FIELD */}
          <div className="w-full bg-white/90 backdrop-blur-md rounded-2xl p-2.5 border border-white shadow-sm">
            <div className="flex items-center justify-between mb-1.5 px-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                Guess Stream & Direction (Slide to inspect)
              </span>
              <span className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                {guessHistory.length} Moves
              </span>
            </div>

            {/* Horizontally scrollable / sliding carousel track */}
            <div
              ref={slidingBoxRef}
              className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scroll-smooth no-scrollbar"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {guessHistory.length === 0 ? (
                <div className="w-full py-2 px-3 text-center text-xs font-medium text-slate-400 bg-slate-50/80 rounded-xl border border-dashed border-slate-200">
                  Your guesses with upward (▲ Higher) or downward (▼ Lower) arrows will slide here!
                </div>
              ) : (
                guessHistory.map((item, idx) => {
                  const isHigher = item.hint === 'higher';
                  const isLower = item.hint === 'lower';
                  const isCorrect = item.hint === 'correct';

                  return (
                    <div
                      key={idx}
                      className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold border shadow-xs transition-transform transform active:scale-95 animate-in slide-in-from-right-4 duration-200 ${
                        isCorrect
                          ? 'bg-amber-100 border-amber-300 text-amber-900 ring-2 ring-amber-400/40'
                          : isHigher
                          ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                          : 'bg-rose-50 border-rose-300 text-rose-900'
                      }`}
                    >
                      <span className="text-[10px] uppercase font-black text-slate-500">
                        {item.player === 'user' ? 'You:' : `${opponent.name}:`}
                      </span>
                      <span className="text-sm font-black font-mono">
                        {item.guess}
                      </span>
                      
                      {/* Arrow Indicator: Upward arrow for Higher, Downward arrow for Lower */}
                      <div className={`flex items-center gap-0.5 px-1.5 py-0.5 rounded-md font-black text-[10px] ${
                        isCorrect
                          ? 'bg-amber-500 text-white'
                          : isHigher
                          ? 'bg-emerald-600 text-white'
                          : 'bg-rose-600 text-white'
                      }`}>
                        {isHigher && <ArrowUp className="w-3 h-3 stroke-[3]" />}
                        {isLower && <ArrowDown className="w-3 h-3 stroke-[3]" />}
                        {isCorrect && <span>★</span>}
                        <span>{isHigher ? 'HIGHER' : isLower ? 'LOWER' : 'MATCH'}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Input & Guess Action (When User's Turn) */}
          {lobbyState === 'in_game' && (
            <div className="bg-white/80 backdrop-blur-md p-4 rounded-3xl border border-white shadow-md flex flex-col gap-3">
              <div className="flex gap-2">
                <input
                  type="number"
                  min="1"
                  max="100"
                  placeholder={turn === 'user' ? "Type number (e.g. 50)..." : "Wait for opponent turn..."}
                  disabled={turn !== 'user'}
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleUserGuess();
                  }}
                  className={`flex-1 px-4 py-3 rounded-2xl border font-mono font-bold text-lg text-center transition-all focus:outline-none ${
                    turn === 'user'
                      ? 'bg-white border-blue-400 text-slate-900 focus:ring-2 focus:ring-blue-500'
                      : 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                />
                <button
                  type="button"
                  disabled={turn !== 'user' || !currentInput}
                  onClick={handleUserGuess}
                  className={`px-6 py-3 rounded-2xl font-black text-sm transition-all cursor-pointer active:scale-95 ${
                    turn === 'user' && currentInput
                      ? 'bg-cyan-500 hover:bg-cyan-600 text-white shadow-md shadow-cyan-500/25'
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  GUESS
                </button>
              </div>

              {/* Number Shortcuts / Quick Digits */}
              {turn === 'user' && (
                <div className="flex flex-wrap gap-1.5 justify-center">
                  {[10, 25, 50, 75, 90].map((quick) => (
                    <button
                      key={quick}
                      type="button"
                      onClick={() => setCurrentInput(quick.toString())}
                      className="px-2.5 py-1 bg-white hover:bg-blue-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer shadow-2xs active:scale-95"
                    >
                      {quick}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setCurrentInput('')}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl text-xs font-bold text-slate-500 cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              )}
            </div>
          )}

          {/* CENTER RESULT POPUP MODAL (When number is found / duel ends) */}
          {lobbyState === 'result' && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="w-full max-w-xs bg-white rounded-3xl p-6 border-2 border-white shadow-2xl text-center flex flex-col items-center gap-4 animate-in zoom-in-95 duration-200">
                
                {/* Status Icon & Title */}
                <div className="flex flex-col items-center">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-2 shadow-inner ${
                    winner === 'opponent'
                      ? 'bg-rose-100 text-rose-600'
                      : winner === 'user'
                      ? 'bg-emerald-100 text-emerald-600'
                      : 'bg-amber-100 text-amber-600'
                  }`}>
                    {winner === 'opponent' ? (
                      <Swords className="w-8 h-8 text-rose-600" />
                    ) : winner === 'user' ? (
                      <Trophy className="w-8 h-8 text-amber-500 fill-amber-400" />
                    ) : (
                      <HelpCircle className="w-8 h-8 text-amber-600" />
                    )}
                  </div>
                  
                  <h2 className={`text-2xl font-black tracking-tight ${
                    winner === 'opponent'
                      ? 'text-rose-600'
                      : winner === 'user'
                      ? 'text-emerald-600'
                      : 'text-amber-600'
                  }`}>
                    {winner === 'opponent' ? 'Loose' : winner === 'user' ? 'Win' : 'Draw'}
                  </h2>
                  <p className="text-xs font-semibold text-slate-500 mt-0.5">
                    {winner === 'opponent'
                      ? `${opponent.name} found your number!`
                      : winner === 'user'
                      ? `You found ${opponent.name}'s number! (+20 Tokens)`
                      : 'Both ran out of chances!'}
                  </p>
                </div>

                {/* Small screen / card showing opponent's number in the middle */}
                <div className="w-full bg-gradient-to-b from-slate-50 to-slate-100/90 rounded-2xl p-4 border border-slate-200 shadow-inner flex flex-col items-center justify-center">
                  <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 mb-1 flex items-center gap-1">
                    <Key className="w-3.5 h-3.5 text-slate-400" />
                    <span>Opponent's Number</span>
                  </span>
                  <div className="text-4xl font-black font-mono text-blue-700 bg-white px-6 py-2 rounded-xl shadow-xs border border-blue-100 my-1">
                    {secretNumber}
                  </div>
                </div>

                {/* Primary Retry Button */}
                <button
                  id="online-game-retry-btn"
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    if (onRetry) {
                      onRetry();
                    } else {
                      onBack();
                    }
                  }}
                  className="w-full py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-sm tracking-wider uppercase rounded-2xl shadow-md shadow-blue-500/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Retry</span>
                </button>

              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
