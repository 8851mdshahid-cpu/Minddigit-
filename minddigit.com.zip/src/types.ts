export type ScreenType = 'login' | 'loading' | 'home' | 'game';

export type ActiveGameType = 'guess-number' | 'guess-imposter' | 'math-blitz' | 'pattern-matrix' | 'bridger';

export type GameMode = 'computer' | 'online';

export type DifficultyLevel = 'easy' | 'normal' | 'hard';

export interface UserProfile {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar: string;
  pin?: string;
  securityQuestion?: string;
  securityAnswer?: string;
  isAdmin?: boolean;
  isGuest: boolean;
  coins: number;
  score: number;
  gamesPlayed: number;
  gamesWon: number;
  bestStreak: number;
  currentStreak: number;
  avatarFrame?: string;
}

export interface GuessRecord {
  guess: number;
  hint: 'higher' | 'lower' | 'correct';
  difference: number;
  timestamp: number;
}

export interface GameSettings {
  mode: GameMode;
  difficulty: DifficultyLevel;
  maxRange: number;
  maxLives: number;
  timerSeconds?: number;
}

export interface ImposterItemPair {
  id: string;
  category: string;
  majorityItem: string;
  majorityEmoji: string;
  imposterItem: string;
  imposterEmoji: string;
  sampleClues: {
    majority: string[];
    imposter: string[];
  };
}

export interface ImposterPlayer {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isUser: boolean;
  item: string;
  emoji: string;
  isImposter: boolean;
  audioUrl?: string;
  audioDuration?: number;
  clueText?: string;
  hasSpoken: boolean;
  votesReceived: number;
  votedForId?: string;
  isReady: boolean;
}

export type ImposterGamePhase =
  | 'lobby'
  | 'reveal_item'
  | 'turn_speaking'
  | 'playback_review'
  | 'voting'
  | 'verdict';
