/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ScreenType, GameMode, DifficultyLevel, UserProfile, ActiveGameType } from './types';
import { LoginPage } from './components/LoginPage';
import { LoadingScreen } from './components/LoadingScreen';
import { Navbar } from './components/Navbar';
import { GameGridView } from './components/GameGridView';
import { LuckyScrollAdBanner } from './components/LuckyScrollAdBanner';
import { LuckyScrollModal } from './components/LuckyScrollModal';
import { ModeSelectModal } from './components/ModeSelectModal';
import { GameComputer } from './components/GameComputer';
import { GameOnline } from './components/GameOnline';
import { GameImposter } from './components/GameImposter';
import { GameMathBlitz } from './components/GameMathBlitz';
import { GameBridger } from './components/GameBridger';
import { GamePatternMatrix } from './components/GamePatternMatrix';
import { UserStatsModal } from './components/UserStatsModal';
import { RulesModal } from './components/RulesModal';
import { AdminUsersVault } from './components/AdminUsersVault';
import { AdModal } from './components/AdModal';
import { ImposterRoomModal } from './components/ImposterRoomModal';
import { FriendsModal } from './components/FriendsModal';
import { TopFriendsBar } from './components/TopFriendsBar';
import { BottomNav } from './components/BottomNav';
import { SourceCodeModal } from './components/SourceCodeModal';
import { SelectionToolbar } from './components/SelectionToolbar';
import { FrameCustomizerModal } from './components/FrameCustomizerModal';
import { getFriends, getIncomingRequests, sendFriendRequest, Friend } from './utils/friends';
import { syncUserProfileToFirestore, subscribeToIncomingRequests } from './utils/firebaseFriends';
import { sound } from './utils/audio';
import { Flame, Trophy, Coins, Gift } from 'lucide-react';

const STORAGE_KEY = 'minddigit_user_profile_v1';
const SESSION_KEY = 'minddigit_session_active';

export default function App() {
  const [screen, setScreen] = useState<ScreenType>(() => {
    const sessionActive = localStorage.getItem(SESSION_KEY);
    if (sessionActive === 'false') {
      return 'login';
    }
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved || sessionActive === 'true' || sessionActive === null) {
      return 'home';
    }
    return 'login';
  });

  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return {
      id: 'default-user',
      name: 'Player 1',
      username: 'shahid8851',
      email: '8851mdshahid@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=minddigit-pro',
      isGuest: false,
      coins: 150,
      score: 420,
      gamesPlayed: 5,
      gamesWon: 4,
      bestStreak: 3,
      currentStreak: 2,
      isAdmin: true,
    };
  });

  const [isMuted, setIsMuted] = useState<boolean>(() => sound.getMuted());
  const [isModeModalOpen, setIsModeModalOpen] = useState<boolean>(false);
  const [isImposterModalOpen, setIsImposterModalOpen] = useState<boolean>(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState<boolean>(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState<boolean>(false);
  const [isAdModalOpen, setIsAdModalOpen] = useState<boolean>(false);
  const [isLuckyScrollModalOpen, setIsLuckyScrollModalOpen] = useState<boolean>(false);
  const [isSourceCodeModalOpen, setIsSourceCodeModalOpen] = useState<boolean>(false);
  const [isFrameCustomizerOpen, setIsFrameCustomizerOpen] = useState<boolean>(false);

  // Friends & Notifications State
  const [isFriendsModalOpen, setIsFriendsModalOpen] = useState<boolean>(false);
  const [friendsModalTab, setFriendsModalTab] = useState<'add' | 'notifications' | 'friends'>('add');
  const [friendsList, setFriendsList] = useState<Friend[]>(() => getFriends(user.id));
  const [pendingRequestsCount, setPendingRequestsCount] = useState<number>(() => getIncomingRequests(user.username).length);
  const [bottomNavTab, setBottomNavTab] = useState<'home' | 'chat' | 'profile'>('home');

  const [activeGame, setActiveGame] = useState<ActiveGameType>('guess-number');
  const [activeGameMode, setActiveGameMode] = useState<GameMode>('computer');
  const [activeDifficulty, setActiveDifficulty] = useState<DifficultyLevel>('normal');
  const [imposterRoomCode, setImposterRoomCode] = useState<string | undefined>(undefined);
  const [imposterPlayersCount, setImposterPlayersCount] = useState<number>(3);
  const [imposterCustomPlayers, setImposterCustomPlayers] = useState<Array<{ name: string; username: string; avatar: string }> | undefined>(undefined);

  const isAdminUser = Boolean(user.isAdmin || user.username.toLowerCase() === 'shahid8851');

  // Refresh friends and notifications data
  const refreshFriendsData = () => {
    const friends = getFriends(user.id);
    const requests = getIncomingRequests(user.username);
    setFriendsList(friends);
    setPendingRequestsCount(requests.length);
  };

  // Real-time polling & Firestore subscription for incoming requests and 15s expirations
  useEffect(() => {
    refreshFriendsData();
    syncUserProfileToFirestore(user);

    // Subscribe to real-time Firestore requests
    const unsubscribe = subscribeToIncomingRequests(user.username, (firestoreReqs) => {
      const localReqs = getIncomingRequests(user.username);
      const merged = [...firestoreReqs];
      localReqs.forEach((lr) => {
        if (!merged.some((mr) => mr.id === lr.id)) {
          merged.push(lr);
        }
      });
      setPendingRequestsCount(merged.length);
    });

    const interval = setInterval(() => {
      refreshFriendsData();
    }, 2000);

    return () => {
      clearInterval(interval);
      if (unsubscribe) unsubscribe();
    };
  }, [user.id, user.username]);

  // Sync user state to localStorage and update accounts table
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    try {
      const raw = localStorage.getItem('minddigit_accounts');
      if (raw) {
        const accounts = JSON.parse(raw);
        if (Array.isArray(accounts)) {
          const idx = accounts.findIndex(
            (a: any) =>
              a.id === user.id ||
              a.username.toLowerCase() === user.username.toLowerCase()
          );
          if (idx !== -1) {
            accounts[idx] = {
              ...accounts[idx],
              coins: user.coins,
              score: user.score,
              gamesPlayed: user.gamesPlayed,
              gamesWon: user.gamesWon,
              bestStreak: user.bestStreak,
              currentStreak: user.currentStreak,
            };
            localStorage.setItem('minddigit_accounts', JSON.stringify(accounts));
          }
        }
      }
    } catch {
      // ignore
    }
  }, [user]);

  // Audio mute toggle handler
  const handleToggleMute = () => {
    const newMute = !isMuted;
    setIsMuted(newMute);
    sound.setMuted(newMute);
  };

  // Login success -> trigger loading screen and save active session
  const handleLoginSuccess = (profile: UserProfile) => {
    setUser(profile);
    localStorage.setItem(SESSION_KEY, 'true');
    setScreen('loading');
  };

  // Loading finished -> go to Home
  const handleLoadingComplete = () => {
    setScreen('home');
  };

  // Game Selection from 2x2 Grid
  const handleSelectGame = (game: ActiveGameType) => {
    if (game === 'guess-number') {
      setIsModeModalOpen(true);
    } else if (game === 'guess-imposter') {
      setIsImposterModalOpen(true);
    } else if (game === 'math-blitz') {
      handleStartMathBlitz();
    } else if (game === 'bridger') {
      handleStartBridger();
    } else if (game === 'pattern-matrix') {
      handleStartPatternMatrix();
    }
  };

  const [joinRoomCode, setJoinRoomCode] = useState<string | undefined>(undefined);
  const [joinOpponent, setJoinOpponent] = useState<{ name: string; username: string } | undefined>(undefined);

  // Launch Guess Number game with token fees check
  const handleStartGame = (
    mode: GameMode,
    difficulty: DifficultyLevel,
    roomCodeToJoin?: string,
    opponentInfo?: { name: string; username: string }
  ) => {
    if (mode === 'online') {
      if (roomCodeToJoin) {
        // Entering a friend's code / joining a room: 100% FREE (NO COINS DEDUCTED)
        setJoinRoomCode(roomCodeToJoin);
        setJoinOpponent(opponentInfo);
      } else {
        // Creating a new room
        if (user.coins < 10) {
          sound.playLose();
          setIsAdModalOpen(true);
          return;
        }
        // Deduct 10 tokens only when creating a new room
        setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 10) }));
        setJoinRoomCode(undefined);
        setJoinOpponent(undefined);
      }
    } else if (mode === 'computer') {
      if (user.coins < 1) {
        sound.playLose();
        setIsAdModalOpen(true);
        return;
      }
      // Deduct 1 token for playing with computer
      setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 1) }));
      setJoinRoomCode(undefined);
      setJoinOpponent(undefined);
    }

    setActiveGame('guess-number');
    setActiveGameMode(mode);
    setActiveDifficulty(difficulty);
    setIsModeModalOpen(false);
    setScreen('game');
  };

  // Launch Against the Imposter game from room lobby
  const handleStartImposterMatch = (
    roomCode?: string,
    initialCount: number = 3,
    customPlayers?: Array<{ name: string; username: string; avatar: string }>,
    isHostCreated: boolean = false
  ) => {
    sound.playWin();
    // Only deduct 20 tokens if the user is the host who created the room
    if (isHostCreated && user.coins >= 20) {
      setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 20) }));
    }
    setImposterRoomCode(roomCode);
    setImposterPlayersCount(initialCount);
    setImposterCustomPlayers(customPlayers);
    setActiveGame('guess-imposter');
    setIsImposterModalOpen(false);
    setScreen('game');
  };

  // Launch Math Blitz game (1 token)
  const handleStartMathBlitz = () => {
    sound.playPop();
    if (user.coins < 1) {
      sound.playLose();
      setIsAdModalOpen(true);
      return;
    }
    setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 1) }));
    setActiveGame('math-blitz');
    setScreen('game');
  };

  // Launch Bridger game (5 rounds, 1 token)
  const handleStartBridger = () => {
    sound.playPop();
    if (user.coins < 1) {
      sound.playLose();
      setIsAdModalOpen(true);
      return;
    }
    setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 1) }));
    setActiveGame('bridger');
    setScreen('game');
  };

  // Launch Pattern Matrix game (1 token)
  const handleStartPatternMatrix = () => {
    sound.playPop();
    if (user.coins < 1) {
      sound.playLose();
      setIsAdModalOpen(true);
      return;
    }
    setUser((prev) => ({ ...prev, coins: Math.max(0, prev.coins - 1) }));
    setActiveGame('pattern-matrix');
    setScreen('game');
  };

  // Game End updates (Tokens & score)
  const handleGameEnd = (won: boolean, scoreGained: number, coinsGained: number) => {
    setUser((prev) => {
      const newPlayed = prev.gamesPlayed + 1;
      const newWon = won ? prev.gamesWon + 1 : prev.gamesWon;
      const newStreak = won ? prev.currentStreak + 1 : 0;
      const newBestStreak = Math.max(prev.bestStreak, newStreak);
      const newScore = prev.score + scoreGained;
      const newCoins = prev.coins + coinsGained;

      return {
        ...prev,
        gamesPlayed: newPlayed,
        gamesWon: newWon,
        currentStreak: newStreak,
        bestStreak: newBestStreak,
        score: newScore,
        coins: newCoins,
      };
    });
  };

  // Handle starting a game directly with a friend (strictly guards against offline players)
  const handleStartGameWithFriend = (
    friend: Friend,
    gameType: ActiveGameType = 'guess-imposter',
    roomCode?: string
  ) => {
    if (!friend.isOnline) {
      sound.playLose();
      sendFriendRequest(user, friend.username, roomCode, gameType, true);
      setScreen('friends');
      return;
    }

    sound.playWin();
    if (gameType === 'guess-imposter') {
      const friendPlayer = {
        name: friend.name,
        username: friend.username,
        avatar: friend.avatar,
      };
      const computerPlayer = {
        name: 'Computer 1',
        username: 'computer_1',
        avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=computer1',
      };
      // Launch 3-player imposter match (You + Friend + Computer)
      handleStartImposterMatch(roomCode, 3, [friendPlayer, computerPlayer], false);
    } else if (gameType === 'math-blitz') {
      setJoinOpponent({
        name: friend.name,
        username: friend.username,
        avatar: friend.avatar,
      });
      setActiveGame('math-blitz');
      setScreen('game');
    } else {
      // Launch Guess Number Online Duel
      handleStartGame('online', 'normal', roomCode, {
        name: friend.name,
        username: friend.username,
      });
    }
  };

  const handleRewardClaimed = (tokensGained: number) => {
    setUser((prev) => ({
      ...prev,
      coins: prev.coins + tokensGained,
    }));
  };

  const handleSelectAvatarFrame = (frameId: string) => {
    setUser((prev) => ({
      ...prev,
      avatarFrame: frameId,
    }));
  };

  const handleLogout = () => {
    localStorage.setItem(SESSION_KEY, 'false');
    setScreen('login');
  };

  return (
    <div className="min-h-screen w-full bg-slate-900/10 flex justify-center items-start sm:py-3">
      
      {/* COMPACT MOBILE-SIZED APP CONTAINER */}
      <div className="w-full max-w-md min-h-screen sm:min-h-[92vh] sm:max-h-[96vh] sm:rounded-[36px] bg-gradient-to-br from-[#cff3fa] via-[#ffe8d6] to-[#ffd7cd] text-slate-800 font-['Plus_Jakarta_Sans',sans-serif] flex flex-col shadow-2xl overflow-y-auto overflow-x-hidden relative border-0 sm:border border-white/60">
        
        {/* 1. LOGIN SCREEN */}
        {screen === 'login' && (
          <LoginPage onSuccess={handleLoginSuccess} />
        )}

        {/* 2. LOADING SCREEN */}
        {screen === 'loading' && (
          <LoadingScreen onComplete={handleLoadingComplete} durationMs={400} />
        )}

        {/* 3. HOME SCREEN */}
        {screen === 'home' && (
          <>
            {/* Top Navbar with App Logo, Add Friend (+), Notifications Bell, & Tokens */}
            <Navbar
              user={user}
              onOpenStats={() => setIsStatsModalOpen(true)}
              onOpenTokens={() => setIsAdModalOpen(true)}
              onOpenSourceCode={() => setIsSourceCodeModalOpen(true)}
              onOpenAddFriend={() => {
                setFriendsModalTab('add');
                setIsFriendsModalOpen(true);
              }}
              onOpenNotifications={() => {
                setFriendsModalTab('notifications');
                setIsFriendsModalOpen(true);
              }}
              pendingRequestsCount={pendingRequestsCount}
            />

            {/* Main Home Content */}
            <main className="flex-1 w-full px-3.5 py-3 pb-20 flex flex-col items-center">
              
              {/* ADMIN EXCLUSIVE TOP BOX: Master Users Vault */}
              {isAdminUser && (
                <AdminUsersVault currentUsername={user.username} />
              )}

              {/* Sub-header Strip: Streak, Wins & Free Token Ad Claim */}
              <div className="w-full flex items-center justify-between gap-2 mb-2.5 bg-white/75 backdrop-blur-md border border-white/90 px-3.5 py-2 rounded-2xl shadow-xs">
                <div className="flex items-center gap-2.5">
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-400" />
                    <span className="text-xs font-bold text-slate-800">
                      {user.currentStreak} Streak
                    </span>
                  </div>
                  <div className="w-px h-3.5 bg-slate-200" />
                  <div className="flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-blue-600 fill-blue-500" />
                    <span className="text-xs font-bold text-slate-800">
                      {user.gamesWon} Wins
                    </span>
                  </div>
                </div>

                {/* Free Token Ad Button */}
                <button
                  type="button"
                  onClick={() => {
                    sound.playPop();
                    setIsAdModalOpen(true);
                  }}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white font-black text-[11px] shadow-xs hover:from-amber-600 hover:to-orange-600 transition-all cursor-pointer active:scale-95"
                >
                  <Gift className="w-3 h-3" />
                  <span>Free 20 🪙</span>
                </button>
              </div>

              {/* TOP FRIENDS BAR: Friends appear at top, click friend to play! */}
              <TopFriendsBar
                friends={friendsList}
                onOpenAddFriend={() => {
                  setFriendsModalTab('add');
                  setIsFriendsModalOpen(true);
                }}
                onOpenNotifications={() => {
                  setFriendsModalTab('notifications');
                  setIsFriendsModalOpen(true);
                }}
                onSelectFriendToPlay={(friend) => handleStartGameWithFriend(friend)}
                pendingRequestsCount={pendingRequestsCount}
              />

              {/* DAILY LUCKY SCROLL AD BANNER (Placed below navigation & sub-section) */}
              <LuckyScrollAdBanner
                onOpenScrollModal={() => setIsLuckyScrollModalOpen(true)}
              />

              {/* 2x2 GAMES GRID (Game 1 Left, Game 2 Right; Game 3 Bottom-Left, Game 4 Bottom-Right) */}
              <div className="w-full">
                <GameGridView
                  onSelectGame={handleSelectGame}
                  userTokens={user.coins}
                />
              </div>

            </main>

            {/* FIXED BOTTOM NAVIGATION with Add Friend (+) option */}
            <BottomNav
              currentTab={bottomNavTab}
              onSelectTab={(tab) => {
                setBottomNavTab(tab);
                if (tab === 'profile') setIsStatsModalOpen(true);
              }}
              user={user}
              onOpenAddFriend={() => {
                setFriendsModalTab('add');
                setIsFriendsModalOpen(true);
              }}
              pendingRequestsCount={pendingRequestsCount}
            />
          </>
        )}

        {/* 4. ACTIVE GAMEPLAY SCREEN */}
        {screen === 'game' && (
          <div className="flex-1 flex flex-col">
            <Navbar
              user={user}
              onOpenStats={() => setIsStatsModalOpen(true)}
              onOpenTokens={() => setIsAdModalOpen(true)}
              onOpenAddFriend={() => {
                setFriendsModalTab('add');
                setIsFriendsModalOpen(true);
              }}
              onOpenNotifications={() => {
                setFriendsModalTab('notifications');
                setIsFriendsModalOpen(true);
              }}
              pendingRequestsCount={pendingRequestsCount}
            />

            <main className="flex-1 flex items-center justify-center p-2 sm:p-3">
              {activeGame === 'guess-imposter' && (
                <GameImposter
                  user={user}
                  roomCode={imposterRoomCode}
                  initialPlayersCount={imposterPlayersCount}
                  customPlayers={imposterCustomPlayers}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                />
              )}

              {activeGame === 'guess-number' && activeGameMode === 'computer' && (
                <GameComputer
                  difficulty={activeDifficulty}
                  user={user}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                  onRetry={() => {
                    setScreen('home');
                    setIsModeModalOpen(true);
                  }}
                />
              )}

              {activeGame === 'guess-number' && activeGameMode === 'online' && (
                <GameOnline
                  difficulty={activeDifficulty}
                  user={user}
                  initialRoomCode={joinRoomCode}
                  initialOpponent={joinOpponent}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                  onRetry={() => {
                    setScreen('home');
                    setIsModeModalOpen(true);
                  }}
                />
              )}

              {activeGame === 'math-blitz' && (
                <GameMathBlitz
                  user={user}
                  initialOpponent={joinOpponent}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                  onRetry={() => {
                    setJoinOpponent(undefined);
                    setActiveGame('math-blitz');
                    setScreen('game');
                  }}
                />
              )}

              {activeGame === 'bridger' && (
                <GameBridger
                  user={user}
                  initialOpponent={joinOpponent}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                  onRetry={() => {
                    setJoinOpponent(undefined);
                    setActiveGame('bridger');
                    setScreen('game');
                  }}
                />
              )}

              {activeGame === 'pattern-matrix' && (
                <GamePatternMatrix
                  user={user}
                  onBack={() => setScreen('home')}
                  onGameEnd={handleGameEnd}
                />
              )}
            </main>
          </div>
        )}

      </div>

      {/* MODALS */}
      {/* 1. Friends & Notifications Modal (Add Friend, 15s Requests, Accept/Reject, & Friend list) */}
      <FriendsModal
        isOpen={isFriendsModalOpen}
        onClose={() => setIsFriendsModalOpen(false)}
        user={user}
        initialTab={friendsModalTab}
        onStartGameWithFriend={handleStartGameWithFriend}
        onRequestsUpdated={refreshFriendsData}
      />

      {/* 2. Mode Select Modal (Online Room / Computer + Tokens selection for Guess Number) */}
      <ModeSelectModal
        isOpen={isModeModalOpen}
        onClose={() => setIsModeModalOpen(false)}
        onSelectMode={handleStartGame}
        user={user}
        onOpenAdModal={() => setIsAdModalOpen(true)}
      />

      {/* 3. Imposter Room Modal (Create Room 20 coins / Enter Code Free, Min 3 - Max 5 Players) */}
      <ImposterRoomModal
        isOpen={isImposterModalOpen}
        onClose={() => setIsImposterModalOpen(false)}
        user={user}
        onStartImposterGame={handleStartImposterMatch}
        onOpenAdModal={() => setIsAdModalOpen(true)}
      />

      {/* 4. User Stats & Profile Modal */}
      <UserStatsModal
        isOpen={isStatsModalOpen}
        user={user}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenRules={() => setIsRulesModalOpen(true)}
        onOpenSourceCode={() => setIsSourceCodeModalOpen(true)}
        onOpenFrameCustomizer={() => setIsFrameCustomizerOpen(true)}
        onClose={() => setIsStatsModalOpen(false)}
        onLogout={handleLogout}
      />

      {/* 5. Rules & How to Play Modal */}
      <RulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
      />

      {/* 6. Watch Ad for Free Tokens Modal */}
      <AdModal
        isOpen={isAdModalOpen}
        onClose={() => setIsAdModalOpen(false)}
        onRewardClaimed={handleRewardClaimed}
      />

      {/* 7. Daily Lucky Scroll Modal (2 Chances Daily + Try After Time Countdown) */}
      <LuckyScrollModal
        isOpen={isLuckyScrollModalOpen}
        onClose={() => setIsLuckyScrollModalOpen(false)}
        userCoins={user.coins}
        onAwardTokens={handleRewardClaimed}
      />

      {/* 8. Interactive Source Code Explorer Modal (HTML, CSS, TypeScript, Server) */}
      <SourceCodeModal
        isOpen={isSourceCodeModalOpen}
        onClose={() => setIsSourceCodeModalOpen(false)}
      />

      {/* 9. Avatar Frame Customizer Modal (चेंज फ्रेम) */}
      <FrameCustomizerModal
        isOpen={isFrameCustomizerOpen}
        onClose={() => setIsFrameCustomizerOpen(false)}
        user={user}
        onSelectFrame={handleSelectAvatarFrame}
      />

      {/* 10. Global On-Screen Selection Floating Action Toolbar (Cut, Copy, Paste, Deselect/Remove, Change Frame) */}
      <SelectionToolbar
        onOpenFrameCustomizer={() => setIsFrameCustomizerOpen(true)}
      />

    </div>
  );
}

